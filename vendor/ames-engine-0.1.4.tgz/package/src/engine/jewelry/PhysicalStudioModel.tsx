import { useGLTF } from '@react-three/drei'
import { useThree } from '@react-three/fiber'
import { useEffect, useMemo, useRef } from 'react'
import { Box3, Group, Matrix4, Mesh, Vector3 } from 'three'
import type { BufferGeometry, Material, MeshPhysicalMaterial } from 'three'
import { applyJewelryMaterials, isQualifiedDielectricMesh } from './jewelryGlbMaterials'
import { createStudioBrilliantGeometry } from './createStudioBrilliantGeometry'
import { createPhysicalStudioGem } from '../materials/PhysicalStudioGem'
import { useControlledTurntable } from '../renderer/useControlledTurntable'
import type { PhysicalStudio } from '../renderer/usePhysicalStudio'

const BRILLIANT_IDS = new Set(['stone-diamond','stone-fancy-color-diamond','stone-ruby','stone-sapphire','stone-morganite','stone-alexandrite','stone-spinel','stone-garnet','stone-zircon','stone-peridot'])

export function PhysicalStudioModel({url, studio, enabled, interacting, resetToken, onReady}: {
  url: string; studio: PhysicalStudio; enabled: boolean; interacting: boolean; resetToken?: number; onReady?: () => void
}) {
  const {scene} = useGLTF(url)
  const {gl, invalidate} = useThree()
  const pivot = useRef<Group>(null)
  const built = useMemo(() => {
    const root=scene.clone(true), geometries: BufferGeometry[]=[], materials: Material[]=[], diagnostics: object[]=[]
    const bounds=new Box3().setFromObject(root), scale=2.6/Math.max(...bounds.getSize(new Vector3()).toArray())
    root.position.sub(bounds.getCenter(new Vector3())); root.updateMatrixWorld(true)
    const gems: Mesh[]=[]
    root.traverse(object=>{if(object instanceof Mesh && isQualifiedDielectricMesh(object))gems.push(object)})
    const assignment=applyJewelryMaterials(root,studio.environment,{preserveMesh:mesh=>gems.includes(mesh),opticsProfile:'mounted-gem-studio'})
    materials.push(...assignment.materials)
    for(const mesh of gems) {
      const source=(Array.isArray(mesh.material)?mesh.material[0]:mesh.material) as MeshPhysicalMaterial
      const id=String(mesh.userData.ames_gemstone_id ?? mesh.parent?.userData.ames_gemstone_id ?? 'stone-diamond')
      // Replace only AMES-authored representative cuts. Uploaded jeweller geometry is retained.
      if(BRILLIANT_IDS.has(id) && /\/(stone-[a-z-]+|demo-pave-solitaire)\//.test(url)) {
        mesh.geometry.computeBoundingBox();const old=mesh.geometry.boundingBox!, size=old.getSize(new Vector3()),center=old.getCenter(new Vector3())
        const geometry=createStudioBrilliantGeometry();geometry.computeBoundingBox()
        const own=geometry.boundingBox!, ownSize=own.getSize(new Vector3()),ownCenter=own.getCenter(new Vector3())
        geometry.translate(-ownCenter.x,-ownCenter.y,-ownCenter.z)
        geometry.scale(size.x/ownSize.x,size.y/ownSize.y,size.z/ownSize.z)
        geometry.translate(center.x,center.y,center.z);mesh.geometry=geometry;geometries.push(geometry)
      }
      // GPU intersection tolerances operate in geometry-local coordinates. Authoring
      // units can be metres or millimetres: normalise each stone before building its
      // BVH, then preserve its exact placement with the inverse mesh transform.
      mesh.geometry.computeBoundingBox()
      const opticalBounds=mesh.geometry.boundingBox!, opticalCenter=opticalBounds.getCenter(new Vector3())
      const opticalScale=opticalBounds.getSize(new Vector3()).length()
      if(!Number.isFinite(opticalScale)||opticalScale<=0)throw Error('Invalid gemstone volume.')
      const normalised=mesh.geometry.clone()
      normalised.translate(-opticalCenter.x,-opticalCenter.y,-opticalCenter.z)
      normalised.scale(1/opticalScale,1/opticalScale,1/opticalScale)
      mesh.geometry=normalised;geometries.push(normalised)
      mesh.updateMatrix()
      mesh.matrix.multiply(new Matrix4().makeTranslation(opticalCenter)).multiply(new Matrix4().makeScale(opticalScale,opticalScale,opticalScale))
      mesh.matrix.decompose(mesh.position,mesh.quaternion,mesh.scale);mesh.updateMatrixWorld(true)
      const worldScale=scale * mesh.getWorldScale(new Vector3()).y
      mesh.geometry.computeBoundingBox()
      const small=mesh.geometry.boundingBox!.getSize(new Vector3()).length()*worldScale<.2
      const material=createPhysicalStudioGem(mesh.geometry,id,source,studio.environment,studio.radiance,worldScale,small)
      mesh.material=material;materials.push(material)
      diagnostics.push({id,type:material.type,ior:material.ior,transmission:material.transmission,roughness:material.roughness,
        color:material.color.getHexString(),attenuationColor:material.attenuationColor.getHexString(),attenuationDistance:material.attenuationDistance,
        thickness:material.thickness,dispersion:material.dispersion,triangles:(mesh.geometry.index?.count??mesh.geometry.getAttribute('position').count)/3,
        cut:mesh.geometry.userData.cut??'imported',...mesh.geometry.userData})
    }
    return {root,scale,materials,geometries,diagnostics}
  },[scene,studio,url])
  useEffect(()=>()=>{built.materials.forEach(m=>m.dispose());built.geometries.forEach(g=>g.dispose())},[built])
  useEffect(()=>{
    gl.domElement.dataset.gemMaterials=JSON.stringify(built.diagnostics)
    let frame=requestAnimationFrame(()=>{invalidate();frame=requestAnimationFrame(()=>onReady?.())})
    return()=>{cancelAnimationFrame(frame);delete gl.domElement.dataset.gemMaterials}
  },[built,gl,invalidate,onReady])
  useControlledTurntable(pivot,enabled,true,interacting,resetToken,invalidate)
  return <group ref={pivot} name="ames-physical-turntable" scale={built.scale}><primitive object={built.root}/></group>
}
