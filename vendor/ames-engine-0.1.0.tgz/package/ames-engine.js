import { ACESFilmicToneMapping as e, BackSide as t, Box3 as n, BoxGeometry as r, Color as i, Mesh as a, MeshBasicMaterial as o, MeshPhysicalMaterial as s, PMREMGenerator as c, PerspectiveCamera as l, PlaneGeometry as u, SRGBColorSpace as d, Scene as f, ShaderMaterial as p, Sphere as m, Texture as h, Vector3 as g, WebGLRenderer as _ } from "three";
import { GLTFLoader as v } from "three/examples/jsm/loaders/GLTFLoader.js";
import { OrbitControls as y } from "three/examples/jsm/controls/OrbitControls.js";
import { HDRLoader as b } from "three/examples/jsm/loaders/HDRLoader.js";
import { useEffect as x, useRef as S, useState as C } from "react";
import { jsx as w } from "react/jsx-runtime";
//#region src/engine/assets/schema.ts
var ee = [
	"ring",
	"watch",
	"bracelet",
	"necklace",
	"earring",
	"stone"
], T = class extends Error {
	code;
	assetId;
	path;
	constructor(e, t, n, r, i) {
		super(t, i), this.code = e, this.assetId = n, this.path = r, this.name = "AssetError";
	}
}, E = (e) => {
	throw new T("INVALID_MANIFEST", e);
};
function D(e, t) {
	return !e || typeof e != "object" || Array.isArray(e) ? E(`${t} must be an object.`) : e;
}
function O(e, t) {
	return typeof e != "string" || !e.trim() || e !== e.trim() ? E(`${t} must be a nonempty trimmed string.`) : e;
}
function k(e, t, n) {
	return typeof e != "string" || !t.includes(e) ? E(`Invalid ${n}.`) : e;
}
function A(e, t) {
	if (!Array.isArray(e)) return E(`${t} must be an array.`);
	let n = e.map((e) => O(e, t));
	return new Set(n).size === n.length ? n : E(`Duplicate ${t}.`);
}
function j(e, t = !0) {
	let n = () => {
		throw new T("INVALID_ASSET_PATH", `Invalid ${t ? "GLB" : "preview"} asset path: ${String(e)}`);
	};
	if (typeof e != "string" || e !== e.trim() || /[\\\u0000-\u0020]/.test(e) || !(e.startsWith("/") && !e.startsWith("//") || /^https?:\/\//i.test(e))) return n();
	let r;
	try {
		let t = decodeURIComponent(e.split(/[?#]/)[0]);
		if (t.split("/").some((e) => e === ".." || e === ".") || t.includes("\\")) return n();
		r = new URL(e, "https://ames.invalid");
	} catch {
		return n();
	}
	return r.username || r.password || t && !/\.glb$/i.test(r.pathname) ? n() : e;
}
function te(e) {
	let t = D(e, "Manifest");
	if (t.schemaVersion !== 1 || !Array.isArray(t.assets)) return E("Expected schemaVersion 1 and assets array.");
	let n = /* @__PURE__ */ new Set(), r = t.assets.map((e) => {
		let t = D(e, "Asset"), r = O(t.id, "asset id");
		if (n.has(r)) return E(`Duplicate asset id: ${r}`);
		n.add(r);
		let i = k(t.category, ee, "category");
		if (!Array.isArray(t.materialSlots)) return E(`materialSlots must be an array: ${r}`);
		let a = /* @__PURE__ */ new Set(), o = t.materialSlots.map((e) => {
			let t = D(e, "Material slot"), n = O(t.id, "slot id");
			return a.has(n) ? E(`Duplicate material slot: ${n}`) : (a.add(n), Object.freeze({
				id: n,
				kind: k(t.kind, ["metal", "gem"], "slot kind"),
				...t.materialName === void 0 ? {} : { materialName: O(t.materialName, "materialName") }
			}));
		}), s = A(t.stoneReferences, "stoneReferences");
		if (s.some((e) => !/^stone-.+/.test(e))) return E(`Invalid stone reference: ${r}`);
		if (i === "stone" && s.length !== 1) return E(`Stone asset must reference exactly one stone identity: ${r}`);
		let c = A(t.metalCompatibility, "metalCompatibility").map((e) => k(e, [
			"gold",
			"silver",
			"platinum"
		], "metal"));
		return Object.freeze({
			id: r,
			name: O(t.name, "name"),
			category: i,
			assetPath: j(t.assetPath),
			previewPath: t.previewPath === null ? null : j(t.previewPath, !1),
			materialSlots: Object.freeze(o),
			stoneReferences: Object.freeze(s),
			metalCompatibility: Object.freeze(c),
			accessTier: k(t.accessTier, [
				"public",
				"premium",
				"exclusive",
				"PUBLIC",
				"MEMBER",
				"PREMIUM",
				"COLLECTOR",
				"PRIVATE"
			], "accessTier"),
			tags: Object.freeze(A(t.tags, "tags")),
			status: k(t.status, [
				"draft",
				"validated",
				"published",
				"archived"
			], "status")
		});
	});
	return Object.freeze({
		schemaVersion: 1,
		assets: Object.freeze(r)
	});
}
function M(e) {
	let t = te(e), n = new Map(t.assets.map((e) => [e.id, e]));
	return Object.freeze({
		manifest: t,
		get: (e) => n.get(e),
		require: (e, t) => {
			let r = n.get(e);
			if (!r) throw new T("ASSET_NOT_FOUND", `Asset not registered: ${e}`, e);
			if (t && t !== r.category) throw new T("WRONG_CATEGORY", `Asset ${e} is ${r.category}; expected ${t}.`, e);
			return r;
		},
		list: (e) => e ? Object.freeze(t.assets.filter((t) => t.category === e)) : t.assets
	});
}
async function ne(e, t = fetch) {
	let n;
	try {
		let r = await t(e);
		if (!r.ok) throw Error(`HTTP ${r.status}`);
		n = await r.json();
	} catch (t) {
		throw new T("MANIFEST_LOAD_FAILED", `Unable to load manifest ${e}: ${String(t)}`, void 0, e, { cause: t });
	}
	return M(n);
}
//#endregion
//#region src/engine/access/index.ts
var re = [
	"PUBLIC",
	"MEMBER",
	"PREMIUM",
	"COLLECTOR",
	"PRIVATE"
];
function N(e) {
	return e === "public" ? "PUBLIC" : e === "premium" ? "PREMIUM" : e === "exclusive" ? "COLLECTOR" : e;
}
var P = class extends Error {
	access;
	code = "ACCESS_DENIED";
	constructor(e) {
		super(e.reason ?? "Access denied."), this.access = e, this.name = "AccessDeniedError";
	}
};
function ie(e, t) {
	let n = /* @__PURE__ */ new Set(), r = /* @__PURE__ */ new Map(), i = !1;
	function a() {
		if (i) throw Error("Access controller disposed.");
	}
	function o(e) {
		for (let t of n) try {
			t(Object.freeze(e));
		} catch {}
	}
	function s(e, t, n) {
		return Object.freeze({
			assetId: e.id,
			tier: N(e.accessTier),
			state: t,
			reason: n,
			previewPath: e.previewPath
		});
	}
	async function c(n) {
		a();
		let i = e.require(n), c = N(i.accessTier) === "PUBLIC";
		if (!c) try {
			c = await t.entitlements?.canAccess(t.userId, n) === !0;
		} catch {
			c = !1;
		}
		a();
		let l = s(i, c ? "unlocked" : "locked", c ? null : "Entitlement required or unavailable.");
		return r.set(n, l), o({
			type: c ? "ACCESS_GRANTED" : "ACCESS_DENIED",
			access: l
		}), l;
	}
	async function l(n) {
		let i = await c(n), l = e.require(n);
		if (i.state !== "unlocked") throw new P(i);
		if (i.tier === "PUBLIC") return l.assetPath;
		try {
			if (!t.delivery) throw Error("Protected delivery adapter required.");
			let e = await t.delivery.resolve(t.userId, n);
			a();
			let r = j(e.url);
			if (!r.startsWith("https://") || !Number.isFinite(e.expiresAt) || e.expiresAt <= Date.now()) throw Error("Invalid or expired delivery lease.");
			return r;
		} catch {
			a();
			let e = s(l, "locked", "Protected asset delivery unavailable.");
			throw r.set(n, e), o({
				type: "ACCESS_DENIED",
				access: e
			}), new P(e);
		}
	}
	return Object.freeze({
		check: c,
		authorize: l,
		getState: (t) => {
			a();
			let n = e.require(t);
			return r.get(t) ?? s(n, N(n.accessTier) === "PUBLIC" ? "unlocked" : "locked", null);
		},
		preview: (t) => {
			a();
			let n = e.require(t);
			if (N(n.accessTier) === "PUBLIC" || !n.previewPath) throw Error("No premium preview registered.");
			let i = s(n, "premium-preview", "Preview only; protected GLB remains locked.");
			return r.set(t, i), o({
				type: "PREMIUM_PREVIEWED",
				access: i
			}), i;
		},
		startSubscription: async (n) => {
			if (a(), e.require(n), !t.onSubscriptionStarted) throw Error("No subscription hook configured.");
			await t.onSubscriptionStarted(t.userId, n), a(), o({
				type: "SUBSCRIPTION_STARTED",
				assetId: n,
				userId: t.userId
			});
		},
		subscribe: (e) => (a(), n.add(e), () => {
			n.delete(e);
		}),
		dispose: () => {
			i = !0, r.clear(), n.clear();
		}
	});
}
//#endregion
//#region src/engine/loaders/readJewelryScene.ts
function F(e) {
	return [
		e.x,
		e.y,
		e.z
	];
}
function ae(e) {
	let t = [], n = e;
	for (; n;) t.push(n.name || n.type), n = n.parent;
	return t.reverse().join("/");
}
function oe(e) {
	return e.index ? Math.floor(e.index.count / 3) : Math.floor((e.getAttribute("position")?.count ?? 0) / 3);
}
function se(e) {
	e.updateWorldMatrix(!0, !0);
	let t = /* @__PURE__ */ new Map(), r = [], i = [], o = 0, s = 0, c = (e) => {
		let n = t.get(e);
		if (n !== void 0) return n;
		let i = r.length;
		return t.set(e, i), r.push({
			index: i,
			name: e.name || `${e.type}-${i}`,
			type: e.type,
			transparent: e.transparent,
			opacity: e.opacity
		}), i;
	};
	e.traverse((e) => {
		if (!(e instanceof a)) return;
		let t = e.geometry, r = t.getAttribute("position")?.count ?? 0, l = oe(t), u = new n().setFromObject(e).getSize(new g()), d = e.getWorldPosition(new g()), f = e.getWorldQuaternion(e.quaternion.clone()), p = e.getWorldScale(new g()), m = e.material, h = (Array.isArray(m) ? m : [m]).map(c);
		o += r, s += l, i.push({
			id: e.uuid,
			name: e.name || `Mesh-${i.length}`,
			parentName: e.parent?.name || void 0,
			path: ae(e),
			vertexCount: r,
			triangleCount: l,
			dimensions: F(u),
			worldPosition: F(d),
			worldQuaternion: [
				f.x,
				f.y,
				f.z,
				f.w
			],
			worldScale: F(p),
			materialIndices: h
		});
	});
	let l = new n().setFromObject(e).getSize(new g());
	return {
		scene: e,
		meshes: i,
		materials: r,
		summary: {
			meshCount: i.length,
			materialCount: r.length,
			vertexCount: o,
			triangleCount: s,
			dimensions: F(l)
		}
	};
}
//#endregion
//#region src/engine/loaders/loadJewelryAsset.ts
async function ce(e) {
	let t = await new v().loadAsync(e);
	return {
		...se(t.scene),
		sourceUrl: e,
		animations: t.animations.length
	};
}
//#endregion
//#region src/engine/analyzer/classifyJewelryAsset.ts
var le = [
	"diamond",
	"gem",
	"gems",
	"stone",
	"brilliant",
	"crystal"
], ue = [
	"pave",
	"pavé",
	"accent",
	"side",
	"melee"
], de = [
	"gold",
	"silver",
	"platinum",
	"metal",
	"ring",
	"band",
	"shank"
], fe = [
	"prong",
	"claw",
	"setting",
	"head",
	"basket"
];
function I(e, t) {
	let n = e.materialIndices.map((e) => t.materials[e]?.name ?? "").join(" ");
	return `${e.name} ${e.parentName ?? ""} ${e.path} ${n}`.toLowerCase();
}
function L(e, t) {
	return t.some((t) => e.includes(t));
}
function pe(e) {
	let t = [...e.dimensions].map(Math.abs).sort((e, t) => t - e);
	return [
		t[0] ?? 0,
		t[1] ?? 0,
		t[2] ?? 0
	];
}
function R(e) {
	let [t, n, r] = pe(e);
	return t <= 0 || n <= 0 ? 0 : Math.max(0, Math.min(1, n / t * .7 + r / n * .3));
}
function z(e) {
	let [t, n] = pe(e);
	return n <= 0 ? Infinity : t / n;
}
function me(e, t) {
	let n = e.dimensions.reduce((e, t) => e * Math.max(Math.abs(t), 1e-6), 1), r = t.summary.dimensions.reduce((e, t) => e * Math.max(Math.abs(t), 1e-6), 1);
	return Math.min(1, n / r);
}
function he(e) {
	let [t, n, r] = e.worldPosition;
	return Math.sqrt(t * t + n * n + r * r);
}
function ge(e, t) {
	let n = I(e, t), r = R(e) * .7;
	return e.name.trim().toLowerCase() === "diamond" ? r += .18 : n.includes("diamond") && (r += .1), L(n, ue) && (r -= .3), z(e) > 2.2 && (r -= Math.min(.4, (z(e) - 2.2) * .12)), r;
}
function _e(e, t) {
	let n = R(e), r = z(e), i = me(e, t), a = he(e), o = [];
	return n >= .72 && r <= 1.55 ? (o.push(`anonymous compact geometry (${Math.round(n * 100)}% compactness) is consistent with a dominant gemstone`), o.push("geometry-only fallback used because mesh/material names are generic"), {
		meshId: e.id,
		meshName: e.name,
		classification: "CENTER_STONE",
		confidence: Math.min(.82, .58 + n * .24),
		reasons: o
	}) : r >= 1.65 || i >= .28 ? (o.push(`anonymous geometry spans the asset (${r.toFixed(1)}× aspect, ${Math.round(i * 100)}% bounding volume)`), o.push("geometry-only fallback treats the extended structural mesh as jewelry metal"), {
		meshId: e.id,
		meshName: e.name,
		classification: "METAL",
		confidence: Math.min(.78, .57 + Math.min(r / 5, .16) + Math.min(i, .05)),
		reasons: o
	}) : (o.push(`generic mesh remains ambiguous (compactness ${Math.round(n * 100)}%, radial distance ${a.toFixed(2)})`), {
		meshId: e.id,
		meshName: e.name,
		classification: "UNKNOWN",
		confidence: .4,
		reasons: o
	});
}
function ve(e, t = {}) {
	let n = e.meshes.filter((t) => L(I(t, e), le)).map((t) => ({
		mesh: t,
		score: ge(t, e)
	})).sort((e, t) => t.score - e.score)[0]?.mesh.id, r = e.meshes.map((r) => {
		let i = I(r, e), a = [], o = Object.hasOwn(t, r.name) ? t[r.name] : void 0;
		if (o) return {
			meshId: r.id,
			meshName: r.name,
			classification: o,
			confidence: 1,
			reasons: ["explicit verified asset semantic metadata"]
		};
		if (L(i, fe)) return a.push("name or material suggests a setting/prong component"), {
			meshId: r.id,
			meshName: r.name,
			classification: "SETTING",
			confidence: .9,
			reasons: a
		};
		if (L(i, le)) {
			let e = R(r), t = z(r);
			return r.id === n ? (a.push(`compact gemstone geometry (${Math.round(e * 100)}% compactness) ranks highest as the dominant stone`), r.name.trim().toLowerCase() === "diamond" && a.push("mesh name directly identifies a diamond"), {
				meshId: r.id,
				meshName: r.name,
				classification: "CENTER_STONE",
				confidence: Math.min(.97, .72 + e * .22),
				reasons: a
			}) : (a.push(t > 2.2 ? `gemstone mesh is spatially distributed/elongated (${t.toFixed(1)}× aspect), consistent with pavé or accent stones` : "gemstone-like mesh ranks below the dominant compact center-stone candidate"), {
				meshId: r.id,
				meshName: r.name,
				classification: "ACCENT_STONE",
				confidence: t > 2.2 ? .93 : .82,
				reasons: a
			});
		}
		return L(i, de) ? (a.push("name or material suggests jewelry metal"), {
			meshId: r.id,
			meshName: r.name,
			classification: "METAL",
			confidence: .9,
			reasons: a
		}) : _e(r, e);
	}), i = r.filter((t) => t.classification === "CENTER_STONE" && !L(I(e.meshes.find((e) => e.id === t.meshId), e), le));
	if (i.length > 1) {
		let t = i.map((t) => ({
			part: t,
			mesh: e.meshes.find((e) => e.id === t.meshId)
		})).sort((e, t) => R(t.mesh) - R(e.mesh) || t.mesh.triangleCount - e.mesh.triangleCount), n = t[0]?.part.meshId;
		for (let e of t.slice(1)) {
			let t = r.findIndex((t) => t.meshId === e.part.meshId);
			r[t] = {
				...r[t],
				classification: "METAL",
				confidence: .62,
				reasons: ["another anonymous compact mesh ranks higher as the center stone", "fallback assigns this remaining structural mesh to jewelry metal"]
			};
		}
		if (n) {
			let e = r.findIndex((e) => e.meshId === n);
			r[e] = {
				...r[e],
				reasons: [...r[e].reasons, "highest-ranked anonymous compact mesh retained as center stone"]
			};
		}
	}
	return { parts: r };
}
//#endregion
//#region src/engine/analyzer/validateBenchmark02.ts
var ye = Object.freeze({
	diamonds: 51,
	prongs: 100,
	metal: 20,
	total: 171
});
function be(e, t) {
	let n = new Set(e.meshes.map((e) => e.id)), r = new Set(t.parts.map((e) => e.meshId)), i = {
		diamonds: 0,
		prongs: 0,
		metal: 0,
		total: e.meshes.length
	}, a = [];
	(n.size !== e.meshes.length || r.size !== t.parts.length || r.size !== n.size || [...r].some((e) => !n.has(e))) && a.push("Classification must cover every source mesh exactly once."), e.summary.meshCount !== e.meshes.length && a.push("Mesh summary disagrees with source meshes.");
	for (let e of t.parts) switch (e.classification) {
		case "CENTER_STONE":
		case "ACCENT_STONE":
			i.diamonds++;
			break;
		case "SETTING":
			i.prongs++;
			break;
		case "METAL":
			i.metal++;
			break;
		default: a.push(`Unclassified mesh: ${e.meshName}`);
	}
	for (let e of [
		"diamonds",
		"prongs",
		"metal",
		"total"
	]) i[e] !== ye[e] && a.push(`${e}: expected ${ye[e]}, received ${i[e]}`);
	return {
		passed: a.length === 0,
		counts: i,
		errors: a
	};
}
//#endregion
//#region src/engine/renderer/JewelryRenderer.ts
function B(e) {
	let t = /* @__PURE__ */ new Set(), n = /* @__PURE__ */ new Set(), r = /* @__PURE__ */ new Set();
	e.traverse((e) => {
		if (e instanceof a) {
			t.add(e.geometry);
			for (let t of Array.isArray(e.material) ? e.material : [e.material]) {
				n.add(t);
				for (let e of Object.values(t)) e instanceof h && r.add(e);
			}
		}
	}), r.forEach((e) => e.dispose()), n.forEach((e) => e.dispose()), t.forEach((e) => e.dispose()), e.removeFromParent();
}
var xe = class e {
	options;
	scene = new f();
	camera = new l(36, 1, .01, 1e3);
	target = new g();
	current = null;
	revision = 0;
	disposed = !1;
	loader;
	constructor(e) {
		this.options = e, this.loader = e.loadAsset ?? ce, this.camera.position.set(3, 2, 4), this.camera.lookAt(this.target);
	}
	static forCanvas(t) {
		return new e({ backend: new _({
			canvas: t,
			antialias: !0
		}) });
	}
	get model() {
		return this.current;
	}
	assertActive() {
		if (this.disposed) throw Error("JewelryRenderer is disposed.");
	}
	async load(e, t = {}) {
		this.assertActive();
		let n = ++this.revision, r = await this.loader(e);
		try {
			if (this.disposed || n !== this.revision) throw Error("Model load superseded or renderer disposed.");
			let e = ve(r, t.verifiedRoles);
			if (t.validateBenchmark02) {
				let t = be(r, e);
				if (!t.passed) throw Error(`Benchmark 02 regression: ${t.errors.join("; ")}`);
			}
			let i = {
				asset: r,
				analysis: e
			};
			return this.current && B(this.current.asset.scene), this.scene.add(r.scene), this.current = i, this.focus(), i;
		} catch (e) {
			throw B(r.scene), e;
		}
	}
	focus() {
		if (this.assertActive(), !this.current) return;
		let e = new n().setFromObject(this.current.asset.scene);
		if (e.isEmpty()) return;
		let t = e.getBoundingSphere(new m()), r = Math.max(t.radius, .001), i = this.camera.getEffectiveFOV() * Math.PI / 360, a = Math.atan(Math.tan(i) * this.camera.aspect), o = r * 1.1 / Math.sin(Math.min(i, a)), s = this.camera.position.clone().sub(this.target);
		s.lengthSq() === 0 && s.set(3, 2, 4), this.target.copy(t.center), this.camera.position.copy(s.normalize().multiplyScalar(o).add(this.target)), this.camera.near = Math.max(r / 1e3, 1e-6), this.camera.far = o + r * 3, this.camera.lookAt(this.target), this.camera.updateProjectionMatrix(), this.camera.updateMatrixWorld();
	}
	resize(e, t) {
		if (this.assertActive(), !Number.isFinite(e) || !Number.isFinite(t) || e <= 0 || t <= 0) throw Error("Renderer dimensions must be finite and positive.");
		this.camera.aspect = e / t, this.camera.updateProjectionMatrix(), this.options.backend.setSize(e, t, !1), this.focus();
	}
	render() {
		this.assertActive(), this.options.backend.render(this.scene, this.camera);
	}
	unload() {
		this.assertActive(), ++this.revision, this.current && B(this.current.asset.scene), this.current = null;
	}
	dispose() {
		this.disposed || (this.unload(), this.disposed = !0, this.scene.clear(), this.options.backend.dispose());
	}
}, Se = Object.freeze(Object.fromEntries(Array.from({ length: 20 }, (e, t) => [`object_${t + 1}`, "METAL"])));
//#endregion
//#region src/engine/assets/consumers.ts
function V(e) {
	return Object.freeze({
		list: () => Object.freeze(e.list().filter((e) => e.category !== "stone")),
		resolve: (t) => {
			let n = e.require(t);
			if (n.category === "stone") throw new T("WRONG_CATEGORY", `Asset ${t} is a stone, not Boutique jewelry.`, t);
			return n;
		}
	});
}
function H(e) {
	return Object.freeze({
		list: () => e.list("stone"),
		resolve: (t) => e.require(t, "stone")
	});
}
//#endregion
//#region src/engine/stones/catalog.ts
function U(e, t) {
	if (!e) throw Error(`Stone catalog: ${t}`);
}
var W = (e) => Number.isFinite(e) && e > 0;
function G(e) {
	let t = /* @__PURE__ */ new Map();
	for (let n of e) U(n.id.trim() && n.name.trim(), "empty identity"), U(!t.has(n.id), `duplicate ID ${n.id}`), t.set(n.id, n);
	return t;
}
function Ce(e) {
	if (e && typeof e == "object") {
		for (let t of Object.values(e)) Ce(t);
		Object.freeze(e);
	}
	return e;
}
var K = (e) => e.normalize("NFKD").replace(/[\u0300-\u036f]/g, "").toLowerCase();
function we(e) {
	U(e.schemaVersion === 1, "unsupported schema version"), U(Number.isInteger(e.revision) && e.revision > 0, "invalid revision");
	let t = Ce(structuredClone(e)), n = G(t.gemTypes), r = G(t.opticalProfiles), i = G(t.cuts), a = G(t.assets), o = G(t.stones);
	for (let e of n.values()) U(r.get(e.defaultOpticalProfileId)?.gemTypeId === e.id, `invalid default optics for ${e.id}`);
	for (let e of r.values()) {
		U(n.has(e.gemTypeId), `unknown gem for ${e.id}`);
		let t = e.refractiveIndex;
		t.kind !== "unknown" && (U(W(t.wavelengthNm), `invalid wavelength for ${e.id}`), U((t.kind === "isotropic" ? [t.n] : t.kind === "uniaxial" ? [t.ordinary, t.extraordinary] : [
			t.alpha,
			t.beta,
			t.gamma
		]).every((e) => Number.isFinite(e) && e >= 1), `invalid refractive index for ${e.id}`)), U(e.abbeNumber === void 0 || W(e.abbeNumber), `invalid dispersion for ${e.id}`);
		for (let n of e.spectralIndices ?? []) {
			let r = t.kind === "isotropic" ? ["isotropic"] : t.kind === "uniaxial" ? ["ordinary", "extraordinary"] : t.kind === "biaxial" ? [
				"alpha",
				"beta",
				"gamma"
			] : [];
			U(W(n.wavelengthNm) && Number.isFinite(n.n) && n.n >= 1 && r.includes(n.axis), `invalid spectral sample for ${e.id}`);
		}
		for (let t of e.absorption ?? []) U(W(t.wavelengthNm) && Number.isFinite(t.coefficientPerMillimeter) && t.coefficientPerMillimeter >= 0, `invalid absorption for ${e.id}`);
	}
	for (let e of a.values()) U(i.has(e.cutId), `unknown cut for ${e.id}`), U(/^[a-f0-9]{64}$/i.test(e.sha256), `invalid asset hash for ${e.id}`), U(e.url.startsWith("/") && !e.url.startsWith("//") || e.url.startsWith("https://"), `invalid asset URL for ${e.id}`), U(e.dimensions.length === 3 && e.dimensions.every(W) && W(e.coordinates.referenceSize), `invalid asset scale for ${e.id}`), U(Math.abs(e.dimensions[{
		x: 0,
		y: 1,
		z: 2
	}[e.coordinates.referenceAxis]] - e.coordinates.referenceSize) < 1e-6, `reference size disagrees with dimensions for ${e.id}`), U([
		e.revision,
		e.byteLength,
		e.meshCount,
		e.triangleCount
	].every((e) => Number.isInteger(e) && e > 0), `invalid asset counts for ${e.id}`);
	let s = /* @__PURE__ */ new Set();
	for (let e of o.values()) {
		U(Number.isInteger(e.number) && e.number > 0 && !s.has(e.number), `invalid or duplicate stone number ${e.number}`), s.add(e.number);
		let t = n.get(e.gemTypeId);
		U(t && i.has(e.cutId), `unknown gem or cut for ${e.id}`), U(r.get(e.opticalProfileId ?? t.defaultOpticalProfileId)?.gemTypeId === t.id, `incompatible optics for ${e.id}`), e.geometry && U(a.get(e.geometry.assetId)?.cutId === e.cutId, `missing or incompatible geometry for ${e.id}`), U(e.caratWeight === void 0 || W(e.caratWeight), `invalid carat weight for ${e.id}`);
		let { min: o, initial: c, max: l } = e.presentation.zoom;
		U([
			o,
			c,
			l
		].every(W) && o <= c && c <= l, `invalid zoom for ${e.id}`);
		let u = e.presentation.rotation.initialQuaternion;
		U(u.length === 4 && u.every(Number.isFinite) && Math.abs(Math.hypot(...u) - 1) < 1e-6, `invalid orientation for ${e.id}`);
	}
	function c(e) {
		let t = o.get(e);
		U(t, `unknown stone ${e}`);
		let s = n.get(t.gemTypeId);
		return Object.freeze({
			stone: t,
			gemType: s,
			cut: i.get(t.cutId),
			opticalProfile: r.get(t.opticalProfileId ?? s.defaultOpticalProfileId),
			asset: t.geometry ? a.get(t.geometry.assetId) : void 0
		});
	}
	function l(e = {}) {
		let n = K(e.text ?? "").split(/\s+/).filter(Boolean);
		return Object.freeze(t.stones.filter((t) => {
			let { gemType: r, cut: i } = c(t.id), a = [
				...t.tags,
				...r.tags,
				...i.tags
			].map(K), o = K([
				t.id,
				`Stone #${String(t.number).padStart(3, "0")}`,
				t.name,
				t.description,
				...t.aliases,
				r.id,
				r.name,
				r.species ?? "",
				r.variety ?? "",
				r.category,
				...r.aliases,
				i.id,
				i.name,
				i.outline,
				i.family,
				i.frequency,
				i.finish,
				...i.aliases,
				...a,
				...t.identity.identifiers.map((e) => `${e.scheme} ${e.value}`)
			].join(" "));
			return n.every((e) => o.includes(e)) && (!e.gemTypeIds || e.gemTypeIds.includes(r.id)) && (!e.cutIds || e.cutIds.includes(i.id)) && (!e.categories || e.categories.includes(r.category)) && (!e.cutFrequencies || e.cutFrequencies.includes(i.frequency)) && (!e.tags || e.tags.every((e) => a.includes(K(e)))) && (e.geometryAvailable === void 0 || !!t.geometry === e.geometryAvailable);
		}).sort((e, t) => e.number - t.number));
	}
	return Object.freeze({
		document: t,
		getStone: (e) => o.get(e),
		resolve: c,
		search: l,
		select: (e) => e.kind === "by-id" ? Object.freeze([c(e.stoneId).stone]) : l(e.query)
	});
}
//#endregion
//#region src/engine/stones/stone001.ts
var q = {
	schemaVersion: 1,
	revision: 1,
	gemTypes: [{
		id: "gem:diamond",
		name: "Diamond",
		description: "Diamond gem type.",
		aliases: [],
		tags: ["diamond"],
		metadata: {},
		category: "precious",
		species: "diamond",
		defaultOpticalProfileId: "optics:diamond-ames-v1"
	}],
	opticalProfiles: [{
		id: "optics:diamond-ames-v1",
		name: "Existing AMES diamond approximation",
		description: "Catalog snapshot of existing optical constants; does not configure a renderer.",
		aliases: [],
		tags: [],
		metadata: {},
		gemTypeId: "gem:diamond",
		refractiveIndex: {
			kind: "isotropic",
			wavelengthNm: 587.6,
			n: 2.417
		},
		abbeNumber: 55.3,
		spectralIndices: [
			{
				wavelengthNm: 656.3,
				n: 2.407,
				axis: "isotropic"
			},
			{
				wavelengthNm: 587.6,
				n: 2.417,
				axis: "isotropic"
			},
			{
				wavelengthNm: 486.1,
				n: 2.451,
				axis: "isotropic"
			}
		],
		phenomena: [],
		evidence: {
			kind: "existing-engine-approximation",
			sources: ["src/engine/diamond-core/diamondOptics.ts"],
			notes: "Approximate RGB indices, not a certified measured spectrum. Missing absorption/phenomena data does not imply zero absorption or absence of effects."
		}
	}],
	cuts: [{
		id: "cut:round-brilliant",
		name: "Round brilliant",
		description: "Round outline with brilliant-style faceting.",
		aliases: ["round brilliant cut", "round diamond"],
		tags: ["round", "brilliant"],
		metadata: {},
		outline: "round",
		family: "brilliant",
		frequency: "common",
		finish: "faceted"
	}],
	assets: [{
		id: "geometry:round-brilliant-blender-v1",
		revision: 1,
		name: "AMES canonical round brilliant GLB",
		description: "Existing convex Blender specimen with preserved individual facets.",
		aliases: [],
		tags: ["canonical", "blender"],
		metadata: {
			opticalFacets: 57,
			girdleFacets: 128,
			exportedVertices: 960,
			tableRatio: .53,
			crownDegrees: 34.5,
			pavilionDegrees: 40.75,
			depthRatio: .6123385885288463,
			sourceBlend: "/models/canonical/ames_round_brilliant_v1.blend",
			analyticReference: "AMES-SG-round-brilliant-v1"
		},
		cutId: "cut:round-brilliant",
		format: "glb",
		url: "/models/canonical/ames_round_brilliant_v1.glb",
		sha256: "4788a83ad653aa6e6e357f304605ad786c04279ce7a2b6dbf8f73d5eec89965b",
		byteLength: 30964,
		dimensions: [
			1,
			.6123385885288463,
			1
		],
		coordinates: {
			units: "normalized",
			upAxis: "+Y",
			origin: "girdle-center",
			referenceAxis: "x",
			referenceSize: 1
		},
		meshCount: 1,
		triangleCount: 590,
		preserveFacetNormals: !0,
		geometryAcceptance: {
			status: "passed",
			sources: ["/models/canonical/ames_round_brilliant_v1.validation.json"],
			notes: "Convex, manifold, planar facets, outward normals and exported buffers validated. Girdle is a 128-sided approximation."
		}
	}],
	stones: [{
		id: "stone-001",
		number: 1,
		name: "AMES Canonical Round Brilliant",
		description: "Stone #001 — virtual canonical diamond test specimen, not a certified physical stone.",
		aliases: [
			"Stone #001",
			"Stone 001",
			"AMES round brilliant"
		],
		tags: ["canonical", "test-asset"],
		metadata: {},
		gemTypeId: "gem:diamond",
		cutId: "cut:round-brilliant",
		identity: {
			kind: "canonical-test",
			origin: "virtual",
			identifiers: [{
				scheme: "AMES",
				value: "001",
				issuer: "AMES",
				verified: !0
			}]
		},
		geometry: {
			assetId: "geometry:round-brilliant-blender-v1",
			representation: "canonical-test"
		},
		presentation: {
			rotation: {
				enabled: !0,
				initialQuaternion: [
					0,
					0,
					0,
					1
				]
			},
			zoom: {
				enabled: !0,
				min: 1.5,
				initial: 2.524,
				max: 4
			}
		},
		acceptance: {
			visual: {
				status: "failed",
				sources: ["docs/CANONICAL_DIAMOND_ACCEPTANCE.md", "docs/FLY_HDRI_AB.md"],
				notes: "Current rendering paths do not meet realism/fire acceptance."
			},
			performance: {
				status: "failed",
				sources: ["docs/CANONICAL_DIAMOND_ACCEPTANCE.md", "docs/FLY_HDRI_AB.md"],
				notes: "480x480 Intel Gen11 measurements below the 55 FPS minimum. Catalog registration is not production approval."
			}
		}
	}]
}, J = [
	{
		id: "stone-002",
		number: 2,
		name: "Oval Brilliant",
		cutId: "cut:oval-brilliant",
		slug: "oval-brilliant",
		outline: "oval",
		family: "brilliant",
		stem: "ames_oval_brilliant_v1",
		dimensions: [
			1,
			.6121938079595566,
			1.600000023841858
		],
		sha256: "e64462ba9de47dfd570ff927fa5104eb1a5d65c111e51aa665a81f0c881cec09",
		bytes: 12304,
		triangles: 174,
		facets: 89,
		opticalFacets: 57,
		girdleFacets: 32,
		exportedVertices: 352,
		tableRatio: .6000000238418579,
		lengthWidthRatio: 1.600000023841858,
		depthRatio: .6121938079595566,
		source: "JewelCraft 3.0.0 assets/gems/gems.blend: Oval"
	},
	{
		id: "stone-003",
		number: 3,
		name: "Emerald Cut",
		cutId: "cut:emerald-cut",
		slug: "emerald-cut",
		outline: "cut-corner rectangle",
		family: "step",
		stem: "ames_emerald_cut_v1",
		dimensions: [
			1,
			.6532910317182541,
			1.4000011682510376
		],
		sha256: "7567dea2c20c3412ea634d263363520283cdf25e37b628021afb0dfa5b6f0f22",
		bytes: 8904,
		triangles: 112,
		facets: 57,
		opticalFacets: 49,
		girdleFacets: 8,
		exportedVertices: 226,
		tableRatio: .6249999403953552,
		lengthWidthRatio: 1.4000011682510376,
		depthRatio: .6532910317182541,
		source: "JewelCraft 3.0.0 assets/gems/gems.blend: Emerald"
	},
	{
		id: "stone-004",
		number: 4,
		name: "Pear Brilliant",
		cutId: "cut:pear-brilliant",
		slug: "pear-brilliant",
		outline: "pear",
		family: "brilliant",
		stem: "ames_pear_brilliant_v1",
		dimensions: [
			1,
			.6121938079595566,
			1.600000023841858
		],
		sha256: "a1c5236ae2517336f92cc032caf0b98d5c038f964040fe3dea83094cbd36f2f3",
		bytes: 12196,
		triangles: 172,
		facets: 88,
		opticalFacets: 56,
		girdleFacets: 32,
		exportedVertices: 348,
		tableRatio: .6000000238418579,
		lengthWidthRatio: 1.600000023841858,
		depthRatio: .6121938079595566,
		source: "JewelCraft 3.0.0 assets/gems/gems.blend: Pear"
	},
	{
		id: "stone-005",
		number: 5,
		name: "Asscher Cut",
		cutId: "cut:asscher-cut",
		slug: "asscher-cut",
		outline: "cut-corner square",
		family: "step",
		stem: "ames_asscher_cut_v1",
		dimensions: [
			1,
			.7000000029802322,
			1
		],
		sha256: "a2b1b153938a37c42d3486909dc872e18e88cd8d7ff4c3f2ef39b187cc5284f7",
		bytes: 8784,
		triangles: 110,
		facets: 57,
		opticalFacets: 49,
		girdleFacets: 8,
		exportedVertices: 224,
		tableRatio: .5500388741493225,
		lengthWidthRatio: 1,
		depthRatio: .7000000029802322,
		source: "JewelCraft 3.0.0 assets/gems/gems.blend: Asscher"
	}
], Te = J.map((e) => ({
	id: e.cutId,
	name: e.name,
	description: `Canonical ${e.name.toLowerCase()} diamond cut.`,
	aliases: e.id === "stone-005" ? ["square emerald cut", "Asscher"] : [e.name.toLowerCase()],
	tags: [e.outline, e.family],
	metadata: {},
	outline: e.outline,
	family: e.family,
	frequency: "common",
	finish: "faceted"
})), Ee = J.map((e) => ({
	id: `geometry:${e.slug}-blender-v1`,
	revision: 1,
	cutId: e.cutId,
	name: `AMES canonical ${e.name} GLB`,
	description: "Convex, manifold canonical diamond geometry validated in Blender before export.",
	aliases: [],
	tags: ["canonical", "blender"],
	format: "glb",
	url: `/models/canonical/${e.stem}.glb`,
	sha256: e.sha256,
	byteLength: e.bytes,
	dimensions: e.dimensions,
	coordinates: {
		units: "normalized",
		upAxis: "+Y",
		origin: "girdle-center",
		referenceAxis: "x",
		referenceSize: 1
	},
	meshCount: 1,
	triangleCount: e.triangles,
	preserveFacetNormals: !0,
	metadata: {
		source: e.source,
		sourcePackageLicense: "GPL-3.0-or-later",
		sourceNotice: "docs/CANONICAL_FANCY_CUTS.md",
		sourceBlend: `/models/canonical/${e.stem}.blend`,
		facets: e.facets,
		opticalFacets: e.opticalFacets,
		girdleFacets: e.girdleFacets,
		exportedVertices: e.exportedVertices,
		tableWidthRatio: e.tableRatio,
		lengthWidthRatio: e.lengthWidthRatio,
		depthWidthRatio: e.depthRatio
	},
	geometryAcceptance: {
		status: "passed",
		sources: [`/models/canonical/${e.stem}.validation.json`],
		notes: "Connected, watertight, convex, planar facets, outward normals; GLB triangle buffers and welded topology validated."
	}
})), De = J.map((e) => ({
	id: e.id,
	number: e.number,
	name: `AMES Canonical ${e.name}`,
	description: `Stone #${String(e.number).padStart(3, "0")} — virtual canonical diamond test specimen.`,
	aliases: [
		`Stone #${String(e.number).padStart(3, "0")}`,
		`Stone ${String(e.number).padStart(3, "0")}`,
		e.name
	],
	tags: ["canonical", "test-asset"],
	metadata: {},
	gemTypeId: "gem:diamond",
	cutId: e.cutId,
	opticalProfileId: "optics:diamond-ames-v1",
	identity: {
		kind: "canonical-test",
		origin: "virtual",
		identifiers: [{
			scheme: "AMES",
			value: String(e.number).padStart(3, "0"),
			issuer: "AMES",
			verified: !0
		}]
	},
	geometry: {
		assetId: `geometry:${e.slug}-blender-v1`,
		representation: "canonical-test"
	},
	presentation: {
		rotation: {
			enabled: !0,
			initialQuaternion: [
				0,
				0,
				0,
				1
			]
		},
		zoom: {
			enabled: !0,
			min: 1.5,
			initial: 3,
			max: 5
		}
	},
	acceptance: {
		visual: {
			status: "unreviewed",
			sources: [],
			notes: "Geometry-only milestone; no browser visual acceptance claimed."
		},
		performance: {
			status: "unreviewed",
			sources: [],
			notes: "Low triangle count does not establish rendering performance acceptance."
		}
	}
})), Oe = we({
	...q,
	revision: 2,
	cuts: [...q.cuts, ...Te],
	assets: [...q.assets, ...Ee],
	stones: [...q.stones, ...De]
}), ke = {
	schemaVersion: 1,
	assets: [
		"stone-001",
		"stone-002",
		"stone-003",
		"stone-004",
		"stone-005"
	].map((e) => {
		let t = Oe.resolve(e);
		return {
			id: e,
			name: t.stone.name,
			category: "stone",
			assetPath: t.asset.url,
			previewPath: null,
			materialSlots: [{
				id: "gem",
				kind: "gem"
			}],
			stoneReferences: [t.stone.id],
			metalCompatibility: [],
			accessTier: "public",
			tags: [.../* @__PURE__ */ new Set([
				...t.stone.tags,
				"canonical-test",
				"diamond"
			])],
			status: "validated"
		};
	})
}, Ae = M(ke);
//#endregion
//#region src/engine/assets/loadGlbAsset.ts
async function je(e, t = ce) {
	j(e);
	try {
		return await t(e);
	} catch (t) {
		throw new T("GLB_LOAD_FAILED", `Unable to load GLB ${e}: ${String(t)}`, void 0, e, { cause: t });
	}
}
//#endregion
//#region src/engine/assets/batch.ts
function Me(e) {
	return Object.freeze({
		registry: e,
		versions: Object.freeze({})
	});
}
function Y(e) {
	throw Error(`Catalog ingestion: ${e}`);
}
async function Ne(e, t, n) {
	let r = n.concurrency ?? 4, i = n.timeoutMs ?? 15e3;
	(!Number.isInteger(r) || r < 1 || r > 16 || !Number.isFinite(i) || i < 1) && Y("invalid worker limits");
	let a = M({
		schemaVersion: 1,
		assets: t.map((e) => e.asset)
	}), o = Object.assign(Object.create(null), e.versions), s = new Map(e.registry.list().map((e) => [e.id, e])), c = /* @__PURE__ */ new Map(), l = /* @__PURE__ */ new Map(), u = new Set(a.list().map((e) => e.id));
	for (let t of e.registry.list()) if (!u.has(t.id)) {
		l.set(t.assetPath, t.id);
		let n = e.versions[t.id];
		n && c.set(n.sha256, t.id);
	}
	for (let n = 0; n < t.length; n++) {
		let r = a.list()[n], i = t[n].version, s = e.versions[r.id];
		(!i || !Number.isSafeInteger(i.revision) || i.revision < 1 || !/^[a-f0-9]{64}$/.test(i.sha256) || !Number.isSafeInteger(i.byteLength) || i.byteLength < 20) && Y(`invalid version: ${r.id}`), e.registry.get(r.id) && !s && Y(`unversioned existing asset cannot be overwritten: ${r.id}`), s && (i.revision <= s.revision || i.sha256 === s.sha256 || r.assetPath === e.registry.require(r.id).assetPath) && Y(`version must advance with new bytes and path: ${r.id}`), (l.has(r.assetPath) || c.has(i.sha256)) && Y(`duplicate path or content: ${r.id}`), !["PUBLIC", "public"].includes(r.accessTier) && /^\/(?:models|assets)\//.test(r.assetPath) && Y(`protected asset uses a public static path: ${r.id}`), l.set(r.assetPath, r.id), c.set(i.sha256, r.id), o[r.id] = Object.freeze({ ...i });
	}
	let d = new AbortController(), f = () => d.abort(n.signal?.reason);
	n.signal?.addEventListener("abort", f, { once: !0 }), n.signal?.aborted && f();
	let p = 0;
	async function m() {
		for (; p < a.list().length;) {
			d.signal.throwIfAborted();
			let e = a.list()[p++], t = o[e.id], r = AbortSignal.any([d.signal, AbortSignal.timeout(i)]), c;
			try {
				let i = (async () => {
					let i = await n.probe(e, r);
					r.throwIfAborted(), (i.byteLength !== t.byteLength || i.sha256 !== t.sha256) && Y(`broken or changed GLB: ${e.id}`);
					let a = n.preview ? await n.preview(e, r) : e.previewPath;
					return r.throwIfAborted(), M({
						schemaVersion: 1,
						assets: [{
							...e,
							previewPath: a
						}]
					}).require(e.id);
				})(), a = new Promise((e, t) => {
					c = () => t(r.reason), r.addEventListener("abort", c, { once: !0 }), r.aborted && c();
				});
				s.set(e.id, await Promise.race([i, a]));
			} finally {
				c && r.removeEventListener("abort", c);
			}
		}
	}
	try {
		return await Promise.all(Array.from({ length: Math.min(r, t.length) }, m)), d.signal.throwIfAborted(), Object.freeze({
			registry: M({
				schemaVersion: 1,
				assets: [...s.values()]
			}),
			versions: Object.freeze(o)
		});
	} catch (e) {
		throw d.abort(e), e;
	} finally {
		n.signal?.removeEventListener("abort", f);
	}
}
function Pe(e = fetch, t = 33554432) {
	return (!Number.isSafeInteger(t) || t < 20) && Y("invalid GLB size limit"), async (n, r) => {
		let i = await e(n.assetPath, {
			signal: r,
			cache: "no-store",
			redirect: "error",
			credentials: "same-origin"
		});
		(!i.ok || !i.body) && Y(`GLB unavailable: ${n.id}`);
		let a = i.body.getReader(), o = [], s = 0;
		try {
			for (;;) {
				r.throwIfAborted();
				let { done: e, value: i } = await a.read();
				if (e) break;
				s += i.length, s > t && Y(`GLB exceeds size limit: ${n.id}`), o.push(i);
			}
		} finally {
			await a.cancel().catch(() => {}), a.releaseLock();
		}
		let c = new Uint8Array(s), l = 0;
		for (let e of o) c.set(e, l), l += e.length;
		Fe(c);
		let u = await crypto.subtle.digest("SHA-256", c);
		return {
			sha256: Array.from(new Uint8Array(u), (e) => e.toString(16).padStart(2, "0")).join(""),
			byteLength: s
		};
	};
}
function Fe(e) {
	let t = new DataView(e.buffer, e.byteOffset, e.byteLength);
	(e.length < 20 || t.getUint32(0, !0) !== 1179937895 || t.getUint32(4, !0) !== 2 || t.getUint32(8, !0) !== e.length) && Y("malformed GLB header");
	let n = 12, r, i = 0;
	for (; n < e.length;) {
		n + 8 > e.length && Y("truncated GLB chunk");
		let a = t.getUint32(n, !0), o = t.getUint32(n + 4, !0);
		if ((a % 4 || n + 8 + a > e.length) && Y("invalid GLB chunk length"), n === 12) {
			o !== 1313821514 && Y("missing GLB JSON");
			try {
				r = JSON.parse(new TextDecoder().decode(e.subarray(n + 8, n + 8 + a)));
			} catch {
				Y("invalid GLB JSON");
			}
		} else o === 5130562 && (i += a);
		n += 8 + a;
	}
	(!r || r.asset?.version !== "2.0" || !Array.isArray(r.meshes) || !r.meshes.length) && Y("GLB contains no supported mesh"), ((r.buffers ?? []).some((e) => e.uri || !Number.isSafeInteger(e.byteLength) || e.byteLength < 0 || e.byteLength > i) || (r.images ?? []).some((e) => e.uri)) && Y("GLB must embed its resources");
}
//#endregion
//#region src/engine/materials/createJewelryMetalMaterial.ts
var Ie = {
	"18K_YELLOW_GOLD": {
		label: "18K Yellow Gold",
		color: "#e8bb70",
		roughness: .18,
		metalness: 1
	},
	ROSE_GOLD: {
		label: "Rose Gold",
		color: "#b76e79",
		roughness: .2,
		metalness: 1
	},
	WHITE_GOLD: {
		label: "18K White Gold",
		color: "#d9d7d2",
		roughness: .16,
		metalness: 1
	},
	PLATINUM: {
		label: "Platinum",
		color: "#c7c9cc",
		roughness: .14,
		metalness: 1
	},
	SILVER: {
		label: "Silver",
		color: "#f2f0e9",
		roughness: .16,
		metalness: 1
	},
	RHODIUM: {
		label: "Rhodium",
		color: "#dce2ea",
		roughness: .11,
		metalness: 1
	}
}, Le = [
	["18k-yellow-gold", "18K_YELLOW_GOLD"],
	["18k-white-gold", "WHITE_GOLD"],
	["rose-gold", "ROSE_GOLD"],
	["platinum", "PLATINUM"],
	["silver", "SILVER"],
	["rhodium", "RHODIUM"]
].map(([e, t]) => {
	let n = Ie[t];
	return {
		id: `metal:${e}`,
		name: n.label,
		color: n.color,
		finishes: {
			polished: {
				roughness: n.roughness,
				anisotropy: 0
			},
			brushed: {
				roughness: .32,
				anisotropy: .45
			},
			satin: {
				roughness: .42,
				anisotropy: 0
			}
		}
	};
});
function Re(e, t = "polished") {
	let n = e.finishes[t];
	if (!n) throw Error(`Unknown metal finish: ${t}`);
	return new s({
		name: `AMES ${e.name} / ${t}`,
		color: e.color,
		metalness: 1,
		roughness: n.roughness,
		anisotropy: n.anisotropy
	});
}
//#endregion
//#region src/engine/materials/createGemstonePreviewMaterial.ts
function ze(e) {
	let t = e === "DIAMOND_CENTER";
	return new s({
		name: t ? "AMES Center Gem Preview" : "AMES Accent Gem Preview",
		color: new i(t ? "#f7fbff" : "#eef5ff"),
		transmission: t ? .82 : .68,
		thickness: t ? 1.1 : .55,
		ior: 2.417,
		roughness: t ? .045 : .075,
		metalness: 0,
		transparent: !0,
		opacity: t ? .96 : .9,
		clearcoat: 1,
		clearcoatRoughness: .03
	});
}
var Be = [{
	id: "gem:diamond",
	name: "Diamond",
	color: "#f7fbff",
	refractiveIndexRange: [2.417, 2.417],
	previewIor: 2.417,
	source: "AMES existing createGemstonePreviewMaterial / diamond optics snapshot",
	rendering: "existing-diamond-preview"
}, ...[
	[
		"ruby",
		"#b51236",
		1.762,
		1.77
	],
	[
		"sapphire",
		"#274da8",
		1.762,
		1.77
	],
	[
		"emerald",
		"#16885e",
		1.577,
		1.583
	],
	[
		"spinel",
		"#b33867",
		1.718,
		1.718
	],
	[
		"alexandrite",
		"#497f75",
		1.746,
		1.755
	],
	[
		"tanzanite",
		"#6452ad",
		1.691,
		1.7
	],
	[
		"aquamarine",
		"#83cfdf",
		1.577,
		1.583
	],
	[
		"tourmaline",
		"#328a74",
		1.624,
		1.644
	],
	[
		"topaz",
		"#8bc8e8",
		1.619,
		1.627
	],
	[
		"garnet",
		"#8b243b",
		1.714,
		1.888
	]
].map(([e, t, n, r]) => ({
	id: `gem:${e}`,
	name: e[0].toUpperCase() + e.slice(1),
	color: t,
	refractiveIndexRange: [n, r],
	previewIor: (n + r) / 2,
	source: `https://www.gia.edu/${e}`,
	rendering: "colored-gem-preview"
}))];
function Ve(e) {
	let t = ze("DIAMOND_CENTER");
	return e.rendering === "colored-gem-preview" && (t.name = `AMES ${e.name} Preview`, t.color.set(e.color), t.ior = e.previewIor), t;
}
//#endregion
//#region src/engine/material-system/registry.ts
var X = class extends Error {
	code;
	constructor(e, t) {
		super(t), this.code = e, this.name = "MaterialSystemError";
	}
};
function He(e) {
	return e && typeof e == "object" && (Object.values(e).forEach(He), Object.freeze(e)), e;
}
function Ue(e, t) {
	let n = structuredClone(e), r = structuredClone(t), i = /* @__PURE__ */ new Set();
	for (let e of [...n, ...r]) {
		if (!e.id || !e.name || !/^#[\da-f]{6}$/i.test(e.color) || i.has(e.id)) throw new X("INVALID_MATERIAL", `Invalid or duplicate material: ${e.id}`);
		i.add(e.id);
	}
	for (let e of n) {
		if (!e.id.startsWith("metal:")) throw new X("INVALID_MATERIAL", "Wrong metal ID prefix");
		for (let t of [
			"polished",
			"brushed",
			"satin"
		]) {
			let n = e.finishes[t];
			if (!n || [n.roughness, n.anisotropy].some((e) => !Number.isFinite(e) || e < 0 || e > 1)) throw new X("INVALID_MATERIAL", `Invalid finish: ${e.id}/${t}`);
		}
	}
	for (let e of r) {
		let [t, n] = e.refractiveIndexRange;
		if (!e.id.startsWith("gem:") || ![
			t,
			n,
			e.previewIor
		].every((e) => Number.isFinite(e) && e > 1) || t > n || e.previewIor < t || e.previewIor > n) throw new X("INVALID_MATERIAL", `Invalid gem optics: ${e.id}`);
	}
	return He(n), He(r), Object.freeze({
		metals: n,
		gems: r,
		metal: (e) => {
			let t = n.find((t) => t.id === e);
			if (!t) throw new X("INVALID_MATERIAL", `Unknown metal material: ${e}`);
			return t;
		},
		gem: (e) => {
			let t = r.find((t) => t.id === e);
			if (!t) throw new X("INVALID_MATERIAL", `Unknown gem material: ${e}`);
			return t;
		}
	});
}
var Z = Ue(Le, Be);
//#endregion
//#region src/engine/material-system/assignment.ts
function We(e) {
	return Object.entries({
		METAL: ["metal", "metal"],
		SETTING: ["setting", "metal"],
		CENTER_STONE: ["center-stone", "gem"],
		ACCENT_STONE: ["accent-stone", "gem"]
	}).map(([t, [n, r]]) => ({
		id: n,
		kind: r,
		meshIds: e.analysis.parts.filter((e) => e.classification === t).map((e) => e.meshId)
	})).filter((e) => e.meshIds.length);
}
var Ge = class {
	registry;
	meshes = /* @__PURE__ */ new Map();
	originals = /* @__PURE__ */ new Map();
	owned = /* @__PURE__ */ new Set();
	suspended = /* @__PURE__ */ new Map();
	disposed = !1;
	paused = !1;
	slots;
	constructor(e, t = We(e), n = Z) {
		this.registry = n, e.asset.scene.traverse((e) => {
			e instanceof a && this.meshes.set(e.uuid, e);
		}), this.slots = structuredClone(t);
		let r = /* @__PURE__ */ new Set(), i = /* @__PURE__ */ new Map();
		for (let e of this.slots) {
			if (!e.id || r.has(e.id) || !["metal", "gem"].includes(e.kind) || !e.meshIds.length || new Set(e.meshIds).size !== e.meshIds.length) throw new X("INVALID_SLOT", `Invalid semantic slot: ${e.id}`);
			r.add(e.id);
			for (let t of e.meshIds) {
				let n = this.meshes.get(t), r = i.get(t) ?? [];
				if (!n || r.some((t) => t === void 0 || e.materialIndex === void 0 || t === e.materialIndex)) throw new X("INVALID_SLOT", `Missing or overlapping slot mesh: ${t}`);
				if (e.materialIndex !== void 0 && (!Number.isInteger(e.materialIndex) || e.materialIndex < 0 || e.materialIndex >= (Array.isArray(n.material) ? n.material.length : 1))) throw new X("INVALID_SLOT", `Invalid material index: ${e.id}`);
				i.set(t, [...r, e.materialIndex]);
			}
		}
	}
	setMetal(e, t = "polished", n) {
		let r = this.registry.metal(e);
		return this.assign("metal", n, () => Re(r, t));
	}
	setGem(e, t) {
		let n = this.registry.gem(e);
		return this.assign("gem", t, () => Ve(n));
	}
	assign(e, t, n) {
		if (this.disposed || this.paused) throw Error("Material assignment is disposed or suspended.");
		let r = this.slots.filter((n) => n.kind === e && (t === void 0 || n.id === t));
		if (!r.length) throw new X(t ? "INVALID_SLOT" : "NO_TARGETS", `No ${e} targets${t ? ` in slot ${t}` : ""}.`);
		let i = r.flatMap((e) => e.meshIds.map((t) => ({
			mesh: this.meshes.get(t),
			index: e.materialIndex
		})));
		for (let { mesh: e, index: t } of i) {
			if (Array.isArray(e.material) && e.material.length > 1 && t === void 0) throw new X("INVALID_SLOT", "Multi-material meshes require explicit materialIndex slots.");
			let n = Array.isArray(e.material) ? e.material[t ?? 0] : e.material;
			if (n instanceof p || n.type === "NodeMaterial" || "isNodeMaterial" in n) throw new X("OPTICS_ADAPTER_REQUIRED", "Custom shader materials require an explicit host adapter; existing optics preserved.");
		}
		let a = n();
		this.owned.add(a);
		for (let { mesh: e, index: t } of i) if (this.originals.has(e) || this.originals.set(e, e.material), Array.isArray(e.material)) {
			let n = [...e.material];
			n[t ?? 0] = a, e.material = n;
		} else e.material = a;
		let o = /* @__PURE__ */ new Set();
		for (let e of this.originals.keys()) for (let t of Array.isArray(e.material) ? e.material : [e.material]) o.add(t);
		for (let e of this.owned) o.has(e) || (e.dispose(), this.owned.delete(e));
		return i.length;
	}
	suspend() {
		if (!(this.disposed || this.paused)) {
			this.paused = !0;
			for (let [e, t] of this.originals) this.suspended.set(e, e.material), e.material = t;
		}
	}
	resume() {
		if (!(this.disposed || !this.paused)) {
			for (let [e, t] of this.suspended) e.material = t;
			this.suspended.clear(), this.paused = !1;
		}
	}
	dispose() {
		this.disposed || (this.suspend(), this.disposed = !0, this.owned.forEach((e) => e.dispose()), this.owned.clear(), this.originals.clear(), this.suspended.clear());
	}
};
//#endregion
//#region src/engine/core/createAmesEngine.ts
function Q(e) {
	let t, n = !1, r = "none", i = 0, a = 0, o = new AbortController(), s = { ...e.hooks }, c = e.registry ?? Ae, l = e.access ? ie(c, e.access) : void 0, u = 0, d = V(c), f = H(c), p = e.materials ?? Z, m, h, g = !1;
	function _() {
		if (n) throw Error("AMES Engine is disposed.");
		if (!t) throw Error("Call AMES Engine init() first.");
		return t;
	}
	function v() {
		let e = _();
		return {
			scene: e.scene,
			camera: e.camera,
			target: e.target,
			model: e.model,
			signal: o.signal
		};
	}
	function y(e) {
		if (_(), e !== a) throw Error("AMES Engine command superseded.");
	}
	async function b(e, t = {}) {
		let s = _();
		if (typeof e != "string" || !e.trim()) throw Error("Asset URL must not be empty.");
		let c = ++a;
		g = !0, m?.suspend(), o.abort(), o = new AbortController();
		let l = e.split(/[?#]/)[0].endsWith("/benchmark_02.glb") || e.split(/[?#]/)[0] === "benchmark_02.glb";
		try {
			let n = await s.load(e, l ? {
				...t,
				validateBenchmark02: !0,
				verifiedRoles: Se
			} : t);
			return y(c), m?.dispose(), m = void 0, h = void 0, g = !1, r = "none", i = 0, n;
		} catch (e) {
			throw c === a && !n && (g = !1, m?.resume()), e;
		}
	}
	async function x(e, t) {
		if (l) throw Error("Access-controlled engines require a manifest asset ID.");
		return b(e, t);
	}
	async function S(t) {
		let n = () => ({
			status: "applied",
			command: t.type
		});
		if (t.type === "DISPOSE") return C(), n();
		switch (_(), t.type) {
			case "CHECK_ACCESS":
			case "PREVIEW_ASSET":
			case "START_SUBSCRIPTION":
				if (!l) return {
					status: "unsupported",
					command: t.type,
					reason: "Access controller not configured."
				};
				if (t.type === "CHECK_ACCESS") return {
					status: "applied",
					command: t.type,
					access: await l.check(t.assetId)
				};
				if (t.type === "PREVIEW_ASSET") return {
					status: "applied",
					command: t.type,
					access: l.preview(t.assetId)
				};
				await l.startSubscription(t.assetId);
				break;
			case "LOAD_ASSET":
				t.assetId === void 0 ? await x(t.url, t.options) : await w(t.assetId, void 0, t.options);
				break;
			case "SHOW_JEWELRY": {
				let e = t.assetId === void 0 ? t.url : d.resolve(t.assetId).assetPath, n = a + 1;
				t.assetId === void 0 ? await x(e, t.options) : await w(t.assetId, void 0, t.options), y(n), await s.boutique?.({ url: e }, v()), y(n), r = "boutique";
				break;
			}
			case "SHOW_STONE": {
				let e = t.assetId === void 0 ? f.list().find((e) => e.stoneReferences.includes(t.stoneId)) : f.resolve(t.assetId);
				if (!e) throw new T("ASSET_NOT_FOUND", `Stone asset not registered: ${t.stoneId}`, t.stoneId);
				let n = a + 1;
				await w(e.id, "stone"), y(n), await s.stoneTray?.({ stoneId: e.stoneReferences[0] }, v()), y(n), r = "stone-tray";
				break;
			}
			case "SET_METAL":
			case "SET_GEM": {
				let n = a, { type: r } = t;
				if (t.type === "SET_METAL" && s.setMetal) {
					let { type: e, ...r } = t;
					await s.setMetal(r, v()), y(n);
					break;
				}
				if (t.type === "SET_GEM" && s.setGem) {
					let { type: e, ...r } = t;
					await s.setGem(r, v()), y(n);
					break;
				}
				let i = t.type === "SET_METAL" ? t.materialId ?? {
					gold: "metal:18k-yellow-gold",
					silver: "metal:silver",
					platinum: "metal:platinum"
				}[t.metal] : t.materialId ?? t.gemTypeId;
				t.type === "SET_METAL" ? p.metal(i) : p.gem(i);
				let o = _().model;
				if (!o || g) return {
					status: "unsupported",
					command: r,
					reason: "A loaded, settled model is required for semantic assignment."
				};
				m ||= new Ge(o, e.resolveMaterialSlots?.(o, h) ?? (h?.category === "stone" && o.asset.meshes.length === 1 ? [{
					id: "gem",
					kind: "gem",
					meshIds: [o.asset.meshes[0].id]
				}] : void 0), p);
				try {
					t.type === "SET_METAL" ? m.setMetal(i, t.finish, t.slotId) : m.setGem(i, t.slotId);
				} catch (e) {
					if (e instanceof X && (e.code === "NO_TARGETS" || e.code === "OPTICS_ADAPTER_REQUIRED")) return {
						status: "unsupported",
						command: r,
						reason: e.message
					};
					throw e;
				}
				break;
			}
			case "FOCUS_COMPONENT":
			case "SET_QUALITY": {
				let e = a, n;
				if (t.type === "FOCUS_COMPONENT" && s.focusComponent) n = s.focusComponent({ componentId: t.componentId }, v());
				else if (t.type === "SET_QUALITY" && s.setQuality) n = s.setQuality({ quality: t.quality }, v());
				else return {
					status: "unsupported",
					command: t.type,
					reason: "No host adapter registered for this command."
				};
				await n, y(e);
				break;
			}
			case "START_TURNTABLE": {
				let e = t.radiansPerSecond ?? .4;
				if (!Number.isFinite(e)) throw Error("Turntable speed must be finite.");
				i = e;
				break;
			}
			case "STOP_TURNTABLE":
				i = 0;
				break;
			default: throw Error("Unknown AMES Engine command.");
		}
		return n();
	}
	function C() {
		n || (n = !0, u++, l?.dispose(), a++, i = 0, r = "none", o.abort(), m?.dispose(), m = void 0, t?.dispose());
	}
	async function w(e, t, n) {
		_();
		let r = c.require(e, t), i = ++u, a = l ? await l.authorize(e) : r.assetPath;
		if (_(), i !== u) throw Error("AMES access request superseded.");
		try {
			let e = await b(a, n);
			return h = r, e;
		} catch (t) {
			throw t instanceof T && t.code === "GLB_LOAD_FAILED" ? new T(t.code, `Asset ${e}: ${t.message}`, e, r.assetPath, { cause: t }) : t;
		}
	}
	return Object.freeze({
		registry: c,
		access: l,
		get status() {
			return n ? "disposed" : t ? "ready" : "idle";
		},
		get mode() {
			return r;
		},
		get model() {
			return t?.model ?? null;
		},
		get scene() {
			return _().scene;
		},
		get camera() {
			return _().camera;
		},
		get target() {
			return _().target;
		},
		init: () => {
			if (n) throw Error("AMES Engine is disposed.");
			t ||= new xe({
				backend: typeof e.backend == "function" ? e.backend() : e.backend,
				loadAsset: (t) => je(t, e.loadAsset)
			});
		},
		load: x,
		loadById: w,
		execute: S,
		update: (e) => {
			let t = _();
			if (!Number.isFinite(e) || e < 0) throw Error("Frame delta must be finite, nonnegative seconds.");
			let n = i * e;
			if (!Number.isFinite(n)) throw Error("Turntable rotation exceeds finite range.");
			t.model && i !== 0 && (t.model.asset.scene.rotation.y = (t.model.asset.scene.rotation.y + n % (Math.PI * 2)) % (Math.PI * 2)), t.render();
		},
		resize: (e, t) => _().resize(e, t),
		render: () => _().render(),
		dispose: C
	});
}
function Ke(e, t) {
	return Q({
		backend: () => new _({
			canvas: e,
			antialias: !0
		}),
		hooks: t
	});
}
function qe(e) {
	if (!e.access) throw Error("Access configuration is required.");
	return Q(e);
}
//#endregion
//#region src/engine/renderer/renderQuality.ts
var $ = Object.freeze({
	FAST: {
		pixelRatio: .75,
		environmentSize: 128
	},
	INTERACTIVE: {
		pixelRatio: 1,
		environmentSize: 256
	},
	HIGH: {
		pixelRatio: 1.5,
		environmentSize: 512
	},
	BEAUTY: {
		pixelRatio: 2,
		environmentSize: 1024
	}
});
//#endregion
//#region src/engine/viewer/camera.ts
function Je(e, t, r, i = !1) {
	let a = new n().setFromObject(r);
	if (a.isEmpty()) throw Error("Cannot focus an empty component.");
	let o = a.getBoundingSphere(new m()), s = Math.max(o.radius, .001), c = e.getEffectiveFOV() * Math.PI / 360, l = Math.atan(Math.tan(c) * e.aspect), u = s * 1.1 / Math.sin(Math.min(c, l)), d = i ? new g(3, 2, 4) : e.position.clone().sub(t);
	return d.lengthSq() || d.set(3, 2, 4), t.copy(o.center), e.position.copy(d.normalize().multiplyScalar(u).add(t)), e.near = Math.max(s / 1e3, 1e-6), e.far = u + s * 3, e.lookAt(t), e.updateProjectionMatrix(), e.updateMatrixWorld(), s;
}
//#endregion
//#region src/engine/viewer/stats.ts
function Ye() {
	let e = [];
	return {
		reset() {
			e.length = 0;
		},
		sample(t, n) {
			Number.isFinite(t) && t > 0 && (e.push(t), e.length > 120 && e.shift());
			let r = e.length ? e.reduce((e, t) => e + t, 0) / e.length : null;
			return Object.freeze({
				fps: r === null ? null : 1e3 / r,
				frameMs: r,
				drawCalls: n?.calls ?? null,
				triangles: n?.triangles ?? null,
				samples: e.length
			});
		}
	};
}
//#endregion
//#region src/engine/viewer/createViewerScene.ts
function Xe(e) {
	let t = !1, n = !1, r = 0, i = null, a = -Infinity, o = Object.freeze({
		status: "idle",
		assetId: null,
		requestedAssetId: null,
		error: null,
		quality: e.quality ?? "INTERACTIVE",
		turntable: !1
	}), s = /* @__PURE__ */ new Set(), c = /* @__PURE__ */ new Set(), l = Ye(), u = l.sample(0), d, f = Q({
		...e,
		hooks: {
			focusComponent: ({ componentId: e }) => {
				let t = f.model;
				if (!t) throw Error("No asset is loaded.");
				let n = t.asset.meshes.filter((t) => t.id === e || t.name === e);
				if (n.length !== 1) throw Error(`Component must identify one mesh: ${e}`);
				let r = t.asset.scene.getObjectByProperty("uuid", n[0].id);
				if (!r) throw Error(`Component not found: ${e}`);
				g(Je(f.camera, f.target, r));
			},
			setQuality: ({ quality: t }) => {
				if (!Object.hasOwn($, t)) throw Error(`Unknown quality: ${t}`);
				e.backend.setPixelRatio?.($[t].pixelRatio), p({ quality: t }), h();
			}
		}
	});
	function p(e) {
		o = Object.freeze({
			...o,
			...e
		}), s.forEach((e) => e());
	}
	function m() {
		if (t) throw Error("Viewer is disposed.");
	}
	function h() {
		i = null, a = -Infinity, l.reset(), u = l.sample(0);
	}
	function g(e) {
		d.target.copy(f.target), d.minDistance = e * .15, d.maxDistance = e * 30, d.update();
	}
	function _(e = !1) {
		f.model && g(Je(f.camera, f.target, f.model.asset.scene, e));
	}
	try {
		if (f.init(), d = e.controls(f.camera), d.target.copy(f.target), d.enablePan = !1, !Object.hasOwn($, o.quality)) throw Error(`Unknown quality: ${o.quality}`);
		e.backend.setPixelRatio?.($[o.quality].pixelRatio);
	} catch (t) {
		throw e.beforeDispose?.(), d?.dispose(), f.dispose(), t;
	}
	async function v(i) {
		if (i.type === "DISPOSE") return y(), {
			status: "applied",
			command: "DISPOSE"
		};
		if (m(), i.type === "LOAD_ASSET" || i.type === "SHOW_JEWELRY" || i.type === "SHOW_STONE") {
			let a = i.assetId ?? (i.type === "SHOW_STONE" ? f.registry.list("stone").find((e) => e.stoneReferences.includes(i.stoneId))?.id : void 0), o;
			try {
				if (!a) throw Error("Viewer load commands require a registered asset ID.");
				if (o = f.registry.require(a), i.type === "SHOW_JEWELRY" && o.category === "stone" || i.type === "SHOW_STONE" && o.category !== "stone") throw new T("WRONG_CATEGORY", `Wrong viewer category for ${a}`, a);
			} catch (e) {
				throw p({
					status: "error",
					requestedAssetId: a ?? null,
					error: String(e)
				}), e;
			}
			let s = ++r;
			p({
				status: "loading",
				requestedAssetId: a,
				error: null
			}), d.enabled = !1, h();
			try {
				let c = await f.execute(i.type === "SHOW_STONE" ? {
					type: "SHOW_STONE",
					assetId: a
				} : {
					type: i.type,
					assetId: a,
					options: i.options
				});
				if (t || s !== r) throw Error("Viewer load superseded or disposed.");
				if (p({ assetId: a }), e.applyDefaultMaterials !== !1) {
					if (o.category !== "stone" && o.metalCompatibility.length && await f.execute({
						type: "SET_METAL",
						materialId: {
							gold: "metal:18k-yellow-gold",
							silver: "metal:silver",
							platinum: "metal:platinum"
						}[o.metalCompatibility[0]]
					}), t || s !== r) throw Error("Viewer load superseded or disposed.");
					await f.execute({
						type: "SET_GEM",
						materialId: "gem:diamond"
					});
				}
				if (t || s !== r) throw Error("Viewer load superseded or disposed.");
				return d.enablePan = e.pan !== "never" && o.category !== "stone", d.enabled = !n, _(!0), h(), p({
					status: "ready",
					assetId: a,
					requestedAssetId: null,
					error: null,
					turntable: !1
				}), c;
			} catch (e) {
				throw !t && s === r && (d.enabled = !n, p({
					status: "error",
					requestedAssetId: a ?? null,
					error: String(e)
				})), e;
			}
		}
		try {
			let e = await f.execute(i);
			return m(), i.type === "START_TURNTABLE" && e.status === "applied" && p({ turntable: !0 }), i.type === "STOP_TURNTABLE" && e.status === "applied" && p({ turntable: !1 }), e;
		} catch (e) {
			throw t || p({ error: String(e) }), e;
		}
	}
	function y() {
		if (!t) {
			t = !0, r++;
			try {
				e.beforeDispose?.();
			} finally {
				d.dispose(), f.dispose(), p({
					status: "disposed",
					turntable: !1,
					requestedAssetId: null
				}), s.clear(), c.clear();
			}
		}
	}
	return Object.freeze({
		engine: f,
		materials: e.materials ?? Z,
		get paused() {
			return n;
		},
		setPaused: (e) => {
			m(), n = e, d.enabled = !n && o.status !== "loading", h();
		},
		get state() {
			return o;
		},
		get performance() {
			return u;
		},
		subscribe: (e) => (m(), s.add(e), () => {
			s.delete(e);
		}),
		subscribePerformance: (e) => (m(), c.add(e), () => {
			c.delete(e);
		}),
		loadAsset: (e) => v({
			type: "LOAD_ASSET",
			assetId: e
		}),
		execute: v,
		resetCamera: () => {
			m(), _(!0);
		},
		resize: (e, t) => {
			if (m(), !Number.isFinite(e) || !Number.isFinite(t) || e < 0 || t < 0) throw Error("Invalid viewer dimensions.");
			if (!e || !t) {
				h();
				return;
			}
			f.target.copy(d.target), f.resize(e, t), _(), h();
		},
		tick: (t) => {
			if (m(), n) {
				h();
				return;
			}
			if (!Number.isFinite(t)) throw Error("Invalid frame timestamp.");
			let r = i === null ? 0 : Math.max(0, t - i);
			if (i = t, d.update(), f.target.copy(d.target), f.update(r / 1e3), o.status !== "loading") {
				let n = l.sample(r, e.backend.statistics?.());
				t - a >= 250 && (u = n, a = t, c.forEach((e) => e()));
			}
		},
		resetPerformance: h,
		dispose: y
	});
}
//#endregion
//#region src/engine/renderer/StudioEnvironment.ts
function Ze() {
	let e = new f();
	e.add(new a(new r(24, 24, 24), new o({
		color: "#34363b",
		side: t
	})));
	for (let t of [
		{
			p: [
				-5,
				5,
				3
			],
			size: [4, 8],
			strength: 5
		},
		{
			p: [
				6,
				3,
				1
			],
			size: [2, 7],
			strength: 7
		},
		{
			p: [
				0,
				8,
				-2
			],
			size: [6, 4],
			strength: 4
		},
		{
			p: [
				-3,
				1,
				-7
			],
			size: [2, 6],
			strength: 5
		},
		{
			p: [
				1,
				1,
				8
			],
			size: [5, 3],
			strength: 1.5
		}
	]) {
		let n = new a(new u(...t.size), new o({ color: new i(1, 1, 1).multiplyScalar(t.strength) }));
		n.position.fromArray(t.p), n.lookAt(new g()), e.add(n);
	}
	return e;
}
var Qe = class e {
	target;
	disposed = !1;
	constructor(e) {
		this.target = e;
	}
	get texture() {
		return this.target.texture;
	}
	static async create(t, n = 256, r) {
		let i = new c(t);
		try {
			if (r) {
				let t = await new b().loadAsync(r);
				try {
					return new e(i.fromEquirectangular(t));
				} finally {
					t.dispose();
				}
			}
			let t = Ze();
			try {
				return new e(i.fromScene(t, 0, .1, 100, { size: n }));
			} finally {
				t.traverse((e) => {
					e instanceof a && (e.geometry.dispose(), (Array.isArray(e.material) ? e.material : [e.material]).forEach((e) => e.dispose()));
				});
			}
		} finally {
			i.dispose();
		}
	}
	attach(e, t = "#181b20") {
		if (this.disposed) throw Error("StudioEnvironment is disposed");
		e.environment = this.texture, e.environmentIntensity = 1, e.background = new i(t);
	}
	dispose() {
		this.disposed || (this.disposed = !0, this.target.dispose());
	}
};
//#endregion
//#region src/engine/viewer/mountViewer.ts
async function $e(t, n = {}) {
	let r = document.createElement("canvas");
	r.style.cssText = "display:block;width:100%;height:100%;touch-action:none", r.setAttribute("aria-label", "Interactive 3D asset. Drag to rotate; scroll or pinch to zoom."), r.tabIndex = 0;
	let i, a, o, s, c = 0, l = !1, u = 0, f = 0, p = () => a ? a.dispose() : h(), m = () => a?.resetPerformance();
	function h() {
		l || (l = !0, cancelAnimationFrame(c), s?.disconnect(), document.removeEventListener("visibilitychange", m), n.signal?.removeEventListener("abort", p), o?.dispose(), r.remove());
	}
	try {
		if (n.signal?.aborted) throw new DOMException("Viewer mount aborted", "AbortError");
		i = new _({
			canvas: r,
			antialias: !0
		}), i.toneMapping = e, i.toneMappingExposure = 1, i.outputColorSpace = d;
		let g = i;
		if (a = Xe({
			...n,
			beforeDispose: h,
			backend: {
				render: (e, t) => g.render(e, t),
				setSize: (e, t) => g.setSize(e, t, !1),
				dispose: () => g.dispose(),
				setPixelRatio: (e) => g.setPixelRatio(e),
				statistics: () => ({
					calls: g.info.render.calls,
					triangles: g.info.render.triangles
				})
			},
			controls: (e) => {
				let t = new y(e, r);
				return t.enableDamping = !1, t;
			}
		}), t.append(r), n.signal?.addEventListener("abort", p, { once: !0 }), o = await Qe.create(i, 256), l || n.signal?.aborted) throw o.dispose(), new DOMException("Viewer mount aborted", "AbortError");
		o.attach(a.engine.scene);
		function v() {
			if (l) return;
			let e = t.getBoundingClientRect();
			u = e.width, f = e.height, a.resize(u, f);
		}
		v(), s = new ResizeObserver(v), s.observe(t), document.addEventListener("visibilitychange", m);
		let b = (e) => {
			l || (!document.hidden && u > 0 && f > 0 ? a.tick(e) : a.resetPerformance(), c = requestAnimationFrame(b));
		};
		return c = requestAnimationFrame(b), a;
	} catch (e) {
		throw a ? a.dispose() : (h(), i?.dispose()), e;
	}
}
//#endregion
//#region src/engine/presentations/assetPresenters.ts
function et(e) {
	return Object.freeze({ show: (t) => e.execute({
		type: "SHOW_JEWELRY",
		assetId: t
	}) });
}
function tt(e) {
	return Object.freeze({ show: (t) => e.execute({
		type: "SHOW_STONE",
		assetId: t
	}) });
}
//#endregion
//#region src/engine/boutique/createBoutiqueMode.ts
var nt = {
	"metal:18k-yellow-gold": "gold",
	"metal:18k-white-gold": "gold",
	"metal:rose-gold": "gold",
	"metal:platinum": "platinum",
	"metal:silver": "silver"
};
function rt(e, t = {}) {
	let n = V(e.engine.registry), r = /* @__PURE__ */ new Set(), i = /* @__PURE__ */ new Map(), a = e.paused, o = !1, s = 0, c = new AbortController(), l = Object.freeze({
		status: "idle",
		product: null,
		requestedProduct: null,
		error: null,
		selectedMetalId: null,
		selectedGemId: null,
		favorite: !1,
		turntable: !1,
		pendingAction: null
	});
	function u(e) {
		l = Object.freeze({
			...l,
			...e
		}), r.forEach((e) => e());
	}
	function d() {
		if (o) throw Error("Boutique Mode is disposed.");
	}
	function f(n) {
		let r = e.engine.access ? e.engine.access.getState(n.id).state !== "unlocked" : N(n.accessTier) !== "PUBLIC" && !(t.canAccess?.(n) ?? !1), i = n.materialSlots.some((e) => e.kind === "metal") ? e.materials.metals.filter((e) => n.metalCompatibility.some((t) => t === nt[e.id])) : [], a = n.materialSlots.some((e) => e.kind === "gem") ? e.materials.gems : [];
		return Object.freeze({
			id: n.id,
			name: n.name,
			category: n.category,
			supportedMetals: Object.freeze(i.map((e) => Object.freeze({
				id: e.id,
				name: e.name
			}))),
			supportedGemstones: Object.freeze(a.map((e) => Object.freeze({
				id: e.id,
				name: e.name
			}))),
			access: Object.freeze({
				tier: n.accessTier,
				locked: r,
				reason: r ? `${n.accessTier === "exclusive" ? "Exclusive" : "Premium"} access required.` : null
			})
		});
	}
	let p = e.subscribe(() => {
		o || (e.state.status === "disposed" ? (o = !0, c.abort(), u({
			status: "disposed",
			turntable: !1
		}), r.clear()) : l.turntable !== e.state.turntable && u({ turntable: e.state.turntable }));
	});
	async function m(t) {
		d();
		let r = ++s;
		if (e.engine.access && (n.resolve(t), await e.engine.access.check(t), d(), s !== r)) throw Error("Boutique access check superseded.");
		let a;
		try {
			a = f(n.resolve(t));
		} catch (e) {
			throw u({
				error: String(e),
				status: l.product ? l.status : "error"
			}), e;
		}
		let p = r;
		if (c.abort(), c = new AbortController(), e.setPaused(!0), a.access.locked) return u({
			status: "locked",
			product: a,
			requestedProduct: null,
			error: null,
			favorite: i.get(t) ?? !1,
			pendingAction: null,
			selectedMetalId: null,
			selectedGemId: null
		}), await e.execute({ type: "STOP_TURNTABLE" }), a;
		u({
			status: "loading",
			requestedProduct: a,
			error: null,
			pendingAction: null
		});
		try {
			if (await e.execute({
				type: "SHOW_JEWELRY",
				assetId: t
			}), o || p !== s) throw Error("Boutique product switch superseded or disposed.");
			let r = f(n.resolve(t));
			return e.setPaused(r.access.locked), u({
				status: r.access.locked ? "locked" : "ready",
				product: r,
				requestedProduct: null,
				error: null,
				favorite: i.get(t) ?? !1,
				selectedMetalId: null,
				selectedGemId: null
			}), r;
		} catch (t) {
			if (!o && p === s) {
				let r = e.state.assetId ? f(n.resolve(e.state.assetId)) : null;
				e.setPaused(!r || r.access.locked), u({
					status: r?.access.locked ? "locked" : "error",
					product: r,
					requestedProduct: a,
					error: String(t)
				});
			}
			throw t;
		}
	}
	function h() {
		if (d(), !l.product || !["ready", "error"].includes(l.status) || e.state.assetId !== l.product.id) throw Error("No settled Boutique product is available.");
		let t = f(n.resolve(l.product.id));
		if (t.access.locked) throw e.setPaused(!0), u({
			status: "locked",
			product: t
		}), Error(t.access.reason);
		return t;
	}
	async function g(t, n = "polished") {
		let r = h(), i = s;
		if (!r.supportedMetals.some((e) => e.id === t)) throw Error(`Metal is not supported by ${r.id}: ${t}`);
		let a = await e.execute({
			type: "SET_METAL",
			materialId: t,
			finish: n
		});
		if (o || i !== s) throw Error("Boutique material selection superseded or disposed.");
		return u(a.status === "applied" ? {
			selectedMetalId: t,
			error: null
		} : { error: a.reason }), a;
	}
	async function _(t) {
		let n = h(), r = s;
		if (!n.supportedGemstones.some((e) => e.id === t)) throw Error(`Gem is not supported by ${n.id}: ${t}`);
		let i = await e.execute({
			type: "SET_GEM",
			materialId: t
		});
		if (o || r !== s) throw Error("Boutique material selection superseded or disposed.");
		return u(i.status === "applied" ? {
			selectedGemId: t,
			error: null
		} : { error: i.reason }), i;
	}
	async function v(e) {
		if (d(), !l.product || l.status === "loading" || l.pendingAction) throw Error("No product available or an action is pending.");
		let r = n.resolve(l.product.id), a = s, f = c.signal, p = !l.favorite;
		if (!(e === "favorite" ? t.onFavorite : e === "compare" ? t.onCompare : t.onRequestAccess)) throw Error(`No ${e} hook configured.`);
		u({
			pendingAction: e,
			error: null
		});
		try {
			if (e === "favorite" ? await t.onFavorite(r, p, f) : e === "compare" ? await t.onCompare(r, f) : await t.onRequestAccess(r, f), o || a !== s) throw Error("Boutique action superseded or disposed.");
			e === "favorite" && (i.set(r.id, p), u({ favorite: p }));
		} catch (e) {
			throw !o && a === s && u({ error: String(e) }), e;
		} finally {
			!o && a === s && u({ pendingAction: null });
		}
	}
	async function y() {
		if (o) {
			p();
			return;
		}
		o = !0, s++, c.abort(), p(), u({
			status: "disposed",
			turntable: !1
		}), r.clear(), t.ownsViewer ? e.dispose() : e.state.status !== "disposed" && (await e.execute({ type: "STOP_TURNTABLE" }), e.setPaused(a));
	}
	return Object.freeze({
		viewer: e,
		get state() {
			return l;
		},
		capabilities: Object.freeze({
			favorite: !!t.onFavorite,
			compare: !!t.onCompare,
			requestAccess: !!t.onRequestAccess
		}),
		listProducts: () => Object.freeze(n.list().map(f)),
		subscribe: (e) => (d(), r.add(e), () => {
			r.delete(e);
		}),
		show: m,
		selectMetal: g,
		selectGem: _,
		refreshAccess: () => {
			if (d(), !l.product) throw Error("No product selected.");
			return m(l.product.id);
		},
		toggleTurntable: () => (h(), e.execute({ type: l.turntable ? "STOP_TURNTABLE" : "START_TURNTABLE" })),
		resetView: () => {
			h(), e.resetCamera();
		},
		toggleFavorite: () => v("favorite"),
		compare: () => v("compare"),
		requestAccess: () => v("access"),
		dispose: y
	});
}
//#endregion
//#region src/engine/boutique/mountBoutiqueViewer.ts
async function it(e, t = {}) {
	let n = document.createElement("section");
	n.className = "ames-boutique", n.innerHTML = "<style>\n  .ames-boutique{font:14px/1.5 system-ui;color:#e6e8ed;background:#181b20;padding:20px;border-radius:10px}\n  .ames-boutique .layout{display:flex;gap:24px;flex-wrap:wrap}.ames-boutique .viewport{flex:2;min-width:260px;height:420px}\n  .ames-boutique .details{flex:1;min-width:240px}.ames-boutique h2{margin:0 0 8px;font-size:24px}\n  .ames-boutique label{display:block;margin-top:14px}.ames-boutique select,.ames-boutique button{font:inherit;padding:8px;color:inherit;background:#29313c;border:1px solid #5a626f;border-radius:4px}\n  .ames-boutique select{width:100%}.ames-boutique button{margin:12px 6px 0 0;cursor:pointer}.ames-boutique button:disabled{opacity:.4;cursor:default}\n  .ames-boutique .badge{display:inline-block;border:1px solid #73767c;border-radius:16px;padding:2px 10px}.ames-boutique .error{color:#ffb5ad}\n  .ames-boutique [hidden]{display:none!important}\n  </style><div class=\"layout\"><div class=\"viewport\"></div><div class=\"details\"><h2 data-title>AMES Boutique</h2>\n  <p data-category></p><span class=\"badge\" data-access></span><p data-status role=\"status\">Select a registered jewelry asset.</p><p class=\"error\" data-error role=\"alert\"></p>\n  <label>Metal<select data-metal aria-label=\"Metal\"></select></label><label>Finish<select data-finish aria-label=\"Finish\"><option value=\"polished\">Polished</option><option value=\"brushed\">Brushed</option><option value=\"satin\">Satin</option></select></label>\n  <label>Gem preview<select data-gem aria-label=\"Gemstone\"></select></label>\n  <button data-turntable>Start turntable</button><button data-reset>Reset view</button><button data-favorite>Save favorite</button><button data-compare>Compare</button><button data-unlock>Request access</button>\n  </div></div>", e.append(n);
	let r = (e) => n.querySelector(e), i;
	try {
		i = await $e(r(".viewport"), t.viewer);
	} catch (e) {
		throw n.remove(), e;
	}
	let a = rt(i, {
		...t,
		ownsViewer: !0
	}), o = r("[data-metal]"), s = r("[data-gem]"), c = r("[data-finish]");
	function l(e, t, n, r) {
		let i = [new Option(r, ""), ...t.map((e) => new Option(e.name, e.id))];
		e.replaceChildren(...i), e.value = n ?? "";
	}
	let u = {
		ring: "Ring",
		watch: "Watch",
		bracelet: "Bracelet",
		necklace: "Necklace",
		earring: "Earring"
	};
	function d() {
		let e = a.state, t = e.status === "loading" ? e.requestedProduct : e.product;
		n.dataset.category = t?.category ?? "", r("[data-title]").textContent = t?.name ?? "AMES Boutique", r("[data-category]").textContent = t ? u[t.category] : "", r("[data-access]").textContent = t ? `${t.access.tier}${t.access.locked ? " · Locked" : " · Available"}` : "", r("[data-access]").hidden = !t, r("[data-status]").textContent = e.status === "loading" ? "Loading product…" : e.status === "locked" ? t.access.reason : e.status === "idle" && !a.listProducts().length ? "No jewelry assets are registered yet." : e.status === "idle" ? "Select a registered jewelry asset." : "", r("[data-error]").textContent = e.error ?? "";
		let d = !!t && !t.access.locked && ["ready", "error"].includes(e.status) && i.state.assetId === t.id;
		r(".viewport").hidden = !d, l(o, t?.supportedMetals ?? [], e.selectedMetalId, "Choose metal"), l(s, t?.supportedGemstones ?? [], e.selectedGemId, "Choose gemstone"), o.disabled = !d || !t?.supportedMetals.length, s.disabled = !d || !t?.supportedGemstones.length, c.disabled = o.disabled, r("[data-turntable]").disabled = !d, r("[data-turntable]").textContent = e.turntable ? "Stop turntable" : "Start turntable", r("[data-reset]").disabled = !d, r("[data-favorite]").disabled = !e.product || e.status === "loading" || !!e.pendingAction || !a.capabilities.favorite, r("[data-favorite]").textContent = e.favorite ? "Remove favorite" : "Save favorite", r("[data-compare]").disabled = !e.product || e.status === "loading" || !!e.pendingAction || !a.capabilities.compare, r("[data-unlock]").disabled = !!e.pendingAction || !a.capabilities.requestAccess, r("[data-unlock]").hidden = !t?.access.locked;
	}
	let f = a.subscribe(d), p = (e) => {
		Promise.resolve().then(e).catch((e) => {
			r("[data-error]").textContent = String(e);
		});
	};
	o.onchange = () => {
		o.value && p(() => a.selectMetal(o.value, c.value));
	}, c.onchange = () => {
		o.value && p(() => a.selectMetal(o.value, c.value));
	}, s.onchange = () => {
		s.value && p(() => a.selectGem(s.value));
	}, r("[data-turntable]").onclick = () => p(a.toggleTurntable), r("[data-reset]").onclick = () => p(a.resetView), r("[data-favorite]").onclick = () => p(a.toggleFavorite), r("[data-compare]").onclick = () => p(a.compare), r("[data-unlock]").onclick = () => p(a.requestAccess);
	let m = async () => {
		f(), await a.dispose(), n.remove();
	};
	if (d(), t.initialAssetId) try {
		await a.show(t.initialAssetId);
	} catch {}
	return Object.freeze({
		viewer: i,
		mode: a,
		show: a.show,
		dispose: m
	});
}
//#endregion
//#region src/engine/stone-tray/createStoneMode.ts
function at(e, t = {}) {
	let n = H(e.engine.registry), r = t.catalog ?? Oe, i = /* @__PURE__ */ new Set(), a = e.paused, o = !1, s = 0, c = 0, l = new AbortController(), u = Object.freeze({
		status: "idle",
		selected: null,
		requested: null,
		error: null,
		turntable: !1,
		selectingPrompt: !1
	});
	function d() {
		if (o) throw Error("Stone Mode is disposed.");
	}
	function f(e) {
		u = Object.freeze({
			...u,
			...e
		}), i.forEach((e) => e());
	}
	function p(e) {
		let t = n.resolve(e), i = r.resolve(t.stoneReferences[0]);
		if (!i.asset) throw Error(`No Stone Library geometry for ${i.stone.id}.`);
		return Object.freeze({
			assetId: e,
			stoneId: i.stone.id,
			name: i.stone.name,
			cut: i.cut,
			gemType: i.gemType,
			identity: i.stone.identity,
			opticalProfile: i.opticalProfile,
			geometry: i.asset,
			metadata: i.stone.metadata,
			acceptance: i.stone.acceptance,
			experimental: i.cut.metadata.experimental === !0 || i.cut.tags.includes("experimental"),
			previewGem: null
		});
	}
	let m = () => Object.freeze(n.list().map((e) => p(e.id)));
	function h() {
		c++, l.abort(), l = new AbortController();
	}
	let g = e.subscribe(() => {
		o || (e.state.status === "disposed" ? (o = !0, h(), f({
			status: "disposed",
			selected: null,
			requested: null,
			turntable: !1,
			selectingPrompt: !1
		}), t.onMetadata?.(null), i.clear()) : e.state.turntable !== u.turntable && f({ turntable: e.state.turntable }));
	});
	async function _(n) {
		d();
		let r;
		try {
			r = p(n);
		} catch (e) {
			throw f({
				error: String(e),
				status: u.selected ? u.status : "error"
			}), e;
		}
		let i = ++s;
		h(), e.setPaused(!0), f({
			status: "loading",
			requested: r,
			error: null,
			selectingPrompt: !1
		});
		try {
			if (await e.execute({
				type: "SHOW_STONE",
				assetId: n
			}), o || i !== s) throw Error("Stone switch superseded or disposed.");
			return e.setPaused(!1), f({
				status: "ready",
				selected: r,
				requested: null,
				error: null
			}), t.onMetadata?.(r), r;
		} catch (t) {
			if (!o && i === s) {
				let n = e.state.assetId && e.engine.registry.get(e.state.assetId)?.category === "stone" ? p(e.state.assetId) : null, i = n?.assetId === u.selected?.assetId ? u.selected : n;
				e.setPaused(!i), f({
					status: "error",
					selected: i,
					requested: r,
					error: String(t)
				});
			}
			throw t;
		}
	}
	function v() {
		if (d(), !u.selected || u.status === "loading" || u.selectingPrompt || u.selected.assetId !== e.state.assetId) throw Error("No settled stone is selected.");
		return u.selected;
	}
	async function y(n) {
		if (n.type === "DISPOSE") return await S(), {
			status: "applied",
			command: n.type
		};
		if (d(), n.type === "SHOW_STONE") {
			let e = n.assetId === void 0 ? m().filter((e) => e.stoneId === n.stoneId) : [p(n.assetId)];
			if (e.length !== 1) throw Error("SHOW_STONE must identify exactly one registered stone asset.");
			return await _(e[0].assetId), {
				status: "applied",
				command: n.type
			};
		}
		let r = v(), i = s;
		if (n.type === "SET_GEM") {
			let a = e.materials.gem(n.materialId ?? n.gemTypeId), c = await e.execute(n);
			if (o || i !== s) throw Error("Stone preview superseded or disposed.");
			if (c.status === "applied") {
				let e = Object.freeze({
					...r,
					previewGem: Object.freeze({
						id: a.id,
						name: a.name
					})
				});
				f({
					selected: e,
					error: null
				}), t.onMetadata?.(e);
			} else f({ error: c.reason });
			return c;
		}
		if (n.type !== "START_TURNTABLE" && n.type !== "STOP_TURNTABLE") throw Error("Unsupported Stone Mode command.");
		return e.execute(n);
	}
	async function b(e) {
		if (d(), !e || !["by-id", "query"].includes(e.kind)) throw Error("Invalid stone selection request.");
		let t = new Set(r.select(e).map((e) => e.id)), n = Object.freeze(m().filter((e) => t.has(e.stoneId)));
		return n.length === 1 ? Object.freeze({
			status: "selected",
			metadata: await _(n[0].assetId)
		}) : Object.freeze({
			status: n.length ? "ambiguous" : "unmatched",
			candidates: n
		});
	}
	async function x(e) {
		if (d(), !t.resolvePrompt) throw Error("No prompt selection hook configured.");
		if (typeof e != "string" || !e.trim()) throw Error("Prompt must not be empty.");
		h();
		let n = c;
		f({
			selectingPrompt: !0,
			error: null
		});
		try {
			let r = await t.resolvePrompt(e, {
				candidates: m(),
				signal: l.signal
			});
			if (o || n !== c) throw Error("Prompt selection superseded or disposed.");
			return f({ selectingPrompt: !1 }), await b(r);
		} catch (e) {
			throw !o && n === c && f({ error: String(e) }), e;
		} finally {
			!o && n === c && f({ selectingPrompt: !1 });
		}
	}
	async function S() {
		if (o) {
			g();
			return;
		}
		o = !0, s++, h(), g(), f({
			status: "disposed",
			selected: null,
			requested: null,
			turntable: !1,
			selectingPrompt: !1
		}), t.onMetadata?.(null), i.clear(), t.ownsViewer ? e.dispose() : e.state.status !== "disposed" && (await e.execute({ type: "STOP_TURNTABLE" }), e.setPaused(a));
	}
	return Object.freeze({
		viewer: e,
		get state() {
			return u;
		},
		subscribe: (e) => (d(), i.add(e), () => {
			i.delete(e);
		}),
		getChatMetadata: () => u.selected,
		listStones: m,
		getStoneMetadata: p,
		show: _,
		execute: y,
		applySelection: b,
		selectFromPrompt: x,
		setGem: (e) => y({
			type: "SET_GEM",
			materialId: e
		}),
		toggleTurntable: () => y({ type: u.turntable ? "STOP_TURNTABLE" : "START_TURNTABLE" }),
		resetView: () => {
			v(), e.resetCamera();
		},
		dispose: S
	});
}
//#endregion
//#region src/engine/stone-tray/mountStoneTray.ts
async function ot(e, t = {}) {
	let n = document.createElement("section");
	n.className = "ames-stone-tray", n.innerHTML = "<style>\n  .ames-stone-tray{font:14px/1.45 system-ui;color:#e7ebf1;background:#181b20;border:1px solid #36404e;border-radius:12px;padding:16px}\n  .ames-stone-tray header{display:flex;justify-content:space-between;align-items:center;gap:12px;flex-wrap:wrap}.ames-stone-tray h2{font-size:18px;margin:0}\n  .ames-stone-tray .stage{height:310px;position:relative}.ames-stone-tray .viewport{height:100%;opacity:1;transition:opacity 180ms ease}\n  .ames-stone-tray[data-loading=true] .viewport{opacity:.25;pointer-events:none}.ames-stone-tray .message{font-size:12px;color:#b9c5d4;min-height:18px}\n  .ames-stone-tray .metadata{display:flex;gap:14px;flex-wrap:wrap;font-size:12px;color:#c9d1dc}.ames-stone-tray .controls{display:flex;gap:8px;align-items:center;flex-wrap:wrap}\n  .ames-stone-tray select,.ames-stone-tray button{font:inherit;padding:7px;color:inherit;background:#27313e;border:1px solid #637083;border-radius:4px}\n  .ames-stone-tray select{max-width:100%;min-width:0}.ames-stone-tray .controls label{max-width:100%}\n  .ames-stone-tray button{cursor:pointer}.ames-stone-tray button:disabled,.ames-stone-tray select:disabled{opacity:.45;cursor:default}.ames-stone-tray .error{color:#ffb4a9}\n  @media(prefers-reduced-motion:reduce){.ames-stone-tray .viewport{transition:none}}\n  </style><header><h2 data-name>Stone Tray</h2><select data-stone aria-label=\"Registered stone\"></select></header>\n  <div class=\"metadata\"><span data-cut></span><span data-gem></span><span data-rarity></span></div>\n  <div class=\"stage\"><div class=\"viewport\"></div></div><p class=\"message\" data-status role=\"status\"></p><p class=\"message error\" data-error role=\"alert\"></p>\n  <div class=\"controls\"><label>Gem preview <select data-preview aria-label=\"Gem preview\"></select></label><button data-turntable>Start turntable</button><button data-reset>Reset view</button></div>", e.append(n);
	let r = (e) => n.querySelector(e), i;
	try {
		i = await $e(r(".viewport"), {
			...t.viewer,
			pan: "never"
		});
	} catch (e) {
		throw n.remove(), e;
	}
	let a = at(i, {
		...t,
		ownsViewer: !0
	}), o = r("[data-stone]"), s = r("[data-preview]"), c = a.listStones();
	o.replaceChildren(new Option("Select stone", ""), ...c.map((e) => new Option(`${e.name} · ${e.cut.name}`, e.assetId))), s.replaceChildren(new Option("Registered gem / default", ""), ...i.materials.gems.map((e) => new Option(e.name, e.id)));
	function l() {
		let e = a.state, t = e.selected, i = e.status === "loading" ? e.requested : t;
		n.dataset.loading = String(e.status === "loading"), r("[data-name]").textContent = i?.name ?? "Stone Tray", r("[data-cut]").textContent = i ? `Cut: ${i.cut.name}` : "", r("[data-gem]").textContent = i ? `Gem: ${i.gemType.name}${t?.previewGem ? ` · ${t.previewGem.name} preview` : ""}` : "", r("[data-rarity]").textContent = i ? `${i.cut.frequency === "common" ? "Known cut" : i.cut.frequency === "unknown" ? "Frequency unspecified" : `${i.cut.frequency} cut`}${i.experimental ? " · Experimental" : ""}` : "", r("[data-status]").textContent = e.status === "loading" ? `Loading ${e.requested?.cut.name ?? "stone"}…` : e.selectingPrompt ? "Resolving host selection…" : t ? "Drag to rotate · scroll or pinch to zoom" : "Select a registered stone.", r("[data-error]").textContent = e.error ?? "", o.value = (e.status === "loading" ? e.requested : t)?.assetId ?? "", s.value = t?.previewGem?.id ?? "";
		let c = !!t && e.status !== "loading" && !e.selectingPrompt && e.status !== "disposed";
		s.disabled = !c, o.disabled = e.status === "disposed", r("[data-turntable]").disabled = !c, r("[data-reset]").disabled = !c, r("[data-turntable]").textContent = e.turntable ? "Stop turntable" : "Start turntable";
	}
	let u = a.subscribe(l), d = !1, f = (e) => {
		Promise.resolve().then(e).catch((e) => {
			d || (r("[data-error]").textContent = String(e));
		});
	};
	o.onchange = () => {
		let e = o.value;
		e && f(() => a.show(e));
	}, s.onchange = () => {
		let e = s.value || a.state.selected?.gemType.id;
		e && f(() => a.setGem(e));
	}, r("[data-turntable]").onclick = () => f(a.toggleTurntable), r("[data-reset]").onclick = () => f(a.resetView);
	let p = () => {
		m();
	};
	async function m() {
		if (!d) {
			d = !0, u(), t.viewer?.signal?.removeEventListener("abort", p);
			try {
				await a.dispose();
			} finally {
				n.remove();
			}
		}
	}
	t.viewer?.signal?.addEventListener("abort", p, { once: !0 }), l();
	let h = t.initialAssetId === void 0 ? c[0]?.assetId : t.initialAssetId;
	if (h) try {
		await a.show(h);
	} catch {}
	return Object.freeze({
		mode: a,
		viewer: i,
		show: a.show,
		execute: a.execute,
		getChatMetadata: a.getChatMetadata,
		dispose: m
	});
}
//#endregion
//#region src/engine/integration/api.ts
function st(e) {
	let t = /* @__PURE__ */ new Map(), n = /* @__PURE__ */ new Map(), r = /* @__PURE__ */ new Map(), i, a = "none", o = !1, s = (e) => {
		for (let n of [...t.get(e.type) ?? [], ...t.get("*") ?? []]) try {
			n(e);
		} catch {}
	}, c = (e, n) => {
		let r = t.get(e) ?? /* @__PURE__ */ new Set();
		return r.add(n), t.set(e, r), () => r.delete(n);
	}, l = () => {
		if (o) throw Error("AMES integration is disposed.");
		e.engine.init(), s({ type: "INITIALIZED" });
	}, u = async (t) => {
		if (o) throw Error("AMES integration is disposed.");
		try {
			let r = t.type === "SHOW_JEWELRY" ? n.get("boutique") : t.type === "SHOW_STONE" ? n.get("stone-tray") : i ? n.get(i) : void 0, a = r ? await r.mode.execute(t) : await e.engine.execute(t);
			return s({
				type: "COMMAND_APPLIED",
				command: t,
				result: a
			}), a;
		} catch (e) {
			let n = e instanceof Error ? e : Error(String(e));
			throw s({
				type: "COMMAND_FAILED",
				command: t,
				error: n
			}), n;
		}
	}, d = async (e, t, c) => {
		if (o) throw Error("AMES integration is disposed.");
		let l = (r.get(e) ?? 0) + 1;
		if (r.set(e, l), await n.get(e)?.dispose(), o || r.get(e) !== l) throw Error("AMES mount superseded or disposed.");
		let u = e === "boutique" ? await it(t, c) : await ot(t, c);
		if (o || r.get(e) !== l) throw await u.dispose(), Error("AMES mount superseded or disposed.");
		let d = e === "stone-tray" ? u.mode.execute : async (e) => {
			let t = u.mode;
			if (e.type === "SHOW_JEWELRY") {
				if (!e.assetId) throw Error("SHOW_JEWELRY requires assetId for an embedded presentation.");
				return await t.show(e.assetId), {
					status: "applied",
					command: e.type
				};
			}
			return e.type === "SET_METAL" ? t.selectMetal(e.materialId ?? e.metal ?? "", e.finish) : e.type === "SET_GEM" ? t.selectGem(e.materialId ?? e.gemTypeId ?? "") : e.type === "START_TURNTABLE" || e.type === "STOP_TURNTABLE" ? u.viewer.execute(e) : e.type === "DISPOSE" ? (await u.dispose(), {
				status: "applied",
				command: e.type
			}) : u.viewer.execute(e);
		}, f = !1, p = Object.freeze({
			...u,
			mode: Object.freeze({ execute: d }),
			dispose: async () => {
				if (!f) {
					f = !0;
					try {
						await u.dispose();
					} finally {
						n.get(e) === p && (n.delete(e), i === e && (i = [...n.keys()].at(-1), a = i ?? "none"));
					}
				}
			}
		});
		return n.set(e, p), i = e, a = e, s({ type: e === "boutique" ? "BOUTIQUE_MOUNTED" : "STONE_TRAY_MOUNTED" }), p;
	};
	return Object.freeze({
		engine: e.engine,
		get mounted() {
			return a;
		},
		init: l,
		send: u,
		on: (e, t) => {
			let n = c(e, t);
			return () => {
				n();
			};
		},
		mountBoutique: (e, t) => d("boutique", e, t ?? {}),
		mountStoneTray: (e, t) => d("stone-tray", e, t ?? {}),
		dispose: async () => {
			o || (o = !0, await Promise.all([...n.values()].map((e) => e.dispose())), n.clear(), i = void 0, a = "none", e.engine.dispose(), s({ type: "DISPOSED" }), t.clear());
		}
	});
}
//#endregion
//#region src/engine/generation/spec.ts
var ct = [
	"ring",
	"watch",
	"bracelet",
	"necklace",
	"earring"
];
function lt(e) {
	if (!e.collection.trim() || !e.name.trim()) throw Error("Collection and name must be non-empty.");
	if (e.category !== "ring") throw Error("V1 generation proof supports category ring only.");
	if (![
		"platinum",
		"18k-yellow-gold",
		"18k-white-gold",
		"rose-gold",
		"silver",
		"rhodium"
	].includes(e.metal)) throw Error("Unsupported generation metal.");
	if (![
		"diamond",
		"ruby",
		"sapphire",
		"emerald",
		"spinel",
		"alexandrite",
		"tanzanite",
		"aquamarine",
		"tourmaline",
		"topaz",
		"garnet"
	].includes(e.primaryGemstone)) throw Error("Unsupported primary gemstone.");
	if (![
		"round",
		"oval",
		"emerald",
		"pear",
		"asscher"
	].includes(e.cut)) throw Error("Unsupported canonical cut.");
	if (!Number.isFinite(e.carat) || e.carat <= 0 || e.carat > 20) throw Error("Carat must be between 0 and 20.");
	if (e.band.widthMm <= 0 || e.band.thicknessMm <= 0 || e.prongs.count < 3 || e.prongs.count > 8) throw Error("Invalid ring dimensions or prong count.");
	if (e.halo.enabled && (e.halo.count < 4 || e.halo.count > 24)) throw Error("Hidden halo count must be between 4 and 24.");
	return Object.freeze({
		...e,
		semanticComponents: Object.freeze([...new Set(e.semanticComponents)])
	});
}
function ut(e, t = "/models/generated") {
	let n = lt(e), r = n.name.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, ""), i = n.cut === "round" ? "round_brilliant" : n.cut === "oval" ? "oval_brilliant" : n.cut === "pear" ? "pear_brilliant" : `${n.cut}_cut`;
	return Object.freeze({
		spec: n,
		assetId: `generated-${n.category}-${r || "asset"}`,
		outputPath: `${t}/generated-${n.category}-${r || "asset"}.glb`,
		canonicalStonePath: `/models/canonical/ames_${i}_v1.glb`,
		components: Object.freeze([...n.semanticComponents])
	});
}
//#endregion
//#region src/engine/generation/blenderFactory.ts
function dt(e, t) {
	let n = JSON.stringify(e.spec), r = `${t}/public${e.outputPath}`, i = `${t}/public${e.canonicalStonePath}`;
	return `import bpy, math, json
from math import sin, cos, pi
SPEC=${n}
OUTPUT=${JSON.stringify(r)}
CANONICAL=${JSON.stringify(i)}
def material(name, color, metallic=0.0, roughness=0.3, transmission=0.0, ior=1.45):
    m=bpy.data.materials.get(name) or bpy.data.materials.new(name); m.diffuse_color=(*color,1); m.use_nodes=True
    bs=m.node_tree.nodes.get('Principled BSDF'); bs.inputs['Base Color'].default_value=(*color,1); bs.inputs['Metallic'].default_value=metallic; bs.inputs['Roughness'].default_value=roughness; bs.inputs['Transmission Weight'].default_value=transmission; bs.inputs['IOR'].default_value=ior; return m
metal=material('AMES_PLATINUM_POLISHED',(0.72,0.76,0.82),0.95,0.16)
gem=material('AMES_DIAMOND_OPTICAL_SLOT',(0.92,0.98,1.0),0.0,0.08,0.72,2.417)
def tag(obj, role, is_gem=False):
    obj['ames_component']=role; obj['ames_semantic']=role; obj['ames_generation']='blender-mcp'; obj.data.materials.append(gem if is_gem else metal)
def torus(name, major, minor, z, role):
    bpy.ops.mesh.primitive_torus_add(major_radius=major, minor_radius=minor, major_segments=64, minor_segments=16, location=(0,0,z)); obj=bpy.context.object; obj.name=name; tag(obj,role); return obj
def cylinder(name, radius, depth, location, role):
    bpy.ops.mesh.primitive_cylinder_add(vertices=24, radius=radius, depth=depth, location=location); obj=bpy.context.object; obj.name=name; tag(obj,role); bpy.ops.object.shade_smooth(); return obj
bpy.ops.object.select_all(action='SELECT'); bpy.ops.object.delete(use_global=False)
bpy.ops.import_scene.gltf(filepath=CANONICAL)
stone=bpy.context.selected_objects[-1] if bpy.context.selected_objects else bpy.context.scene.objects[-1]; stone.name='Gem_Center_Oval'; stone.scale=(0.62,0.43,0.62); stone.location=(0,0,1.28); stone['ames_component']='Gem_Center'; stone['ames_semantic']='primary-gemstone'; stone['ames_source']=CANONICAL
torus('Band_Main',1.0,0.12,0,'Band_Main'); torus('Setting_Basket',0.48,0.07,0.96,'Setting_Basket')
for i in range(SPEC['prongs']['count']):
    a=2*pi*i/SPEC['prongs']['count']; cylinder('Prong_%02d'%(i+1),0.045,0.38,(0.34*cos(a),0.23*sin(a),1.18),'Prong_%02d'%(i+1))
if SPEC['halo']['enabled']:
    torus('Halo_Hidden',0.40,0.035,1.05,'Halo_Hidden')
    for i in range(SPEC['halo']['count']):
        a=2*pi*i/SPEC['halo']['count']; bpy.ops.mesh.primitive_ico_sphere_add(subdivisions=2,radius=0.045,location=(0.40*cos(a),0.27*sin(a),1.07)); obj=bpy.context.object; obj.name='Halo_Gem_%02d'%(i+1); tag(obj,'Halo_Gem_%02d'%(i+1),True)
bpy.ops.object.select_all(action='SELECT')
for obj in bpy.context.selected_objects:
    if obj.type=='MESH':
        bpy.context.view_layer.objects.active=obj; obj.select_set(True); bpy.ops.object.transform_apply(location=False,rotation=False,scale=True); bpy.ops.object.mode_set(mode='EDIT'); bpy.ops.mesh.select_all(action='SELECT'); bpy.ops.mesh.normals_make_consistent(inside=False); bpy.ops.object.mode_set(mode='OBJECT'); obj.data.validate(verbose=False)
bpy.ops.object.select_all(action='SELECT'); bpy.ops.export_scene.gltf(filepath=OUTPUT,export_format='GLB',use_selection=True,export_apply=True)
print(json.dumps({'output':OUTPUT,'objects':[o.name for o in bpy.context.selected_objects],'canonical':CANONICAL}))`;
}
//#endregion
//#region src/engine/generation/catalog.ts
function ft(e, t, n) {
	return Ne(e, t.map(({ plan: e, version: t }) => ({
		asset: pt(e),
		version: t
	})), n);
}
function pt(e, t = "exported") {
	let n = e.spec, r = n.metal.includes("gold") || n.metal === "rose-gold" ? "gold" : n.metal === "silver" ? "silver" : "platinum";
	return Object.freeze({
		id: e.assetId,
		name: n.name,
		category: n.category,
		assetPath: e.outputPath,
		previewPath: null,
		materialSlots: Object.freeze([{
			id: "metal",
			kind: "metal"
		}, {
			id: "gem:primary",
			kind: "gem"
		}]),
		stoneReferences: Object.freeze([]),
		metalCompatibility: Object.freeze([r]),
		accessTier: n.accessTier,
		tags: Object.freeze([
			"generated",
			"blender-mcp",
			n.collection
		]),
		status: "validated",
		generation: Object.freeze({
			spec: n,
			status: t,
			source: "blender-mcp"
		})
	});
}
function mt(e, t, n = "registered") {
	let r = pt(t, n);
	if (e.get(r.id)) throw Error(`Generated asset already registered: ${r.id}`);
	return M({
		schemaVersion: 1,
		assets: [...e.manifest.assets, r]
	});
}
//#endregion
//#region src/engine/integration/react.tsx
function ht(e) {
	let [t, n] = C(e.mounted);
	return x(() => e.on("*", (e) => {
		e.type === "BOUTIQUE_MOUNTED" ? n("boutique") : e.type === "STONE_TRAY_MOUNTED" ? n("stone-tray") : e.type === "DISPOSED" && n("none");
	}), [e]), {
		integration: e,
		mounted: t,
		send: e.send
	};
}
var gt = Object.freeze({});
function _t(e, t, n = gt) {
	let r = S(null), [i, a] = C(null);
	return x(() => {
		let i, o = !1;
		if (!r.current) return;
		a(null);
		let s = r.current;
		return (t === "boutique" ? e.mountBoutique(s, n) : e.mountStoneTray(s, n)).then(async (e) => {
			o ? await e.dispose() : i = e.dispose;
		}).catch((e) => {
			o || a(e instanceof Error ? e : Error(String(e)));
		}), () => {
			o = !0, i?.();
		};
	}, [
		e,
		t,
		n
	]), {
		ref: r,
		error: i
	};
}
function vt(e) {
	let t = _t(e.integration, "boutique", e.options);
	return /* @__PURE__ */ w("div", {
		ref: t.ref,
		"data-ames-integration": "boutique",
		children: t.error?.message
	});
}
function yt(e) {
	let t = _t(e.integration, "stone-tray", e.options);
	return /* @__PURE__ */ w("div", {
		ref: t.ref,
		"data-ames-integration": "stone-tray",
		children: t.error?.message
	});
}
//#endregion
//#region src/engine/index.ts
var bt = "0.1.0";
//#endregion
export { re as ACCESS_TIERS, bt as AMES_ENGINE_VERSION, ee as ASSET_CATEGORIES, P as AccessDeniedError, vt as AmesBoutique, yt as AmesStoneTray, T as AssetError, ct as JEWELRY_GENERATION_CATEGORIES, X as MaterialSystemError, Ge as RuntimeMaterialAssignment, Ae as assetRegistry, ke as canonicalAssetManifest, Me as catalogSnapshot, qe as createAccessControlledEngine, ie as createAccessController, Q as createAmesEngine, Ke as createAmesEngineForCanvas, st as createAmesIntegration, M as createAssetRegistry, dt as createBlenderGenerationScript, V as createBoutiqueAssets, rt as createBoutiqueMode, et as createBoutiquePresenter, Pe as createGlbProbe, ut as createJewelryGenerationPlan, Ue as createMaterialRegistry, Ve as createProfileGemMaterial, Re as createProfileMetalMaterial, at as createStoneMode, H as createStoneTrayAssets, tt as createStoneTrayPresenter, Xe as createViewerScene, pt as generatedAssetRecord, ft as ingestGeneratedJewelry, ne as loadAssetManifest, je as loadGlbAsset, Z as materialRegistry, it as mountBoutiqueViewer, ot as mountStoneTray, $e as mountViewer, N as normalizeAccessTier, te as parseAssetManifest, Ne as registerAssetBatch, mt as registerGeneratedAsset, We as semanticMaterialSlots, ht as useAmesIntegration, _t as useAmesMount, Fe as validateGlbContainer, lt as validateJewelryDesignSpec };
