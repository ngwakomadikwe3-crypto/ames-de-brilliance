# AMES access control ? Milestone 7

Use `createAccessControlledEngine({ backend, access: { userId, entitlements, delivery } })` for the app runtime, or pass the same `access` option to the shared viewer used by Boutique and Stone Tray. The existing `createAmesEngine` without access configuration remains a local-development compatibility API; it is not an authorization boundary. Do not use that configuration for protected app assets.

## Tiers and authority

`EntitlementTier` is PUBLIC, MEMBER, PREMIUM, COLLECTOR or PRIVATE. Manifest parsing accepts these and preserves legacy public/premium/exclusive records; legacy exclusive maps to COLLECTOR. Tiers describe policy, not an automatic numeric hierarchy. Only the host's trusted `EntitlementAdapter.canAccess(userId, assetId)` grants protected access. AI selection, preview state, UI callbacks and subscription hooks cannot grant it. Missing/unavailable entitlement service denies access. A controller is scoped to one identity: dispose/recreate on login or logout.

## Delivery boundary

Access-configured engines reject raw URL loads. ID loads validate registry/category, authorize before ingestion, then request protected URLs through `AssetDeliveryAdapter.resolve(userId, assetId)`. Missing delivery, invalid HTTPS GLB URLs and expired leases deny access. Public assets retain existing paths. Server adapters MUST derive the authenticated identity from the session, independently verify the asset entitlement and issue short-lived URLs. They must not trust the browser-provided userId or cached ACCESS_GRANTED state. Protected originals must live behind authenticated storage, not Vite public/ or publicly reachable manifest paths. No storage service or subscription provider is implemented here; shipping protected content requires that server integration. Already downloaded content cannot be revoked by hiding the viewer.

## Commands and events

CHECK_ACCESS returns an AccessState (locked/unlocked); PREVIEW_ASSET returns premium-preview metadata only, never a protected GLB. Preview paths must be intentionally public derivatives. START_SUBSCRIPTION invokes a host flow hook and emits SUBSCRIPTION_STARTED without granting access. `engine.access.subscribe` exposes ACCESS_GRANTED, ACCESS_DENIED, PREMIUM_PREVIEWED and SUBSCRIPTION_STARTED. Granted events describe entitlement checks, not successful delivery or rendering. Failed delivery emits ACCESS_DENIED. Loading denied assets rejects with typed AccessDeniedError, code ACCESS_DENIED and the access state. Invalid IDs retain ASSET_NOT_FOUND.

Boutique ignores its legacy UI grant callback when engine access is configured. Stone Tray SHOW_STONE and prompt selections pass through the same loader authorization. Presentation code can read engine.access.getState and subscribe without placing payments in the renderer. Access snapshots are advisory; each protected load rechecks authority. Event listeners cannot override authorization. Disposal prevents late authorization results from loading assets.

## Validation

Access unit tests cover public/granted/denied loading, five tiers, invalid IDs, both presentation modes, preview and subscription separation, events, direct-URL rejection, delivery failure/expiry and pending disposal. No payment integration, protected production assets, shader or geometry changes are included. Milestone 6 files were already in progress when this milestone was requested; this milestone does not claim their full separate acceptance.
