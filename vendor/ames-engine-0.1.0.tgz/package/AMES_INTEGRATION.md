# AMES app integration contract

The external AMES app should depend on the standalone package and own one integration instance. It does not need to know about Three.js scenes or renderer internals.

```ts
import { createAmesEngine, createAmesIntegration } from '@ames/engine'
const engine = createAmesEngine({ backend: createBackend(), access: accessOptions })
const ames = createAmesIntegration({ engine }); ames.init()
await ames.mountBoutique(document.querySelector('#boutique')!, { initialAssetId: 'ring-001' })
await ames.mountStoneTray(document.querySelector('#stone-tray')!, { initialAssetId: 'stone-001' })
```

Send `SHOW_JEWELRY`, `SHOW_STONE`, `LOAD_ASSET`, `SET_METAL`, `SET_GEM`, `FOCUS_COMPONENT`, `SET_QUALITY`, `START_TURNTABLE` and `STOP_TURNTABLE` through `ames.send(command)`. Commands return typed results. Subscribe with `ames.on('*', listener)` for `INITIALIZED`, mount, command success/failure and disposal events. The access controller separately emits its four access events.

```ts
const off = ames.on('*', event => chatStore.dispatch({ type: event.type, payload: event }))
try { await ames.send({ type: 'SHOW_STONE', assetId: 'stone-001' }) } finally { off() }
await ames.dispose()
```

React hosts can use `useAmesIntegration(integration)` and `<AmesBoutique integration={ames} />` or `<AmesStoneTray integration={ames} />` from `src/engine/integration/react.tsx`; expose that file as the app's React adapter entry when packaging React separately. The core runtime stays UI independent. Disposal unmounts the presentation, aborts pending work and releases viewer/engine resources.
