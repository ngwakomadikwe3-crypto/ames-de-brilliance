# AMES Engine V1 — milestone 1

Latest host layers: [reusable interactive viewer](REUSABLE_VIEWER.md) and [Boutique Mode](BOUTIQUE_MODE.md) add browser mounting, category-scoped product presentation and lifecycle/performance hooks without changing the underlying rendering implementations. The rest of this document records the initial shell milestone.

Current extensions: [asset manifest and ID loader](ASSET_MANIFEST.md) and [milestone 3 material system](MATERIAL_SYSTEM.md). Those documents supersede the historical milestone-1-only command behavior below: LOAD/SHOW accept asset IDs, and SET_METAL/SET_GEM now have semantic assignment defaults for loaded models. The original lifecycle, hook precedence and locked-kernel ownership remain intact.

This milestone creates a standalone public engine runtime, typed command protocol, lifecycle and Boutique/Stone Tray hooks, delivered as an ES module with TypeScript declarations. It composes the existing tested `JewelryRenderer` kernel without modifying it. V1 names the product roadmap; the current API is version 0.1.0 and does not claim production-ready photorealism. The five-cut rendering baseline still fails visual/performance acceptance.

## Public API and build

`npm run build:engine` emits `dist-engine/ames-engine.js`, declarations and a private `@ames/engine` package manifest. The existing Vite application remains the development host; `npm run build` builds both host and standalone package. A Node smoke check imports and runs the built package without a DOM or GPU. Three.js is external and declared as a peer at the tested installed version, avoiding duplicate scene-object identities. React and React Three Fiber belong to host adapters and are not dependencies of the shell. No assets, research shaders or application screens are bundled into this artifact. This does not publish anything.

```ts
import { createAmesEngineForCanvas } from '@ames/engine'

const engine = createAmesEngineForCanvas(canvas)
engine.init()
engine.resize(640, 480)
await engine.execute({ type: 'SHOW_STONE', stoneId: 'stone-001' })
await engine.execute({ type: 'START_TURNTABLE', radiansPerSecond: 0.4 })
engine.update(1 / 60) // example delta in seconds; the host supplies actual frame deltas
engine.dispose() // safe to call again
```

For non-browser hosts or tests, use `createAmesEngine({ backend, hooks?, loadAsset? })` with backend `render(scene, camera)`, `setSize(width, height, updateStyle)` and `dispose()` methods. The backend transfers exclusive ownership at `init()`; a factory defers allocation. Each engine owns independent scene/camera state. Hosts can access `scene`, `camera`, `target` and `model`; they own any lighting, controls or resources they add. Dispose those resources before the engine. Importing or constructing the shell does not fetch assets, create an animation loop or install event listeners. A production presentation still needs a host lighting/material adapter; loading a stone is not optical acceptance.

Lifecycle is `idle → init() → ready → dispose() → disposed`. Init and disposal are idempotent; disposed engines cannot be reinitialized. `load(url, options?)` delegates to the existing loader/classifier with latest-request-wins and model preservation on failure. Benchmark 02 URLs force the existing verified semantic guard. `update(deltaSeconds)` rotates only the loaded instance transform when turntable is enabled and renders one frame; geometry buffers remain untouched. `render()` is also available without advancing the turntable. No operation requires a React component.

## Typed command protocol

`execute(command: EngineCommand): Promise<EngineCommandResult>` accepts trusted TypeScript commands. It is not an untrusted JSON/network parser or an entitlement check. URLs and user-generated commands must be validated by a future app boundary. Unknown commands, bad lifecycle calls and load/adapter failures reject. Adapter-dependent commands return `status: 'unsupported'` when the adapter is absent; they never claim to have changed the visual result.

| Command | Payload | Milestone 1 behavior |
| --- | --- | --- |
| `LOAD_ASSET` | `url`, optional kernel load `options` | Load through existing ingestion, reset presentation mode to `none` |
| `SHOW_JEWELRY` | `url`, optional `options` | Load, invoke optional `boutique` hook, set mode `boutique` |
| `SHOW_STONE` | `stoneId` | Resolve actual Stone Library GLB, load, invoke optional `stoneTray` hook, set mode `stone-tray` |
| `SET_METAL` | `metal`: gold/silver/platinum | Delegate to `setMetal` hook or report unsupported |
| `SET_GEM` | `gemTypeId` | Delegate to `setGem` hook or report unsupported |
| `FOCUS_COMPONENT` | `componentId` | Delegate to `focusComponent` hook or report unsupported |
| `SET_QUALITY` | `quality`: FAST/INTERACTIVE/HIGH/BEAUTY | Delegate to `setQuality` hook or report unsupported |
| `START_TURNTABLE` | optional `radiansPerSecond` (default 0.4) | Enable rotation on subsequent host updates |
| `STOP_TURNTABLE` | none | Hold current angle |
| `DISPOSE` | none | Abort hook scope and release owned kernel/backend resources |

Boutique/Stone Tray are integration hooks and mode state, not new screens. Without a presentation hook, the selected GLB still loads and the mode changes. Material, gem, focus and quality behavior requires an explicit adapter; no new shader or automatic material assignment is hidden in the runtime. Hooks receive scene, camera, target, current model and an AbortSignal. Replacement loads and disposal abort the signal. Async hooks must honor it and clean up their own resources. Superseded/disposed completions cannot set mode or report success. A failed presentation hook rejects and leaves the newly loaded model in mode `none`; it does not restore a disposed previous asset. Starting a replacement load cancels old hook work even if that replacement subsequently fails; the old model itself remains available. The host should await commands that depend on earlier changes.

In a later React adapter, create an instance on mount and dispose it on cleanup; do not allocate it during React render. A canvas-backed engine owns its WebGLRenderer. An R3F adapter must explicitly coordinate rendering and ownership rather than hand a shared R3F renderer to this owning factory. That adapter is not implemented in milestone 1.

## Module boundaries

| Responsibility | Location / ownership |
| --- | --- |
| Stable public entry, typed commands and lifecycle composition | `src/engine/index.ts`, `src/engine/core/{protocol,createAmesEngine}.ts` |
| GLB ingestion and scene reading | Existing `src/engine/loaders/`; manifest binding in milestone 2 |
| Part analysis and verified semantics | Existing `src/engine/analyzer/`; jewelry-type contract in milestone 3 |
| Material assignment | Existing `src/engine/materials/`; acceptance work in milestone 4 |
| Scene, camera and backend ownership | Existing `src/engine/renderer/JewelryRenderer.ts` |
| Interaction and React/R3F host adapters | Existing viewer controls retained; public viewer in milestone 5 |
| Boutique and gem tray presentation | Future host modes, milestones 6–7; not dependencies of core |
| Access policy | Future milestone 8; client access state cannot replace server authorization |
| App command API | Runtime protocol in milestone 1; AMES transport/integration and prompt hooks in milestone 9 |
| Asset and stone catalog data | Existing Stone Library retained; scalable jewelry schema finalized in milestone 10 |

Dependencies point from host → public engine → focused services. Existing experimental renderers remain isolated research code and are not silently promoted into the public API. The build rejects imports of research material/rendering and React host modules into the shell. No duplicate loader, classifier, shader or kernel is introduced.

## Milestones and stopping points

1. **Complete:** standalone runtime, typed commands, init/load/update/dispose, mode hooks, package build, declarations and lifecycle/command tests.
2. Asset loader + manifest: expose the existing GLB pipeline through stable asset identities, explicit ownership and failure handling. Register actual available assets; do not fabricate a 60-asset inventory.
3. Jewelry classification: jewelry category and part-role contracts, retaining Benchmark 02 verified semantics.
4. Material assignment: gold, silver, platinum and gem bindings with explicit rendering acceptance. Existing failed rendering experiments are evidence, not accepted defaults.
5. Interactive viewer: rotation, zoom, optional pan, lifecycle and device performance acceptance.
6. Boutique mode: reusable viewer/card scenes.
7. Gem tray: named stone selection through the existing Stone Library above chat.
8. Subscription locks: public/premium/exclusive metadata and host-provided entitlement decisions.
9. AMES app interface: typed commands and deferred prompt-generation request hooks; no generator implementation.
10. Scale-ready schema: curated target of 10 each rings, bracelets, necklaces, earrings, watches and stones; future 100 each jewelry category. Counts are goals, not existing inventory. Asset production is separately gated by geometry, provenance and rendering acceptance.

Work stops after each milestone. No assets or jewelry are created in milestone 1. Blender/JewelCraft authoring and GLB runtime delivery remain the asset contract, with immutable canonical revisions and separate provenance records.

## Original implementation and preserved work

No diamond-webgl code is cloned, copied or imported by the standalone shell. It is a visual benchmark only. Existing legacy directories remain untouched; this milestone makes no blanket license claim about prior research or JewelCraft-derived assets. Their provenance remains separate from original AMES shell code. Benchmark 02, canonical geometry, locked semantics/kernel, current viewers and rendering implementations are unchanged.

The immediate next milestone is the asset loader + asset manifest. Photorealistic production acceptance remains unresolved and must pass before the engine is represented as production ready.

## Files in this milestone

Validation: application and standalone builds PASS; built ES-module/declaration Node smoke check PASS; full thread-worker suite **80 tests / 23 files PASS**, preserving all 71 prior tests. SHA-256 comparison confirms all 87 protected engine/asset files unchanged, including Benchmark 02 and all canonical stones. The standalone bundle is 29.92 kB (10.09 kB gzip), excluding the external Three.js peer. Existing application BVH namespace and chunk-size warnings remain; this shell does not establish a new visual acceptance result.

- `src/engine/index.ts`, `src/engine/core/createAmesEngine.ts`, `src/engine/core/protocol.ts`: public API, command protocol and composition.
- `vite.engine.config.ts`, `tsconfig.engine.json`, `scripts/package-engine.mjs`, `scripts/validate-engine-package.mjs`: standalone ES-module/declaration build and artifact smoke check.
- `package.json`, `.gitignore`: build integration and generated-output exclusion.
- `tests/engineShell.test.ts`, `tests/engineCommands.test.ts`: instance isolation, lifecycle, command routing, unsupported adapters, catalog resolution, turntable geometry preservation, load races, cancellation and benchmark guard.
- `docs/ENGINE_V1.md`, `docs/AMES_STATE.md`: runtime contract and current milestone state.

Access-controlled app entry and server adapter contract: [ACCESS_CONTROL.md](ACCESS_CONTROL.md).
