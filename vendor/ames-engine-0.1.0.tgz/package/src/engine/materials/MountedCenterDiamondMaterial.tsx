import { MeshRefractionMaterial } from '@react-three/drei'
import { useThree } from '@react-three/fiber'
import { useEffect, useMemo } from 'react'
import {
  Box3, CubeCamera, CubeTexture, HalfFloatType, LinearMipmapLinearFilter,
  Matrix3, Matrix4, Mesh, Scene, SRGBColorSpace, Vector3, WebGLCubeRenderTarget,
} from 'three'
import type { Light, ShaderMaterial } from 'three'
import type { ViewerQualityProfile } from '../renderer/viewerQuality'

/** A neutral optical room used only by Reference Diamond 001. */
function createCenterEnvironment() {
  const size = 512
  const texture = new CubeTexture(Array.from({ length: 6 }, (_, face) => {
    const canvas = document.createElement('canvas')
    canvas.width = canvas.height = size
    const context = canvas.getContext('2d')!
    const fill = context.createLinearGradient(0, 0, size, size)
    fill.addColorStop(0, '#969696')
    fill.addColorStop(0.5, '#686868')
    fill.addColorStop(1, '#3e3e3e')
    context.fillStyle = fill
    context.fillRect(0, 0, size, size)
    context.filter = 'blur(24px)'
    context.fillStyle = '#bcbcbc'
    context.fillRect(28, 40, 280, 400)
    context.filter = 'blur(6px)'
    context.fillStyle = '#202020'
    context.fillRect(face % 2 ? 300 : 58, 80, 80, 310)
    context.filter = 'blur(2px)'
    context.fillStyle = '#ffffff'
    context.fillRect(face % 2 ? 118 : 350, 42, 38, 390)
    if (face === 2 || face === 4) context.fillRect(86, 100, 300, 28)
    return canvas
  }))
  texture.colorSpace = SRGBColorSpace
  texture.needsUpdate = true
  return texture
}

/** Keep mounting reflections attached to the ring as its existing turntable rotates. */
export function orientCenterEnvironment(fragmentShader: string) {
  return fragmentShader
    .replace('uniform float bounces;', 'uniform mat3 centerWorldToCapture;\nuniform float bounces;')
    .replace('return textureGrad(envMap, rayDirection,', `
      rayDirection = centerWorldToCapture * rayDirection;
      directionCamPerfect = centerWorldToCapture * directionCamPerfect;
      return textureGrad(envMap, rayDirection,`)
}

export function MountedCenterDiamondMaterial({ constrained, quality, center }: { constrained?: boolean; quality?: ViewerQualityProfile; center: Mesh }) {
  // A material portal's scene is the center mesh; the outer scene is its topmost ancestor.
  const gl = useThree(state => state.gl)
  const opticalRoom = useMemo(createCenterEnvironment, [])
  const tier = quality?.tier ?? (constrained ? 'MEDIUM' : 'HIGH')
  const safe = tier === 'SAFE'
  const capture = useMemo(() => ({
    target: new WebGLCubeRenderTarget(quality?.centerEnvironmentSize ?? (constrained ? 192 : 256), {
      type: HalfFloatType, generateMipmaps: true, minFilter: LinearMipmapLinearFilter,
    }),
    rotation: new Matrix4(),
    inverseRotation: new Matrix4(),
    worldToCapture: { value: new Matrix3() },
  }), [quality?.centerEnvironmentSize, constrained])

  useEffect(() => {
    if (safe) return
    let root = center.parent!
    while (root.parent) root = root.parent
    const source = root as Scene
    source.updateMatrixWorld(true)
    const room = new Scene()
    room.background = opticalRoom
    room.environment = source.environment
    room.environmentIntensity = source.environmentIntensity
    // Read-only geometry/material references. No source object is hidden or reparented.
    source.traverse(object => {
      if (object === center) return
      if ((object as Mesh).isMesh && object.userData.ames_part_id) {
        const mesh = object as Mesh
        const copy = new Mesh(mesh.geometry, mesh.material)
        copy.matrixAutoUpdate = false
        copy.matrix.copy(mesh.matrixWorld)
        room.add(copy)
      } else if ((object as Light).isLight) {
        const light = object.clone()
        light.matrixAutoUpdate = false
        light.matrix.copy(object.matrixWorld)
        room.add(light)
      }
    })
    const camera = new CubeCamera(0.005, 30, capture.target)
    camera.position.copy(new Box3().setFromObject(center).getCenter(new Vector3()))
    capture.rotation.extractRotation(center.matrixWorld)
    const previousTarget = gl.getRenderTarget()
    const previousFace = gl.getActiveCubeFace()
    const previousMip = gl.getActiveMipmapLevel()
    try {
      camera.update(gl, room)
    } finally {
      gl.setRenderTarget(previousTarget, previousFace, previousMip)
      room.clear() // Shared geometry and materials belong to the visible scene.
    }
  }, [center, opticalRoom, capture, gl, safe])

  useEffect(() => () => {
    opticalRoom.dispose()
    capture.target.dispose()
  }, [opticalRoom, capture])

  if (safe) return <meshPhysicalMaterial
    envMap={opticalRoom}
    color="#f8fbff"
    metalness={0}
    roughness={0.025}
    clearcoat={0.35}
    clearcoatRoughness={0.06}
    transmission={0.2}
    ior={2.417}
    envMapIntensity={2}
    flatShading
    toneMapped
  />

  return <MeshRefractionMaterial
    envMap={capture.target.texture}
    ior={2.417}
    bounces={tier === 'IOS_LOW' ? 1 : tier === 'LOW' ? 2 : tier === 'MEDIUM' ? 4 : 6}
    aberrationStrength={tier === 'IOS_LOW' || tier === 'LOW' ? 0 : tier === 'MEDIUM' ? 0.001 : 0.002}
    fastChroma
    fresnel={0.04}
    color={[1.8, 1.8, 1.8]}
    toneMapped
    onBeforeCompile={shader => {
      shader.uniforms.centerWorldToCapture = capture.worldToCapture
      shader.fragmentShader = orientCenterEnvironment(shader.fragmentShader)
    }}
    customProgramCacheKey={() => 'ames-reference-001-local-environment-v1'}
    onBeforeRender={(renderer, _scene, camera, _geometry, object) => {
      capture.inverseRotation.extractRotation(object.matrixWorld).invert()
      capture.worldToCapture.value.setFromMatrix4(
        capture.inverseRotation.premultiply(capture.rotation),
      )
      const material = center.material as ShaderMaterial
      material.uniforms.viewMatrixInverse.value.copy(camera.matrixWorld)
      material.uniforms.projectionMatrixInverse.value.copy(camera.projectionMatrixInverse)
      const target = renderer.getRenderTarget()
      if (target) material.uniforms.resolution.value.set(target.width, target.height)
      else renderer.getDrawingBufferSize(material.uniforms.resolution.value)
    }}
  />
}
