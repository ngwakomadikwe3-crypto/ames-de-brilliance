import { MeshRefractionMaterial } from '@react-three/drei'
import { useEffect, useMemo } from 'react'
import type { Matrix4, Texture } from 'three'
import { createRoundBrilliantGeometry } from './createRoundBrilliantGeometry'
import {
  gemQualityForGeometry,
  JEWELRY_DIAMOND_OPTICS,
  mobileGemProfile,
} from './jewelryGlbMaterials'

export function RoundBrilliantGem({
  envMap,
  matrix,
  constrained = false,
}: {
  envMap: Texture
  matrix: Matrix4
  constrained?: boolean
}) {
  const geometry = useMemo(() => createRoundBrilliantGeometry(), [])
  useEffect(() => () => geometry.dispose(), [geometry])

  const quality = useMemo(() => {
    const base = gemQualityForGeometry(geometry)
    return constrained ? mobileGemProfile(base) : base
  }, [constrained, geometry])

  return (
    <mesh
      geometry={geometry}
      dispose={null}
      matrixAutoUpdate={false}
      ref={(mesh) => {
        if (!mesh) return
        mesh.matrix.copy(matrix)
        mesh.matrixWorldNeedsUpdate = true
      }}
    >
      <MeshRefractionMaterial
        envMap={envMap}
        ior={JEWELRY_DIAMOND_OPTICS.ior}
        fresnel={quality.fresnel}
        aberrationStrength={quality.aberrationStrength}
        fastChroma={JEWELRY_DIAMOND_OPTICS.fastChroma}
        bounces={quality.bounces}
        color="#ffffff"
        toneMapped
      />
    </mesh>
  )
}
