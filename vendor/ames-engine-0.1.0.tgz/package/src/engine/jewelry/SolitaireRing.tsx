import { useGLTF } from '@react-three/drei'
import { useMemo } from 'react'
import * as THREE from 'three'
import { TEST_RING_SOURCE } from '../../../contracts/test-ring'

/** Legacy component name; all development entry points now use the candidate. */
export const TEST_SOLITAIRE_RING_URL = TEST_RING_SOURCE.url

export function SolitaireRing({ url = TEST_SOLITAIRE_RING_URL }: { url?: string }) {
  const { scene } = useGLTF(url)
  const fitted = useMemo(() => {
    const copy = scene.clone(true)
    const box = new THREE.Box3().setFromObject(copy)
    const size = box.getSize(new THREE.Vector3())
    const center = box.getCenter(new THREE.Vector3())
    const scale = 2.0 / Math.max(size.x, size.y, size.z, 0.001)
    copy.position.sub(center).multiplyScalar(scale)
    copy.scale.setScalar(scale)
    return copy
  }, [scene])
  // The GLB is cached by useGLTF; do not dispose its shared geometry/materials here.
  return <primitive object={fitted} />
}
