import { BufferGeometry, Float32BufferAttribute, Vector3 } from 'three'

const OCTANTS = 8
const SECTOR = (Math.PI * 2) / OCTANTS
const HALF_SECTOR = SECTOR / 2
const GIRDLE_RADIUS = 1
const TABLE_RATIO = 0.56
const CROWN_ANGLE = 34.5
const PAVILION_ANGLE = 40.9
const GIRDLE_THICKNESS = 0.04
const CROWN_MID_RATIO = 0.78
const PAVILION_SIDE_RATIO = 0.5
const INTERIOR = new Vector3(0, 0, 0)

export const ROUND_BRILLIANT_FACET_GROUPS = {
  table: 1,
  star: 8,
  bezel: 8,
  upperGirdle: 16,
  pavilionMain: 8,
  lowerGirdle: 16,
} as const

export const ROUND_BRILLIANT_PROPORTIONS = {
  table: TABLE_RATIO,
  crownAngle: CROWN_ANGLE,
  pavilionAngle: PAVILION_ANGLE,
  girdleThickness: GIRDLE_THICKNESS,
  totalDepth:
    GIRDLE_THICKNESS +
    (GIRDLE_RADIUS - TABLE_RATIO) * Math.tan((CROWN_ANGLE * Math.PI) / 180) +
    GIRDLE_RADIUS * Math.tan((PAVILION_ANGLE * Math.PI) / 180),
} as const

export const ROUND_BRILLIANT_TRIANGLE_COUNT = OCTANTS * 14

function mainAngle(index: number) {
  return index * SECTOR
}

function halfAngle(index: number) {
  return (index + 0.5) * SECTOR
}

function polar(radius: number, angle: number, height: number) {
  return new Vector3(Math.cos(angle) * radius, height, Math.sin(angle) * radius)
}

function nextIndex(index: number) {
  return (index + 1) % OCTANTS
}

function previousIndex(index: number) {
  return (index + OCTANTS - 1) % OCTANTS
}

export function createRoundBrilliantGeometry(): BufferGeometry {
  const girdleTop = GIRDLE_THICKNESS / 2
  const girdleBottom = -GIRDLE_THICKNESS / 2
  const crownHeight =
    (GIRDLE_RADIUS - TABLE_RATIO) * Math.tan((CROWN_ANGLE * Math.PI) / 180)
  const tableHeight = girdleTop + crownHeight
  const pavilionDepth = GIRDLE_RADIUS * Math.tan((PAVILION_ANGLE * Math.PI) / 180)
  const culetHeight = girdleBottom - pavilionDepth
  const crownMidHeight =
    tableHeight +
    (crownHeight * (TABLE_RATIO - CROWN_MID_RATIO * Math.cos(HALF_SECTOR))) /
      (GIRDLE_RADIUS - TABLE_RATIO)
  const pavilionSideHeight =
    culetHeight + pavilionDepth * PAVILION_SIDE_RATIO * Math.cos(HALF_SECTOR)

  const vertices: Vector3[] = []
  const push = (vertex: Vector3) => {
    vertices.push(vertex)
    return vertices.length - 1
  }

  const tableCenter = push(new Vector3(0, tableHeight, 0))
  const culet = push(new Vector3(0, culetHeight, 0))

  const tableRing: number[] = []
  const crownRing: number[] = []
  const girdleTopMain: number[] = []
  const girdleTopValley: number[] = []
  const girdleBottomMain: number[] = []
  const girdleBottomValley: number[] = []
  const pavilionRing: number[] = []

  for (let index = 0; index < OCTANTS; index += 1) {
    tableRing.push(push(polar(TABLE_RATIO, mainAngle(index), tableHeight)))
    crownRing.push(push(polar(CROWN_MID_RATIO, halfAngle(index), crownMidHeight)))
    girdleTopMain.push(push(polar(GIRDLE_RADIUS, mainAngle(index), girdleTop)))
    girdleTopValley.push(push(polar(GIRDLE_RADIUS, halfAngle(index), girdleTop)))
    girdleBottomMain.push(push(polar(GIRDLE_RADIUS, mainAngle(index), girdleBottom)))
    girdleBottomValley.push(push(polar(GIRDLE_RADIUS, halfAngle(index), girdleBottom)))
    pavilionRing.push(push(polar(PAVILION_SIDE_RATIO, halfAngle(index), pavilionSideHeight)))
  }

  const triangles: [number, number, number][] = []

  for (let index = 0; index < OCTANTS; index += 1) {
    const next = nextIndex(index)
    const previous = previousIndex(index)

    triangles.push([tableCenter, tableRing[index], tableRing[next]])
    triangles.push([tableRing[index], tableRing[next], crownRing[index]])

    triangles.push([tableRing[index], crownRing[index], girdleTopMain[index]])
    triangles.push([tableRing[index], girdleTopMain[index], crownRing[previous]])

    triangles.push([girdleTopMain[index], girdleTopValley[index], crownRing[index]])
    triangles.push([girdleTopValley[previous], girdleTopMain[index], crownRing[previous]])

    triangles.push([girdleBottomMain[index], girdleBottomValley[index], pavilionRing[index]])
    triangles.push([girdleBottomValley[previous], girdleBottomMain[index], pavilionRing[previous]])

    triangles.push([girdleBottomMain[index], pavilionRing[index], culet])
    triangles.push([girdleBottomMain[index], culet, pavilionRing[previous]])
  }

  const topOrder: number[] = []
  const bottomOrder: number[] = []
  for (let index = 0; index < OCTANTS; index += 1) {
    topOrder.push(girdleTopMain[index], girdleTopValley[index])
    bottomOrder.push(girdleBottomMain[index], girdleBottomValley[index])
  }
  for (let segment = 0; segment < topOrder.length; segment += 1) {
    const next = (segment + 1) % topOrder.length
    triangles.push([topOrder[segment], topOrder[next], bottomOrder[next]])
    triangles.push([topOrder[segment], bottomOrder[next], bottomOrder[segment]])
  }

  const positions: number[] = []
  const emit = (a: Vector3, b: Vector3, c: Vector3) => {
    const normal = new Vector3().subVectors(b, a).cross(new Vector3().subVectors(c, a))
    const centroid = new Vector3().add(a).add(b).add(c).multiplyScalar(1 / 3)
    const outward = centroid.clone().sub(INTERIOR)
    const ordered = normal.dot(outward) >= 0 ? [a, b, c] : [a, c, b]
    for (const vertex of ordered) positions.push(vertex.x, vertex.y, vertex.z)
  }

  for (const [a, b, c] of triangles) {
    emit(vertices[a], vertices[b], vertices[c])
  }

  const geometry = new BufferGeometry()
  geometry.setAttribute('position', new Float32BufferAttribute(positions, 3))
  geometry.computeVertexNormals()
  geometry.computeBoundingBox()
  geometry.computeBoundingSphere()
  return geometry
}

export interface RoundBrilliantTopologyReport {
  positionCount: number
  triangleCount: number
  weldedVertexCount: number
  edgeCount: number
  boundaryEdgeCount: number
  nonManifoldEdgeCount: number
  inconsistentlyWoundEdgeCount: number
  duplicateTriangleCount: number
  watertight: boolean
}

export function analyzeRoundBrilliantTopology(
  geometry: BufferGeometry,
): RoundBrilliantTopologyReport {
  const position = geometry.getAttribute('position')
  const index = geometry.getIndex()
  const elementCount = index ? index.count : position.count

  const keyToId = new Map<string, number>()
  const vertexId = (vertexIndex: number) => {
    const x = position.getX(vertexIndex)
    const y = position.getY(vertexIndex)
    const z = position.getZ(vertexIndex)
    const key = `${x.toFixed(6)},${y.toFixed(6)},${z.toFixed(6)}`
    const existing = keyToId.get(key)
    if (existing !== undefined) return existing
    const id = keyToId.size
    keyToId.set(key, id)
    return id
  }

  const edges = new Map<string, { forward: number; backward: number }>()
  const recordedEdges = new Set<string>()
  let duplicateTriangleCount = 0

  for (let offset = 0; offset < elementCount; offset += 3) {
    const corner = index
      ? [index.getX(offset), index.getX(offset + 1), index.getX(offset + 2)]
      : [offset, offset + 1, offset + 2]
    const a = vertexId(corner[0])
    const b = vertexId(corner[1])
    const c = vertexId(corner[2])

    const triangleKey = [a, b, c].sort((left, right) => left - right).join(':')
    if (recordedEdges.has(triangleKey)) duplicateTriangleCount += 1
    else recordedEdges.add(triangleKey)

    for (const [from, to] of [
      [a, b],
      [b, c],
      [c, a],
    ]) {
      const key = from < to ? `${from}:${to}` : `${to}:${from}`
      const entry = edges.get(key) ?? { forward: 0, backward: 0 }
      if (from < to) entry.forward += 1
      else entry.backward += 1
      edges.set(key, entry)
    }
  }

  let boundaryEdgeCount = 0
  let nonManifoldEdgeCount = 0
  let inconsistentlyWoundEdgeCount = 0
  for (const entry of edges.values()) {
    const total = entry.forward + entry.backward
    if (total === 1) boundaryEdgeCount += 1
    if (total > 2) nonManifoldEdgeCount += 1
    if (total === 2 && (entry.forward === 2 || entry.backward === 2)) {
      inconsistentlyWoundEdgeCount += 1
    }
  }

  return Object.freeze({
    positionCount: elementCount,
    triangleCount: elementCount / 3,
    weldedVertexCount: keyToId.size,
    edgeCount: edges.size,
    boundaryEdgeCount,
    nonManifoldEdgeCount,
    inconsistentlyWoundEdgeCount,
    duplicateTriangleCount,
    watertight:
      boundaryEdgeCount === 0 &&
      nonManifoldEdgeCount === 0 &&
      inconsistentlyWoundEdgeCount === 0 &&
      duplicateTriangleCount === 0,
  })
}
