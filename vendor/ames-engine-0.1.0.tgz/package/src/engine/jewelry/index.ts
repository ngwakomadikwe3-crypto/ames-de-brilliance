export {
  analyzeRoundBrilliantTopology,
  createRoundBrilliantGeometry,
  ROUND_BRILLIANT_TRIANGLE_COUNT,
  ROUND_BRILLIANT_FACET_GROUPS,
  ROUND_BRILLIANT_PROPORTIONS,
} from './createRoundBrilliantGeometry'
export type { RoundBrilliantTopologyReport } from './createRoundBrilliantGeometry'
export { TemporaryJewelry } from './TemporaryJewelry'
export { RoundBrilliantDiamond } from './RoundBrilliantDiamond'
export { RoundBrilliantGem } from './RoundBrilliantGem'
export { SolitaireRing, TEST_SOLITAIRE_RING_URL } from './SolitaireRing'
export {
  JewelryGlbModel,
  DEFAULT_JEWELRY_GLB_URL,
  JEWELRY_FIT_SIZE,
  JEWELRY_TURNTABLE_SPEED,
} from './JewelryGlbModel'
export {
  applyJewelryMaterials,
  bouncesForGeometry,
  classifyJewelrySurface,
  createGemMaterial,
  createMetalMaterial,
  gemQualityForGeometry,
  isPureGemMesh,
  JEWELRY_DIAMOND_OPTICS,
  JEWELRY_DIAMOND_PROFILE,
  JEWELRY_METAL_PROFILE,
  mobileGemProfile,
} from './jewelryGlbMaterials'
export type { GemQualityProfile, JewelryMaterialResult } from './jewelryGlbMaterials'
export {
  createCanonicalRoundBrilliantGeometry,
  fingerprintRoundBrilliantGeometry,
  getRoundBrilliantDiagnostics,
} from './canonicalRoundBrilliantGeometry'
export type { RoundBrilliantGeometryDiagnostics } from './canonicalRoundBrilliantGeometry'
