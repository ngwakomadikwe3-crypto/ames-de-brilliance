import { createPortal, useFrame } from '@react-three/fiber'
import { useGLTF, MeshRefractionMaterial } from '@react-three/drei'
import { useEffect, useMemo, useRef } from 'react'
import { Box3, Group, Mesh, Vector3 } from 'three'
import type { BufferGeometry, Matrix4, Texture } from 'three'
import {
  applyJewelryMaterials,
  gemQualityForGeometry,
  isPureGemMesh,
  JEWELRY_DIAMOND_OPTICS,
  mobileGemProfile,
} from './jewelryGlbMaterials'
import type { GemQualityProfile } from './jewelryGlbMaterials'
import { RoundBrilliantGem } from './RoundBrilliantGem'
import { MountedCenterDiamondMaterial } from '../materials/MountedCenterDiamondMaterial'
import type { ViewerQualityProfile } from '../renderer/viewerQuality'

/** Approved mounted production asset for the live dev viewer. */
export const DEFAULT_JEWELRY_GLB_URL = '/models/mounted-reference-ring.glb'

/** Longest-axis fit size in world units, matched to the calibrated camera framing. */
export const JEWELRY_FIT_SIZE = 2.6

/** Idle turntable angular speed in radians per second. */
export const JEWELRY_TURNTABLE_SPEED = 0.18

/** How quickly the turntable eases in after interaction (higher = quicker). */
const TURNTABLE_EASE = 2.5

interface ExtractedGem {
  key: string
  geometry: BufferGeometry
  matrix: Matrix4
  profile: GemQualityProfile
}

interface ExtractedCenterStone {
  key: string
  matrix: Matrix4
}

/**
 * The legacy prepared asset exposes its unsuitable centre stone as the
 * `Diamond` node with the `dmesh` geometry. The approved mounted reference
 * asset keeps its imported centre stone and bypasses this replacement path.
 */
const CENTER_STONE_NODE = 'diamond'
const CENTER_STONE_GEOMETRY = 'dmesh'

function isCenterStoneMesh(mesh: Mesh): boolean {
  const nodeName = (mesh.name ?? '').trim().toLowerCase()
  if (nodeName === CENTER_STONE_NODE) return true
  const geometryName = (mesh.geometry?.name ?? '').trim().toLowerCase()
  return geometryName === CENTER_STONE_GEOMETRY
}

export function isReferenceDiamond001Mesh(mesh: Mesh): boolean {
  const metadata = mesh.userData as {
    ames_asset_id?: unknown
    ames_role?: unknown
    ames_part_id?: unknown
    ames_source_binding?: unknown
  }
  return metadata.ames_asset_id === 'reference-diamond-001'
    && metadata.ames_role === 'center'
    && metadata.ames_part_id === 'C00'
    && metadata.ames_source_binding === 'center-stone'
}

function findReferenceDiamond001Mesh(root: Group): Mesh | undefined {
  let center: Mesh | undefined
  root.traverse((object) => {
    if (!center && object instanceof Mesh && isReferenceDiamond001Mesh(object)) center = object
  })
  return center
}

function collectGemMeshes(root: Group): Mesh[] {
  const gems: Mesh[] = []
  root.traverse((object) => {
    if (isPureGemMesh(object as Mesh)) gems.push(object as Mesh)
  })
  return gems
}

/**
 * Generic real-jewelry GLB model.
 *
 * Preserves the loaded node and material hierarchy and only adds a
 * centering/scaling wrapper so an arbitrary catalog asset fits the calibrated
 * camera. Geometry is never rewritten. Gem meshes are lifted out of the clone
 * and rendered with the ray-marched refraction material (real internal
 * reflections and facet contrast); metal keeps a physically based material.
 *
 * A smooth idle turntable spins the fitted model around its vertical axis and
 * eases to a stop while `interactionRef` is true, then eases back in.
 */
export function JewelryGlbModel({
  url,
  envMap,
  fit = JEWELRY_FIT_SIZE,
  turntable = true,
  interactionRef,
  quality,
  onReady,
}: {
  url: string
  envMap?: Texture | null
  fit?: number
  turntable?: boolean
  /** Set to true while the user is dragging so the turntable eases to a stop. */
  interactionRef?: { current: boolean }
  quality: ViewerQualityProfile
  onReady?: () => void
}) {
  const { scene } = useGLTF(url)
  const spin = useRef(0)
  const pivot = useRef<Group>(null)

  useEffect(() => { onReady?.() }, [onReady, scene])

  const { root, gems, centerStones, scale, materials, mountedCenter } = useMemo(() => {
    const root = scene.clone(true)

    const box = new Box3().setFromObject(root)
    const size = box.getSize(new Vector3())
    const center = box.getCenter(new Vector3())
    const scale = fit / Math.max(size.x, size.y, size.z, 0.001)
    root.position.sub(center)
    root.updateMatrixWorld(true)

    // Capture gem transforms in pivot space, then lift them out of the metal hierarchy.
    // Without an environment the ray-marched path is unavailable, so gems stay in
    // the hierarchy and receive the physical fallback material instead.
    const gemMeshes = envMap ? collectGemMeshes(root) : []
    const mountedCenter = url === DEFAULT_JEWELRY_GLB_URL ? findReferenceDiamond001Mesh(root) : undefined
    const preserveImportedCenterStone = Boolean(mountedCenter)
    const centerMeshes = preserveImportedCenterStone ? [] : gemMeshes.filter(isCenterStoneMesh)
    const extractedGemMeshes = preserveImportedCenterStone
      ? gemMeshes.filter((mesh) => mesh !== mountedCenter)
      : gemMeshes
    const gems: ExtractedGem[] = extractedGemMeshes
      .map((mesh, index) => ({
        key: `${mesh.name || 'gem'}-${index}`,
        geometry: mesh.geometry,
        matrix: mesh.matrixWorld.clone(),
        profile: gemQualityForGeometry(mesh.geometry),
      }))
    const centerStones: ExtractedCenterStone[] = centerMeshes.map((mesh, index) => ({
      key: `${mesh.name || 'center-stone'}-${index}`,
      matrix: mesh.matrixWorld.clone(),
    }))
    for (const mesh of extractedGemMeshes) mesh.parent?.remove(mesh)

    const assignment = applyJewelryMaterials(root, envMap, {
      preserveMesh: mountedCenter ? (mesh) => mesh === mountedCenter : undefined,
    })
    return { root, gems, centerStones, scale, materials: assignment.materials, mountedCenter }
  }, [scene, envMap, fit, url])

  useEffect(() => () => {
    for (const material of materials) material.dispose()
  }, [materials])

  useEffect(() => () => {
    useGLTF.clear(url)
  }, [url])

  useFrame((_, delta) => {
    const interacting = interactionRef?.current === true
    const target = turntable && !interacting ? JEWELRY_TURNTABLE_SPEED : 0
    spin.current += (target - spin.current) * Math.min(1, delta * TURNTABLE_EASE)
    if (pivot.current) pivot.current.rotation.y += spin.current * delta
  })

  return (
    <group ref={pivot}>
      <group scale={scale}>
        <primitive object={root} />
        {mountedCenter && envMap ? createPortal(<MountedCenterDiamondMaterial quality={quality} center={mountedCenter} />, mountedCenter) : null}
        {envMap ? centerStones.map((stone) => (
          <RoundBrilliantGem
            key={stone.key}
            envMap={envMap}
            matrix={stone.matrix}
            constrained={quality.tier !== 'HIGH'}
          />
        )) : null}
        {envMap ? gems.map((gem) => {
          const gemQuality = quality.tier === 'HIGH' ? gem.profile : mobileGemProfile(gem.profile)
          return (
            <mesh
              key={gem.key}
              geometry={gem.geometry}
              dispose={null}
              matrixAutoUpdate={false}
              ref={(mesh) => {
                if (!mesh) return
                mesh.matrix.copy(gem.matrix)
                mesh.matrixWorldNeedsUpdate = true
              }}
            >
              {quality.refraction ? <MeshRefractionMaterial
                envMap={envMap}
                ior={JEWELRY_DIAMOND_OPTICS.ior}
                fresnel={gemQuality.fresnel}
                aberrationStrength={quality.tier === 'IOS_LOW' || quality.tier === 'LOW' ? 0 : gemQuality.aberrationStrength}
                fastChroma={JEWELRY_DIAMOND_OPTICS.fastChroma}
                bounces={Math.min(gemQuality.bounces, quality.gemBounces)}
                color="#ffffff"
                toneMapped
              /> : <meshStandardMaterial
                envMap={envMap}
                color="#e8edf5"
                roughness={0.12}
                metalness={0}
                envMapIntensity={1.25}
                toneMapped
              />}
            </mesh>
          )
        }) : null}
      </group>
    </group>
  )
}


