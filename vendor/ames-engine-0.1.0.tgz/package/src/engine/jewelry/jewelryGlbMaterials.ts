import { Color, MeshPhysicalMaterial } from 'three'
import type { BufferGeometry, Material, Mesh, MeshStandardMaterial, Object3D, Texture } from 'three'

export type JewelrySurfaceKind = 'gem' | 'metal' | 'other'

/**
 * Names observed on the prepared validation asset
 * (/models/diamond_ring_candidate_blender.glb):
 *   Ring/Circle002   -> material "Gold"    (band)
 *   Ring/Circle002_1 -> material "Dimond"  (pave on band)
 *   Ring/Diamond     -> material "Material"(centre stone)
 *   Ring/GEMS        -> material "Dimond"  (melee)
 * The exporter spells diamond as "Dimond", so both spellings are matched.
 */
const GEM_NAME = /diamond|dimond|gem|stone|crystal|brilliant|ruby|emerald|sapphire|topaz|opal/i
const METAL_NAME = /gold|platinum|silver|rhodium|palladium|titanium|metal|ring|band|setting|shank/i

export function classifyJewelrySurface(nodeName?: string | null, materialName?: string | null): JewelrySurfaceKind {
  const material = materialName ?? ''
  if (GEM_NAME.test(material)) return 'gem'
  if (METAL_NAME.test(material)) return 'metal'
  const node = nodeName ?? ''
  if (GEM_NAME.test(node)) return 'gem'
  if (METAL_NAME.test(node)) return 'metal'
  return 'other'
}

export const JEWELRY_METAL_PROFILE = Object.freeze({
  metalness: 1,
  roughness: 0.14,
  clearcoat: 0.5,
  clearcoatRoughness: 0.18,
  envMapIntensity: 1.6,
})

/**
 * Diamond optics for the ray-marched refraction material. `bounces` (internal
 * reflections) and `fresnel` give facet contrast and white brilliance;
 * `aberrationStrength` is kept very small so dispersion reads as subtle fire
 * rather than obvious rainbow fringing.
 */
export const JEWELRY_DIAMOND_OPTICS = Object.freeze({
  ior: 2.417,
  fresnel: 0.12,
  aberrationStrength: 0.004,
  fastChroma: true,
  maxBounces: 5,
})

export interface GemQualityProfile {
  bounces: number
  fresnel: number
  aberrationStrength: number
}

/**
 * Per-surface gem quality. The hero centre stone gets the most internal light
 * return; the dense melee and pave get progressively calmer optics (and fewer
 * bounces) so small stones read clean instead of noisy.
 */
export function gemQualityForGeometry(geometry?: BufferGeometry): GemQualityProfile {
  const count = geometry?.getAttribute('position')?.count ?? 0
  if (count > 20000) return { bounces: 2, fresnel: 0.09, aberrationStrength: 0 }
  if (count > 3000) return { bounces: 3, fresnel: 0.1, aberrationStrength: 0.002 }
  return {
    bounces: JEWELRY_DIAMOND_OPTICS.maxBounces,
    fresnel: JEWELRY_DIAMOND_OPTICS.fresnel,
    aberrationStrength: JEWELRY_DIAMOND_OPTICS.aberrationStrength,
  }
}

/** Lower-cost, calmer profile for touch/small screens. */
export function mobileGemProfile(profile: GemQualityProfile): GemQualityProfile {
  return {
    bounces: Math.max(1, profile.bounces - 2),
    fresnel: profile.fresnel * 0.85,
    aberrationStrength: profile.aberrationStrength * 0.5,
  }
}

export const JEWELRY_DIAMOND_PROFILE = Object.freeze({
  roughness: 0.02,
  thickness: 0.6,
  ior: 2.417,
  envMapIntensity: 2.2,
  dispersion: 0.12,
})

function sourceColor(source?: Material): Color {
  const color = (source as MeshStandardMaterial | undefined)?.color
  return color ? color.clone() : new Color(0xd4d4d4)
}

/** Physically based polished metal that keeps the asset's source colour. */
export function createMetalMaterial(source?: Material, envMap?: Texture | null): MeshPhysicalMaterial {
  const material = new MeshPhysicalMaterial({
    color: sourceColor(source),
    metalness: JEWELRY_METAL_PROFILE.metalness,
    roughness: JEWELRY_METAL_PROFILE.roughness,
    clearcoat: JEWELRY_METAL_PROFILE.clearcoat,
    clearcoatRoughness: JEWELRY_METAL_PROFILE.clearcoatRoughness,
    envMapIntensity: JEWELRY_METAL_PROFILE.envMapIntensity,
    envMap: envMap ?? null,
  })
  material.name = `${source?.name ?? 'metal'}::enhanced`
  return material
}

/**
 * Physical gem material. Used only as a fallback when a mesh cannot be rendered
 * with the refraction path; the live viewer routes gems to the ray-marched
 * refraction material instead.
 */
export function createGemMaterial(source?: Material, envMap?: Texture | null): MeshPhysicalMaterial {
  const material = new MeshPhysicalMaterial({
    color: 0xffffff,
    metalness: 0,
    roughness: JEWELRY_DIAMOND_PROFILE.roughness,
    transmission: 1,
    thickness: JEWELRY_DIAMOND_PROFILE.thickness,
    ior: JEWELRY_DIAMOND_PROFILE.ior,
    envMapIntensity: JEWELRY_DIAMOND_PROFILE.envMapIntensity,
    attenuationColor: new Color(0xffffff),
    attenuationDistance: Infinity,
    flatShading: true,
    envMap: envMap ?? null,
  })
  const refractive = material as MeshPhysicalMaterial & { dispersion?: number }
  if ('dispersion' in refractive) refractive.dispersion = JEWELRY_DIAMOND_PROFILE.dispersion
  material.name = `${source?.name ?? 'gem'}::diamond`
  return material
}

/** Backwards-compatible bounce lookup derived from the shared quality profile. */
export function bouncesForGeometry(geometry?: BufferGeometry): number {
  return gemQualityForGeometry(geometry).bounces
}

/** True only when every surface on the mesh is a gem, so extraction is safe. */
export function isPureGemMesh(mesh: Mesh): boolean {
  if (!mesh.isMesh) return false
  const sources = Array.isArray(mesh.material) ? mesh.material : [mesh.material]
  return sources.length > 0 && sources.every((source) => classifyJewelrySurface(mesh.name, source?.name) === 'gem')
}

export interface JewelryMaterialResult {
  gemSurfaces: number
  metalSurfaces: number
  otherSurfaces: number
  materials: Material[]
}

/**
 * Replace an imported GLB clone's materials with premium ones while leaving
 * geometry, transforms and node structure untouched. Metal keeps the source
 * colour; any gem surface still present gets the physical fallback (the viewer
 * extracts pure gem meshes for the refraction path before calling this).
 * Every material the viewer creates is returned so its owner can dispose of it.
 */
export function applyJewelryMaterials(
  root: Object3D,
  envMap?: Texture | null,
  options?: { preserveMesh?: (mesh: Mesh) => boolean },
): JewelryMaterialResult {
  const result: JewelryMaterialResult = { gemSurfaces: 0, metalSurfaces: 0, otherSurfaces: 0, materials: [] }

  root.traverse((object) => {
    const mesh = object as Mesh
    if (!mesh.isMesh) return
    if (options?.preserveMesh?.(mesh)) return
    const sources = Array.isArray(mesh.material) ? mesh.material : [mesh.material]

    const enhanced = sources.map((source) => {
      const kind = classifyJewelrySurface(object.name, source?.name)
      let material: Material
      if (kind === 'gem') {
        result.gemSurfaces += 1
        material = createGemMaterial(source, envMap)
      } else if (kind === 'metal') {
        result.metalSurfaces += 1
        material = createMetalMaterial(source, envMap)
      } else {
        result.otherSurfaces += 1
        const clone = (source?.clone() as MeshPhysicalMaterial) ?? new MeshPhysicalMaterial()
        clone.envMap = envMap ?? null
        material = clone
      }
      material.needsUpdate = true
      result.materials.push(material)
      return material
    })

    mesh.material = Array.isArray(mesh.material) ? enhanced : enhanced[0]
  })

  return result
}
