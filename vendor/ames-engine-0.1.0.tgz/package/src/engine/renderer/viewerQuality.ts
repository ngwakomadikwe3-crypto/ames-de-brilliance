export type ViewerQualityTier = 'HIGH' | 'MEDIUM' | 'LOW' | 'IOS_LOW' | 'SAFE'

export interface ViewerRuntimeProfile {
  coarsePointer: boolean
  width: number
  devicePixelRatio: number
  deviceMemory?: number
  hardwareConcurrency?: number
  maxTextureSize?: number
  webKitMobile?: boolean
  forcedTier?: ViewerQualityTier
}

export interface ViewerQualityProfile {
  tier: ViewerQualityTier
  dpr: [number, number]
  gemBounces: number
  centerEnvironmentSize: number
  contactShadows: boolean
  refraction: boolean
  autoRotate: boolean
}

export function chooseViewerQuality(runtime: ViewerRuntimeProfile): ViewerQualityTier {
  if (runtime.forcedTier) return runtime.forcedTier
  const constrainedMemory = runtime.deviceMemory !== undefined && runtime.deviceMemory <= 2
  const constrainedCpu = runtime.hardwareConcurrency !== undefined && runtime.hardwareConcurrency <= 4
  const constrainedGpu = runtime.maxTextureSize !== undefined && runtime.maxTextureSize < 4096
  // WebKit measurements show the refraction path is unsafe even at IOS_LOW;
  // start in the non-refractive SAFE profile and let the user keep orbiting.
  if (runtime.webKitMobile) return 'SAFE'
  if (constrainedMemory || constrainedGpu || (constrainedCpu && runtime.coarsePointer)) return 'LOW'
  if (runtime.coarsePointer || runtime.width <= 900 || runtime.devicePixelRatio > 1.5 || constrainedCpu) return 'MEDIUM'
  return 'HIGH'
}

export function qualityProfile(tier: ViewerQualityTier): ViewerQualityProfile {
  if (tier === 'SAFE') return { tier, dpr: [0.75, 1], gemBounces: 1, centerEnvironmentSize: 32, contactShadows: false, refraction: false, autoRotate: false }
  if (tier === 'IOS_LOW') return { tier, dpr: [1, 1.25], gemBounces: 1, centerEnvironmentSize: 64, contactShadows: false, refraction: true, autoRotate: true }
  if (tier === 'LOW') return { tier, dpr: [1, 1], gemBounces: 2, centerEnvironmentSize: 128, contactShadows: false, refraction: true, autoRotate: true }
  if (tier === 'MEDIUM') return { tier, dpr: [1, 1.5], gemBounces: 4, centerEnvironmentSize: 192, contactShadows: true, refraction: true, autoRotate: true }
  return { tier, dpr: [1, 2], gemBounces: 6, centerEnvironmentSize: 256, contactShadows: true, refraction: true, autoRotate: true }
}

export function nextLowerViewerQuality(tier: ViewerQualityTier): ViewerQualityTier {
  if (tier === 'HIGH') return 'MEDIUM'
  if (tier === 'MEDIUM') return 'LOW'
  if (tier === 'IOS_LOW' || tier === 'LOW') return 'SAFE'
  return 'SAFE'
}

export function readViewerRuntime(): ViewerRuntimeProfile {
  if (typeof window === 'undefined') return { coarsePointer: false, width: 1200, devicePixelRatio: 1 }
  let maxTextureSize: number | undefined
  try {
    const canvas = document.createElement('canvas')
    const gl = canvas.getContext('webgl2') ?? canvas.getContext('webgl')
    maxTextureSize = gl?.getParameter(gl.MAX_TEXTURE_SIZE)
  } catch { /* Capability probing is best effort. */ }
  return {
    forcedTier: (() => { const value = new URLSearchParams(window.location.search).get('quality')?.toUpperCase(); return value === 'HIGH' || value === 'MEDIUM' || value === 'LOW' || value === 'IOS_LOW' || value === 'SAFE' ? value : undefined })(),
    coarsePointer: typeof window.matchMedia === 'function' && window.matchMedia('(pointer: coarse)').matches,
    width: window.innerWidth,
    devicePixelRatio: window.devicePixelRatio || 1,
    deviceMemory: (navigator as Navigator & { deviceMemory?: number }).deviceMemory,
    hardwareConcurrency: navigator.hardwareConcurrency,
    maxTextureSize,
    webKitMobile: /AppleWebKit/i.test(navigator.userAgent) && !/Chrome|CriOS|Edg/i.test(navigator.userAgent) && (typeof window.matchMedia === 'function' && window.matchMedia('(pointer: coarse)').matches),
  }
}
