import { useCallback, useRef, useState } from 'react'
import { useThree } from '@react-three/fiber'
import { Group } from 'three'
import type { Texture } from 'three'
import { JewelryGlbModel } from '../jewelry/JewelryGlbModel'
import { useControlledTurntable } from './useControlledTurntable'
import type { ViewerQualityProfile } from './viewerQuality'
export function ControlledJewelryModel({ url, envMap, enabled, interacting, resetToken, quality, onReady }: {
  url: string; envMap: Texture; enabled: boolean; interacting: boolean; resetToken?: number;
  quality: ViewerQualityProfile; onReady?: () => void;
}) {
  const pivot = useRef<Group>(null)
  const [ready, setReady] = useState(false)
  const invalidate = useThree(state => state.invalidate)
  const handleReady = useCallback(() => { setReady(true); onReady?.() }, [onReady])
  useControlledTurntable(pivot, enabled, ready, interacting, resetToken, invalidate)
  return <group ref={pivot} name="ames-controlled-turntable"><JewelryGlbModel url={url} envMap={envMap} turntable={false} quality={quality} onReady={handleReady} /></group>
}
