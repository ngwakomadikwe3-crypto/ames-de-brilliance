/**
 * Premium jewelry studio lighting for the real GLB viewer.
 *
 * Soft warm key, cool fill and a back rim keep facets alive without blowing
 * highlights; reflections are carried mainly by the calibrated studio
 * environment so metal reads as polished rather than plastic. Intensities are
 * deliberately conservative under the shared ACES/0.9-exposure canvas.
 */
export function JewelryStudioLighting() {
  return (
    <>
      <ambientLight intensity={0.12} />
      <directionalLight position={[3.5, 4.5, 3.5]} intensity={1.9} color="#fff3e0" />
      <directionalLight position={[-4, 1.5, 2.5]} intensity={0.85} color="#cfdfff" />
      <directionalLight position={[0, 3.5, -4.5]} intensity={1.5} color="#ffffff" />
      <spotLight position={[0, 5, -3]} intensity={1.1} color="#ffffff" angle={0.55} penumbra={1} />
    </>
  )
}
