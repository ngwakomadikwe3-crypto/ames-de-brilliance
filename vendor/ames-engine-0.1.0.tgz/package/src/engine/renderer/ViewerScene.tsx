import { Suspense, useEffect, useMemo, useRef, useState } from 'react'
import { useFrame } from '@react-three/fiber'
import { ContactShadows } from '@react-three/drei'
import type { BufferGeometry, CubeTexture } from 'three'
import { DIAMOND_CALIBRATION } from '../calibration'
import { JewelryGlbModel } from '../jewelry/JewelryGlbModel'
import { RoundBrilliantDiamond } from '../jewelry/RoundBrilliantDiamond'
import { DiamondEnvironment } from './DiamondEnvironment'
import { createDiamondDisplayEnvironment } from './createDiamondDisplayEnvironment'
import { createDiamondStudioEnvironment } from './createDiamondStudioEnvironment'
import { JewelryStudioLighting } from './JewelryStudioLighting'
import { StudioLighting } from './StudioLighting'
import { ViewerControls } from './ViewerControls'
import type { ViewerQualityProfile, ViewerQualityTier } from './viewerQuality'

function QualityGovernor({ tier, onDowngrade }: { tier: ViewerQualityTier; onDowngrade: () => void }) {
  const samples = useRef<number[]>([])
  const lastChange = useRef(0)
  const badWindows = useRef(0)
  useFrame((_, delta) => {
    samples.current.push(delta * 1000)
    if (samples.current.length < 45) return
    const average = samples.current.reduce((sum, value) => sum + value, 0) / samples.current.length
    samples.current = []
    const now = performance.now()
    if (now - lastChange.current < 6000) return
    const threshold = tier === 'HIGH' ? 24 : tier === 'MEDIUM' || tier === 'IOS_LOW' ? 20 : 18
    if (1000 / average < threshold) badWindows.current += 1
    else badWindows.current = 0
    if (badWindows.current >= 3 && tier !== 'SAFE') {
      lastChange.current = now
      badWindows.current = 0
      onDowngrade()
    }
  })
  return null
}

export function ViewerScene({
  diamondRotationY,
  geometry,
  environment: providedEnvironment,
  controlsEnabled = true,
  modelUrl,
  procedural = false,
  quality,
  onQualityDowngrade,
  onModelReady,
}: {
  diamondRotationY?: number
  geometry?: BufferGeometry
  environment?: CubeTexture
  controlsEnabled?: boolean
  /** Real catalog GLB to render as the primary live object. */
  modelUrl?: string
  /** Explicit opt-in to the procedural round-brilliant path. */
  procedural?: boolean
  quality: ViewerQualityProfile
  onQualityDowngrade: () => void
  onModelReady?: () => void
}) {
  const generatedEnvironment = useMemo(() => createDiamondStudioEnvironment(), [])
  const displayEnvironment = useMemo(() => createDiamondDisplayEnvironment(), [])
  const envMap = providedEnvironment ?? generatedEnvironment
  useEffect(() => () => {
    generatedEnvironment.dispose()
    displayEnvironment.dispose()
  }, [generatedEnvironment, displayEnvironment])

  const interacting = useRef(false)
  const [isInteracting, setIsInteracting] = useState(false)
  const liveGlb = !procedural && Boolean(modelUrl)
  // Gems need a high-contrast environment; the calibration room reads grey.
  const activeEnvMap = liveGlb ? displayEnvironment : envMap

  return (
    <>
      <color attach="background" args={[DIAMOND_CALIBRATION.background]} />
      <QualityGovernor tier={quality.tier} onDowngrade={onQualityDowngrade} />
      {liveGlb ? <JewelryStudioLighting /> : <StudioLighting />}
      <DiamondEnvironment envMap={activeEnvMap} />
      {procedural
        ? <RoundBrilliantDiamond envMap={envMap} geometry={geometry} rotationY={diamondRotationY} />
        : modelUrl
          ? (
              <Suspense fallback={null}>
                <JewelryGlbModel url={modelUrl} envMap={activeEnvMap} interactionRef={interacting} turntable={quality.autoRotate} quality={quality} onReady={onModelReady} />
              </Suspense>
            )
          : <RoundBrilliantDiamond envMap={envMap} geometry={geometry} rotationY={diamondRotationY} />}
      {liveGlb
        ? quality.contactShadows && !isInteracting ? <ContactShadows position={[0, -1.35, 0]} opacity={0.55} scale={6} blur={quality.tier === 'HIGH' ? 2.6 : 3.2} far={3.2} color="#000000" /> : null
        : null}
      {controlsEnabled ? <ViewerControls onInteractionChange={(active) => { interacting.current = active; setIsInteracting(active) }} /> : null}
    </>
  )
}
