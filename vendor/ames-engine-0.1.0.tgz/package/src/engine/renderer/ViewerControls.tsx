import { OrbitControls } from '@react-three/drei'
import { useThree } from '@react-three/fiber'
import { useEffect, useRef } from 'react'
import { Spherical } from 'three'
import type { OrbitControls as OrbitControlsImpl } from 'three-stdlib'
import { cameraFraming, CAMERA_MIN_DISTANCE, CAMERA_MAX_DISTANCE } from './cameraFraming'
import type { CameraPreset } from './cameraFraming'
export function ViewerControls({ onInteractionChange, cameraPreset, zoom, resetToken }: {
  onInteractionChange?: (active: boolean) => void
  cameraPreset?: CameraPreset
  zoom?: number
  resetToken?: number
}) {
  const controls = useRef<OrbitControlsImpl>(null)
  const camera = useThree(state => state.camera)
  const invalidate = useThree(state => state.invalidate)
  useEffect(() => {
    if (!cameraPreset || !controls.current) return
    // Clear prior damping deltas so a reset/preset cannot drift toward the old orbit.
    const damping = controls.current.enableDamping
    controls.current.enableDamping = false
    controls.current.update()
    controls.current.reset()
    const framing = cameraFraming(cameraPreset, zoom)
    controls.current.target.set(0, 0, 0)
    camera.position.setFromSpherical(new Spherical(framing.radius, framing.phi, framing.theta))
    controls.current.update()
    controls.current.enableDamping = damping
    // Request the committed camera frame after React/R3F finishes this update.
    const frame = requestAnimationFrame(invalidate)
    // Zoom is applied separately so zoom commands retain a manually chosen angle.
    return () => cancelAnimationFrame(frame)
  }, [cameraPreset, resetToken, camera, invalidate])
  useEffect(() => {
    if (zoom === undefined || !controls.current) return
    const target = controls.current.target
    camera.position.sub(target).setLength(cameraFraming(cameraPreset ?? 'three_quarter', zoom).radius).add(target)
    controls.current.update()
    const frame = requestAnimationFrame(invalidate)
    return () => cancelAnimationFrame(frame)
  }, [zoom, resetToken, camera, invalidate])
  return <OrbitControls ref={controls} enablePan={false} enableDamping dampingFactor={0.07}
    minDistance={CAMERA_MIN_DISTANCE} maxDistance={CAMERA_MAX_DISTANCE}
    minPolarAngle={Math.PI * 0.15} maxPolarAngle={Math.PI * 0.85}
    onStart={() => onInteractionChange?.(true)} onEnd={() => onInteractionChange?.(false)} />
}
