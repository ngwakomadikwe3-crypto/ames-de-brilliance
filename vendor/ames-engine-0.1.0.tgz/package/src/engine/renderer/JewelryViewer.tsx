import { Canvas } from '@react-three/fiber'
import { ACESFilmicToneMapping, SRGBColorSpace } from 'three'
import type { BufferGeometry, CubeTexture } from 'three'
import { useEffect, useState } from 'react'
import type { CSSProperties } from 'react'
import { DIAMOND_CALIBRATION } from '../calibration'
import { getRoundBrilliantDiagnostics } from '../jewelry/canonicalRoundBrilliantGeometry'
import { ViewerScene } from './ViewerScene'
import { chooseViewerQuality, nextLowerViewerQuality, qualityProfile, readViewerRuntime } from './viewerQuality'

export const DIAMOND_VIEWER_CAMERA = {
  position: [...DIAMOND_CALIBRATION.camera.position] as [number, number, number],
  fov: DIAMOND_CALIBRATION.camera.fov,
  near: DIAMOND_CALIBRATION.camera.near,
  far: DIAMOND_CALIBRATION.camera.far,
}

export const DIAMOND_TONE_MAPPING_EXPOSURE = DIAMOND_CALIBRATION.camera.exposure

export interface JewelryViewerProps {
  className?: string
  diamondRotationY?: number
  geometry?: BufferGeometry
  environment?: CubeTexture
  controlsEnabled?: boolean
  /** Real catalog GLB to render as the primary live object. */
  modelUrl?: string
  /** Explicit opt-in to the procedural round-brilliant path. */
  procedural?: boolean
  /** Called once the requested GLB has loaded into the live viewer. */
  onModelReady?: () => void
  style?: CSSProperties
}

export function JewelryViewer({
  className = '',
  diamondRotationY,
  geometry,
  environment,
  controlsEnabled = true,
  modelUrl,
  procedural = false,
  onModelReady,
  style,
}: JewelryViewerProps) {
  const [tier, setTier] = useState(() => chooseViewerQuality(readViewerRuntime()))
  useEffect(() => {
    const update = () => setTier(chooseViewerQuality(readViewerRuntime()))
    window.addEventListener('resize', update)
    return () => window.removeEventListener('resize', update)
  }, [])
  const quality = qualityProfile(tier)
  const classes = ['jewelry-viewer', className].filter(Boolean).join(' ')
  const diagnostics = geometry ? getRoundBrilliantDiagnostics(geometry) : undefined

  return (
    <section
      className={classes}
      role="region"
      aria-label="AMES Engine 3D jewelry viewer"
      data-geometry-uuid={diagnostics?.uuid}
      data-geometry-fingerprint={diagnostics?.fingerprint}
        data-environment-uuid={environment?.uuid}
        data-render-mode={procedural ? 'procedural' : modelUrl ? 'glb' : 'procedural'}
      data-model-url={modelUrl ?? undefined}
      data-quality-tier={quality.tier}
      style={style}
      >
      <Canvas
        camera={DIAMOND_VIEWER_CAMERA}
        dpr={quality.dpr}
        frameloop={quality.tier === 'SAFE' ? 'demand' : 'always'}
        gl={{
          antialias: quality.tier === 'HIGH' || quality.tier === 'MEDIUM',
          alpha: true,
          toneMapping: ACESFilmicToneMapping,
          outputColorSpace: SRGBColorSpace,
        }}
        onCreated={({ camera, gl }) => {
          camera.lookAt(...DIAMOND_CALIBRATION.camera.target)
          camera.updateMatrixWorld()
          gl.toneMappingExposure = DIAMOND_TONE_MAPPING_EXPOSURE
        }}
        shadows={quality.contactShadows}
      >
        <ViewerScene
          diamondRotationY={diamondRotationY}
          geometry={geometry}
          environment={environment}
          controlsEnabled={controlsEnabled}
          modelUrl={modelUrl}
          procedural={procedural}
          quality={quality}
          onQualityDowngrade={() => setTier(current => nextLowerViewerQuality(current))}
          onModelReady={onModelReady}
        />
      </Canvas>
    </section>
  )
}
