export type JewelryOpticsProfile = 'reference' | 'soft-studio' | 'clear-crystal' | 'gemstone-studio'

export interface JewelryOpticsSettings {
  environment: {
    base: { top: string; mid: string; bottom: string }
    darkFlag: string
  }
  lighting: {
    ambient: number
    key: number
    fill: number
    rim: number
    spot: number
  }
  metal: {
    roughness: number
    envMapIntensity: number
  }
  safeCenter: {
    roughness: number
    transmission: number
    thickness: number
    envMapIntensity: number
  }
  center: {
    fresnel: number
    color: [number, number, number]
  }
}

/**
 * Experimental optical looks for the representative-ring review lab.
 * `reference` is the existing customer presentation and must remain the default.
 * These are rendering profiles, not gemstone, alloy, or stock specifications.
 */
export const JEWELRY_OPTICS_PROFILES: Record<JewelryOpticsProfile, JewelryOpticsSettings> = {
  reference: {
    environment: {
      base: { top: '#20262e', mid: '#0d1015', bottom: '#06070a' },
      darkFlag: '#0b0d11',
    },
    lighting: { ambient: 0.12, key: 1.9, fill: 0.85, rim: 1.5, spot: 1.1 },
    metal: { roughness: 0.14, envMapIntensity: 1.6 },
    safeCenter: { roughness: 0.025, transmission: 0.2, thickness: 0, envMapIntensity: 2 },
    center: { fresnel: 0.04, color: [1.8, 1.8, 1.8] },
  },
  'soft-studio': {
    environment: {
      base: { top: '#2b3036', mid: '#171c22', bottom: '#0e1115' },
      darkFlag: '#1a2026',
    },
    lighting: { ambient: 0.075, key: 1.7, fill: 0.48, rim: 1.85, spot: 1.1 },
    metal: { roughness: 0.13, envMapIntensity: 0.95 },
    safeCenter: { roughness: 0.018, transmission: 0.44, thickness: 0.3, envMapIntensity: 1.75 },
    center: { fresnel: 0.06, color: [1.65, 1.65, 1.65] },
  },
  'gemstone-studio': {
    environment: {
      base: { top: '#a4adb4', mid: '#75818a', bottom: '#485661' },
      darkFlag: '#39454f',
    },
    lighting: { ambient: 0.08, key: 1.8, fill: 0.42, rim: 2.1, spot: 1.25 },
    metal: { roughness: 0.13, envMapIntensity: 1.55 },
    safeCenter: { roughness: 0.018, transmission: 0.82, thickness: 0.8, envMapIntensity: 1.8 },
    center: { fresnel: 0.1, color: [1.7, 1.7, 1.7] },
  },
  'clear-crystal': {
    environment: {
      base: { top: '#2b323b', mid: '#141920', bottom: '#0b0e13' },
      darkFlag: '#14181e',
    },
    lighting: { ambient: 0.12, key: 2, fill: 0.95, rim: 1.7, spot: 1.1 },
    metal: { roughness: 0.12, envMapIntensity: 1.7 },
    safeCenter: { roughness: 0.018, transmission: 0.65, thickness: 0.6, envMapIntensity: 1.7 },
    center: { fresnel: 0.09, color: [1.6, 1.6, 1.6] },
  },
}
