import { useEffect, useState } from 'react'
import { useThree } from '@react-three/fiber'
import { CubeTextureLoader, HalfFloatType, LinearFilter, LinearSRGBColorSpace, SRGBColorSpace } from 'three'
import { RGBMLoader } from 'three-stdlib'
import type { CubeTexture } from 'three'
interface StudioMaps { surface: CubeTexture; refraction: CubeTexture }
let shared: Promise<StudioMaps> | undefined
function loadStudio(): Promise<StudioMaps> {
  if (!shared) {
    const base = '/ames-engine/environments/studio-small-09-v1/'
    const faces = ['px', 'nx', 'py', 'ny', 'pz', 'nz']
    shared = Promise.all([
      new CubeTextureLoader().loadAsync(faces.map(face => base + face + '-display.webp')),
      new Promise<CubeTexture>((resolve, reject) => {
        new RGBMLoader().setDataType(HalfFloatType).setMaxRange(64).loadCubemap(
          faces.map(face => base + face + '-rgbm.png'), resolve, undefined, reject,
        )
      }),
    ]).then(([surface, refraction]) => {
      surface.colorSpace = SRGBColorSpace
      refraction.colorSpace = LinearSRGBColorSpace
      refraction.generateMipmaps = false // Decode before GPU filtering; no float render targets.
      refraction.minFilter = LinearFilter
      refraction.magFilter = LinearFilter
      refraction.userData.photographicHDR = true
      surface.needsUpdate = true; refraction.needsUpdate = true
      return { surface, refraction }
    }).catch(error => { shared = undefined; throw error })
  }
  return shared
}
/** Shared offline-processed studio asset; no external service or API calls at runtime. */
export function useGemstonePhotoEnvironment(enabled: boolean): StudioMaps | null {
  const canvas = useThree(state => state.gl.domElement)
  const [maps, setMaps] = useState<StudioMaps | null>(null)
  useEffect(() => {
    if (!enabled) return
    let active = true
    loadStudio().then(value => { if (active) setMaps(value) }).catch(() => {
      // Keep the generated studio available during an offline/asset outage.
    })
    return () => { active = false }
  }, [enabled])
  useEffect(() => {
    if (!enabled) return
    canvas.dataset.studioEnvironment = maps ? 'photographic' : 'generated-fallback'
    return () => { delete canvas.dataset.studioEnvironment }
  }, [canvas, enabled, maps])
  return enabled ? maps : null
}
