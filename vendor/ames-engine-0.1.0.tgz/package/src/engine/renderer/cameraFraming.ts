import { DIAMOND_CALIBRATION } from '../calibration'
export type CameraPreset = 'front' | 'three_quarter' | 'side' | 'setting'
export const CAMERA_MIN_DISTANCE = 2.5
export const CAMERA_MAX_DISTANCE = 8
export const CAMERA_BASE_DISTANCE = Math.hypot(...DIAMOND_CALIBRATION.camera.position)
export function cameraFraming(preset: CameraPreset, zoom = 1) {
  const angles = { front: [0, 75], three_quarter: [35, 40], side: [90, 75], setting: [35, 35] }
  const [theta, phi] = angles[preset] ?? angles.three_quarter
  const factor = Number.isFinite(zoom) && zoom > 0 ? zoom : 1
  return { theta: theta * Math.PI / 180, phi: Math.max(Math.PI * 0.15, Math.min(Math.PI * 0.85, phi * Math.PI / 180)), radius: Math.max(CAMERA_MIN_DISTANCE, Math.min(CAMERA_MAX_DISTANCE, CAMERA_BASE_DISTANCE / factor)) }
}
