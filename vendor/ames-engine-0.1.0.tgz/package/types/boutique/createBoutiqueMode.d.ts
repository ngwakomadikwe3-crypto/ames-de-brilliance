import type { AssetRecord, JewelryCategory, AccessTier } from '../assets';
import type { MetalFinish } from '../material-system';
import type { ViewerScene } from '../viewer';
export interface BoutiqueProduct {
    readonly id: string;
    readonly name: string;
    readonly category: JewelryCategory;
    readonly supportedMetals: readonly {
        readonly id: string;
        readonly name: string;
    }[];
    readonly supportedGemstones: readonly {
        readonly id: string;
        readonly name: string;
    }[];
    readonly access: {
        readonly tier: AccessTier;
        readonly locked: boolean;
        readonly reason: string | null;
    };
}
export interface BoutiqueState {
    readonly status: 'idle' | 'loading' | 'ready' | 'locked' | 'error' | 'disposed';
    readonly product: BoutiqueProduct | null;
    readonly requestedProduct: BoutiqueProduct | null;
    readonly error: string | null;
    readonly selectedMetalId: string | null;
    readonly selectedGemId: string | null;
    readonly favorite: boolean;
    readonly turntable: boolean;
    readonly pendingAction: 'favorite' | 'compare' | 'access' | null;
}
export interface BoutiqueModeOptions {
    /** Client presentation decision only. Servers must protect premium asset delivery. */
    canAccess?: (asset: AssetRecord) => boolean;
    onFavorite?: (asset: AssetRecord, favorite: boolean, signal: AbortSignal) => void | Promise<void>;
    onCompare?: (asset: AssetRecord, signal: AbortSignal) => void | Promise<void>;
    onRequestAccess?: (asset: AssetRecord, signal: AbortSignal) => void | Promise<void>;
    /** Borrow an existing viewer by default; a mounted Boutique owns its viewer. */
    ownsViewer?: boolean;
}
/** Product/access orchestration only: all graphics and interaction stay in the shared viewer. */
export declare function createBoutiqueMode(viewer: ViewerScene, options?: BoutiqueModeOptions): Readonly<{
    viewer: Readonly<{
        engine: import("..").AmesEngine;
        materials: Readonly<{
            metals: readonly import("..").MetalMaterialProfile[];
            gems: readonly import("..").GemMaterialProfile[];
            metal: (id: string) => import("..").MetalMaterialProfile;
            gem: (id: string) => import("..").GemMaterialProfile;
        }>;
        readonly paused: boolean;
        setPaused: (value: boolean) => void;
        readonly state: import("..").ViewerState;
        readonly performance: import("..").ViewerPerformanceStats;
        subscribe: (listener: () => void) => () => void;
        subscribePerformance: (listener: () => void) => () => void;
        loadAsset: (assetId: string) => Promise<import("..").EngineCommandResult>;
        execute: (command: import("..").EngineCommand) => Promise<import("..").EngineCommandResult>;
        resetCamera: () => void;
        resize: (width: number, height: number) => void;
        tick: (now: number) => void;
        resetPerformance: () => void;
        dispose: () => void;
    }>;
    readonly state: BoutiqueState;
    capabilities: Readonly<{
        favorite: boolean;
        compare: boolean;
        requestAccess: boolean;
    }>;
    listProducts: () => readonly BoutiqueProduct[];
    subscribe: (fn: () => void) => () => void;
    show: (assetId: string) => Promise<BoutiqueProduct>;
    selectMetal: (materialId: string, finish?: MetalFinish) => Promise<import("..").EngineCommandResult>;
    selectGem: (materialId: string) => Promise<import("..").EngineCommandResult>;
    refreshAccess: () => Promise<BoutiqueProduct>;
    toggleTurntable: () => Promise<import("..").EngineCommandResult>;
    resetView: () => void;
    toggleFavorite: () => Promise<void>;
    compare: () => Promise<void>;
    requestAccess: () => Promise<void>;
    dispose: () => Promise<void>;
}>;
export type BoutiqueMode = ReturnType<typeof createBoutiqueMode>;
