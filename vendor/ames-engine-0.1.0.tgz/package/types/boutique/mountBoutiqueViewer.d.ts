import { type MountViewerOptions } from '../viewer';
import { type BoutiqueModeOptions } from './createBoutiqueMode';
export interface BoutiqueViewerOptions extends BoutiqueModeOptions {
    viewer?: MountViewerOptions;
    initialAssetId?: string;
}
/** Optional DOM presentation. Rendering is delegated entirely to mountViewer. */
export declare function mountBoutiqueViewer(container: HTMLElement, options?: BoutiqueViewerOptions): Promise<Readonly<{
    viewer: Readonly<{
        engine: import("..").AmesEngine;
        materials: Readonly<{
            metals: readonly import("..").MetalMaterialProfile[];
            gems: readonly import("..").GemMaterialProfile[];
            metal: (id: string) => import("..").MetalMaterialProfile;
            gem: (id: string) => import("..").GemMaterialProfile;
        }>;
        readonly paused: boolean;
        setPaused: (value: boolean) => void;
        readonly state: import("..").ViewerState;
        readonly performance: import("..").ViewerPerformanceStats;
        subscribe: (listener: () => void) => () => void;
        subscribePerformance: (listener: () => void) => () => void;
        loadAsset: (assetId: string) => Promise<import("..").EngineCommandResult>;
        execute: (command: import("..").EngineCommand) => Promise<import("..").EngineCommandResult>;
        resetCamera: () => void;
        resize: (width: number, height: number) => void;
        tick: (now: number) => void;
        resetPerformance: () => void;
        dispose: () => void;
    }>;
    mode: Readonly<{
        viewer: Readonly<{
            engine: import("..").AmesEngine;
            materials: Readonly<{
                metals: readonly import("..").MetalMaterialProfile[];
                gems: readonly import("..").GemMaterialProfile[];
                metal: (id: string) => import("..").MetalMaterialProfile;
                gem: (id: string) => import("..").GemMaterialProfile;
            }>;
            readonly paused: boolean;
            setPaused: (value: boolean) => void;
            readonly state: import("..").ViewerState;
            readonly performance: import("..").ViewerPerformanceStats;
            subscribe: (listener: () => void) => () => void;
            subscribePerformance: (listener: () => void) => () => void;
            loadAsset: (assetId: string) => Promise<import("..").EngineCommandResult>;
            execute: (command: import("..").EngineCommand) => Promise<import("..").EngineCommandResult>;
            resetCamera: () => void;
            resize: (width: number, height: number) => void;
            tick: (now: number) => void;
            resetPerformance: () => void;
            dispose: () => void;
        }>;
        readonly state: import("./createBoutiqueMode").BoutiqueState;
        capabilities: Readonly<{
            favorite: boolean;
            compare: boolean;
            requestAccess: boolean;
        }>;
        listProducts: () => readonly import("./createBoutiqueMode").BoutiqueProduct[];
        subscribe: (fn: () => void) => () => void;
        show: (assetId: string) => Promise<import("./createBoutiqueMode").BoutiqueProduct>;
        selectMetal: (materialId: string, finish?: import("..").MetalFinish) => Promise<import("..").EngineCommandResult>;
        selectGem: (materialId: string) => Promise<import("..").EngineCommandResult>;
        refreshAccess: () => Promise<import("./createBoutiqueMode").BoutiqueProduct>;
        toggleTurntable: () => Promise<import("..").EngineCommandResult>;
        resetView: () => void;
        toggleFavorite: () => Promise<void>;
        compare: () => Promise<void>;
        requestAccess: () => Promise<void>;
        dispose: () => Promise<void>;
    }>;
    show: (assetId: string) => Promise<import("./createBoutiqueMode").BoutiqueProduct>;
    dispose: () => Promise<void>;
}>>;
