import type { JewelryPartClassification } from './classifyJewelryAsset';
/**
 * Benchmark 02's locked semantic metadata, not a generic object-name heuristic.
 * Its 51 Diamond_Round* and 100 Prong_On_Surface* meshes are named explicitly;
 * the remaining verified 20 structural metal meshes are named object_1..20.
 * Pass only for Benchmark 02. Counts are independently enforced by the guard.
 */
export declare const BENCHMARK_02_VERIFIED_ROLES: Readonly<Record<string, JewelryPartClassification>>;
