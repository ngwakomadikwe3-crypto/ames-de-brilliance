import type { JewelryAssetReadResult } from '../loaders';
export type JewelryPartClassification = 'CENTER_STONE' | 'ACCENT_STONE' | 'METAL' | 'SETTING' | 'UNKNOWN';
export interface JewelryMeshClassification {
    meshId: string;
    meshName: string;
    classification: JewelryPartClassification;
    confidence: number;
    reasons: string[];
}
export interface JewelryAssetClassificationResult {
    parts: JewelryMeshClassification[];
}
export declare function classifyJewelryAsset(asset: JewelryAssetReadResult, verifiedRoles?: Readonly<Record<string, JewelryPartClassification>>): JewelryAssetClassificationResult;
