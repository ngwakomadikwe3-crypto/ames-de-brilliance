import type { JewelryAssetReadResult } from '../loaders';
import type { JewelryAssetClassificationResult } from './classifyJewelryAsset';
export declare const BENCHMARK_02_COUNTS: Readonly<{
    diamonds: 51;
    prongs: 100;
    metal: 20;
    total: 171;
}>;
/** Checks classification output; never reclassifies or modifies source geometry. */
export declare function validateBenchmark02(asset: JewelryAssetReadResult, analysis: JewelryAssetClassificationResult): {
    passed: boolean;
    counts: {
        diamonds: number;
        prongs: number;
        metal: number;
        total: number;
    };
    errors: string[];
};
