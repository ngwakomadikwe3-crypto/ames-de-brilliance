import { type ReactNode } from 'react';
import type { AmesIntegration } from './api';
import type { BoutiqueViewerOptions } from '../boutique/mountBoutiqueViewer';
import type { StoneTrayOptions } from '../stone-tray/mountStoneTray';
export declare function useAmesIntegration(integration: AmesIntegration): {
    integration: AmesIntegration;
    mounted: "boutique" | "none" | "stone-tray";
    send: (command: import("..").EngineCommand) => Promise<import("..").EngineCommandResult>;
};
export declare function useAmesMount(integration: AmesIntegration, kind: 'boutique' | 'stone-tray', options?: BoutiqueViewerOptions | StoneTrayOptions): {
    ref: import("react").RefObject<HTMLDivElement | null>;
    error: Error | null;
};
export declare function AmesBoutique(props: {
    integration: AmesIntegration;
    options?: BoutiqueViewerOptions;
}): ReactNode;
export declare function AmesStoneTray(props: {
    integration: AmesIntegration;
    options?: StoneTrayOptions;
}): ReactNode;
