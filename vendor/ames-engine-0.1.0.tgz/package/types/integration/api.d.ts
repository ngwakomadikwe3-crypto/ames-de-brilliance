import type { EngineCommand, EngineCommandResult } from '../core/protocol';
import { type BoutiqueViewerOptions } from '../boutique/mountBoutiqueViewer';
import { type StoneTrayOptions } from '../stone-tray/mountStoneTray';
import type { ViewerScene } from '../viewer';
import type { AmesEngine } from '../core/protocol';
export type AmesIntegrationEvent = {
    readonly type: 'INITIALIZED';
} | {
    readonly type: 'COMMAND_APPLIED';
    readonly command: EngineCommand;
    readonly result: EngineCommandResult;
} | {
    readonly type: 'COMMAND_FAILED';
    readonly command: EngineCommand;
    readonly error: Error;
} | {
    readonly type: 'BOUTIQUE_MOUNTED' | 'STONE_TRAY_MOUNTED';
} | {
    readonly type: 'ASSET_CHANGED';
    readonly assetId: string | null;
} | {
    readonly type: 'DISPOSED';
};
export type AmesIntegrationEventType = AmesIntegrationEvent['type'];
export type AmesIntegrationListener = (event: AmesIntegrationEvent) => void;
export interface AmesIntegrationOptions {
    readonly engine: AmesEngine;
}
export interface AmesIntegration {
    readonly engine: AmesEngine;
    readonly mounted: 'none' | 'boutique' | 'stone-tray';
    init(): void;
    send(command: EngineCommand): Promise<EngineCommandResult>;
    on(type: AmesIntegrationEventType | '*', listener: AmesIntegrationListener): () => void;
    mountBoutique(container: HTMLElement, options?: BoutiqueViewerOptions): Promise<MountedIntegration>;
    mountStoneTray(container: HTMLElement, options?: StoneTrayOptions): Promise<MountedIntegration>;
    dispose(): Promise<void>;
}
export interface MountedIntegration {
    readonly viewer: ViewerScene;
    readonly mode: {
        readonly execute: (command: EngineCommand) => Promise<EngineCommandResult>;
    };
    readonly dispose: () => Promise<void>;
}
export declare function createAmesIntegration(options: AmesIntegrationOptions): AmesIntegration;
