import type { PerspectiveCamera, Vector3 } from 'three';
import type { AmesEngineOptions, AmesRenderBackend, EngineCommand, EngineCommandResult } from '../core/protocol';
import { type RenderQuality } from '../renderer/renderQuality';
import { type ViewerPerformanceStats } from './stats';
export interface ViewerControls {
    readonly target: Vector3;
    enabled: boolean;
    enablePan: boolean;
    minDistance: number;
    maxDistance: number;
    update(): unknown;
    dispose(): void;
}
export interface ViewerBackend extends AmesRenderBackend {
    setPixelRatio?(ratio: number): void;
    statistics?(): {
        calls: number;
        triangles: number;
    };
}
export interface ViewerState {
    readonly status: 'idle' | 'loading' | 'ready' | 'error' | 'disposed';
    readonly assetId: string | null;
    readonly requestedAssetId: string | null;
    readonly error: string | null;
    readonly quality: RenderQuality;
    readonly turntable: boolean;
}
export interface ViewerSceneOptions extends Omit<AmesEngineOptions, 'backend' | 'hooks'> {
    backend: ViewerBackend;
    controls: (camera: PerspectiveCamera) => ViewerControls;
    pan?: 'never' | 'jewelry';
    quality?: RenderQuality;
    applyDefaultMaterials?: boolean;
    /** Browser-owned environment/observer cleanup, before backend disposal. */
    beforeDispose?: () => void;
}
/** UI-independent viewer. A host supplies controls/backend and calls tick with RAF timestamps. */
export declare function createViewerScene(options: ViewerSceneOptions): Readonly<{
    engine: import("..").AmesEngine;
    materials: Readonly<{
        metals: readonly import("..").MetalMaterialProfile[];
        gems: readonly import("..").GemMaterialProfile[];
        metal: (id: string) => import("..").MetalMaterialProfile;
        gem: (id: string) => import("..").GemMaterialProfile;
    }>;
    readonly paused: boolean;
    setPaused: (value: boolean) => void;
    readonly state: ViewerState;
    readonly performance: ViewerPerformanceStats;
    subscribe: (listener: () => void) => () => void;
    subscribePerformance: (listener: () => void) => () => void;
    loadAsset: (assetId: string) => Promise<EngineCommandResult>;
    execute: (command: EngineCommand) => Promise<EngineCommandResult>;
    resetCamera: () => void;
    resize: (width: number, height: number) => void;
    tick: (now: number) => void;
    resetPerformance: () => void;
    dispose: () => void;
}>;
export type ViewerScene = ReturnType<typeof createViewerScene>;
