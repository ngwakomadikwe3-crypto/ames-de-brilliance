export interface ViewerPerformanceStats {
    readonly fps: number | null;
    readonly frameMs: number | null;
    readonly drawCalls: number | null;
    readonly triangles: number | null;
    readonly samples: number;
}
/** Bounded frame intervals. Draw counts come from the backend, never geometry estimates. */
export declare function createViewerStats(): {
    reset(): void;
    sample(deltaMs: number, counters?: {
        calls: number;
        triangles: number;
    }): ViewerPerformanceStats;
};
