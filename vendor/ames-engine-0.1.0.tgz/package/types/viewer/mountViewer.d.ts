import { type ViewerSceneOptions, type ViewerScene } from './createViewerScene';
export interface MountViewerOptions extends Omit<ViewerSceneOptions, 'backend' | 'controls' | 'beforeDispose'> {
    signal?: AbortSignal;
}
/** Owns only its canvas, frame loop, controls and existing studio environment. No presentation UI. */
export declare function mountViewer(container: HTMLElement, options?: MountViewerOptions): Promise<ViewerScene>;
