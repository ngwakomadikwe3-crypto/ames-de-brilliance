import { Vector3, type Object3D, type PerspectiveCamera } from 'three';
/** Same enclosing-sphere fit as the existing kernel, for component and reset views. */
export declare function fitViewerCamera(camera: PerspectiveCamera, target: Vector3, object: Object3D, resetDirection?: boolean): number;
