import type { AmesEngine, AmesEngineOptions } from './protocol';
/** Lifecycle/command composition only. Existing ingestion and rendering stay owned by the kernel. */
export declare function createAmesEngine(options: AmesEngineOptions): AmesEngine;
/** Browser allocation is deferred until init(). No DOM work occurs on import. */
export declare function createAmesEngineForCanvas(canvas: HTMLCanvasElement, hooks?: AmesEngineOptions['hooks']): AmesEngine;
/** App-facing factory: access configuration is mandatory; protected delivery fails closed. */
export declare function createAccessControlledEngine(options: AmesEngineOptions & {
    access: NonNullable<AmesEngineOptions['access']>;
}): AmesEngine;
