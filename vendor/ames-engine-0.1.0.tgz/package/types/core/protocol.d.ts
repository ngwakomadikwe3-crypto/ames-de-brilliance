import type { AccessOptions, AccessController, AccessState } from '../access';
import type { PerspectiveCamera, Scene, Vector3 } from 'three';
import type { JewelryLoadOptions, JewelryModel, JewelryRenderBackend } from '../renderer/JewelryRenderer';
import type { LoadedJewelryAsset } from '../loaders/loadJewelryAsset';
import type { RenderQuality } from '../renderer/renderQuality';
import type { GemTypeId, StoneId } from '../stones/schema';
import type { AssetCategory } from '../assets/schema';
import type { AssetRegistry } from '../assets/registry';
import type { AssetRecord } from '../assets/schema';
import type { MaterialRegistry, MetalFinish, SemanticMaterialSlot } from '../material-system';
export type AmesRenderBackend = JewelryRenderBackend;
export type EngineMode = 'none' | 'boutique' | 'stone-tray';
export type MetalSelection = 'gold' | 'silver' | 'platinum';
export type AssetTarget = {
    assetId: string;
    url?: never;
} | {
    url: string;
    assetId?: never;
};
export type MetalSelectionRequest = ({
    materialId: string;
    metal?: never;
} | {
    metal: MetalSelection;
    materialId?: never;
}) & {
    finish?: MetalFinish;
    slotId?: string;
};
export type GemSelectionRequest = ({
    materialId: string;
    gemTypeId?: never;
} | {
    gemTypeId: GemTypeId;
    materialId?: never;
}) & {
    slotId?: string;
};
export type EngineCommand = ({
    type: 'LOAD_ASSET';
    options?: JewelryLoadOptions;
} & AssetTarget) | ({
    type: 'SHOW_JEWELRY';
    options?: JewelryLoadOptions;
} & AssetTarget) | ({
    type: 'SHOW_STONE';
} & ({
    stoneId: StoneId;
    assetId?: never;
} | {
    assetId: string;
    stoneId?: never;
})) | ({
    type: 'SET_METAL';
} & MetalSelectionRequest) | ({
    type: 'SET_GEM';
} & GemSelectionRequest) | {
    type: 'FOCUS_COMPONENT';
    componentId: string;
} | {
    type: 'SET_QUALITY';
    quality: RenderQuality;
} | {
    type: 'START_TURNTABLE';
    radiansPerSecond?: number;
} | {
    type: 'STOP_TURNTABLE';
} | {
    type: 'CHECK_ACCESS' | 'PREVIEW_ASSET' | 'START_SUBSCRIPTION';
    assetId: string;
} | {
    type: 'DISPOSE';
};
export type EngineCommandResult = {
    status: 'applied';
    command: EngineCommand['type'];
    access?: AccessState;
} | {
    status: 'unsupported';
    command: EngineCommand['type'];
    reason: string;
};
export interface EngineHookContext {
    readonly scene: Scene;
    readonly camera: PerspectiveCamera;
    readonly target: Vector3;
    readonly model: JewelryModel | null;
    /** Aborted on replacement load or disposal; hooks must stop late work. */
    readonly signal: AbortSignal;
}
type Hook<T> = (payload: T, context: EngineHookContext) => void | Promise<void>;
/** Optional host adapters override default profile assignment; custom optical shaders stay protected. */
export interface EngineHooks {
    boutique?: Hook<{
        url: string;
    }>;
    stoneTray?: Hook<{
        stoneId: StoneId;
    }>;
    setMetal?: Hook<MetalSelectionRequest>;
    setGem?: Hook<GemSelectionRequest>;
    focusComponent?: Hook<{
        componentId: string;
    }>;
    setQuality?: Hook<{
        quality: RenderQuality;
    }>;
}
export interface AmesEngineOptions {
    /** Enable server-backed, fail-closed access and ID-only protected loading. Omit only for local development. */
    access?: AccessOptions;
    /** Exclusive ownership transfers at init. A factory defers browser allocation. */
    backend: AmesRenderBackend | (() => AmesRenderBackend);
    hooks?: EngineHooks;
    /** Optional ingestion adapter; every result must be independently owned. */
    loadAsset?: (url: string) => Promise<LoadedJewelryAsset>;
    /** Defaults to the five canonical stones. Both presentation consumers use this instance. */
    registry?: AssetRegistry;
    materials?: MaterialRegistry;
    /** Explicit per-instance selectors; never changes the source classifier output. */
    resolveMaterialSlots?: (model: JewelryModel, asset?: AssetRecord) => readonly SemanticMaterialSlot[];
}
export interface AmesEngine {
    readonly access: AccessController | undefined;
    readonly status: 'idle' | 'ready' | 'disposed';
    readonly mode: EngineMode;
    readonly registry: AssetRegistry;
    readonly model: JewelryModel | null;
    readonly scene: Scene;
    readonly camera: PerspectiveCamera;
    readonly target: Vector3;
    init(): void;
    load(url: string, options?: JewelryLoadOptions): Promise<JewelryModel>;
    loadById(assetId: string, category?: AssetCategory, options?: JewelryLoadOptions): Promise<JewelryModel>;
    /** Seconds since previous host frame; rotates object transform and renders once. */
    update(deltaSeconds: number): void;
    execute(command: EngineCommand): Promise<EngineCommandResult>;
    resize(width: number, height: number): void;
    render(): void;
    dispose(): void;
}
export {};
