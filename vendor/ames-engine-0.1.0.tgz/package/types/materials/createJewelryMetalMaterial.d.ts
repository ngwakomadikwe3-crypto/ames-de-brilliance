import { MeshStandardMaterial } from 'three';
export type JewelryMetalPreset = '18K_YELLOW_GOLD' | 'ROSE_GOLD' | 'WHITE_GOLD' | 'PLATINUM' | 'SILVER' | 'RHODIUM';
export interface JewelryMetalOptions {
    color?: string;
    roughness?: number;
    metalness?: number;
}
export declare const JEWELRY_METAL_PRESETS: Record<JewelryMetalPreset, Required<JewelryMetalOptions> & {
    label: string;
}>;
export declare function createJewelryMetalMaterial(preset?: JewelryMetalPreset, overrides?: JewelryMetalOptions): MeshStandardMaterial;
