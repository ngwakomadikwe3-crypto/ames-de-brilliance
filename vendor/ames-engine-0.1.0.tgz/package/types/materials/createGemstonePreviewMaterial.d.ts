import { MeshPhysicalMaterial } from 'three';
export type GemstonePreviewRole = 'DIAMOND_CENTER' | 'DIAMOND_ACCENT';
export declare function createGemstonePreviewMaterial(role: GemstonePreviewRole): MeshPhysicalMaterial;
