import type { AssetRecord, AssetRegistry } from '../assets';
export declare const ACCESS_TIERS: readonly ['PUBLIC', 'MEMBER', 'PREMIUM', 'COLLECTOR', 'PRIVATE'];
export type EntitlementTier = typeof ACCESS_TIERS[number];
export interface EntitlementAdapter {
    /** Trusted service decision; never an AI recommendation or client tier comparison. */
    canAccess(userId: string | null, assetId: string): Promise<boolean>;
}
export interface AssetDeliveryAdapter {
    /** Server must independently authorize identity + asset and issue a short-lived URL. */
    resolve(userId: string | null, assetId: string): Promise<{
        url: string;
        expiresAt: number;
    }>;
}
export interface AccessState {
    readonly assetId: string;
    readonly tier: EntitlementTier;
    readonly state: 'locked' | 'unlocked' | 'premium-preview';
    readonly reason: string | null;
    readonly previewPath: string | null;
}
export type AccessEvent = {
    readonly type: 'ACCESS_GRANTED' | 'ACCESS_DENIED' | 'PREMIUM_PREVIEWED';
    readonly access: AccessState;
} | {
    readonly type: 'SUBSCRIPTION_STARTED';
    readonly assetId: string;
    readonly userId: string | null;
};
export interface AccessOptions {
    userId: string | null;
    entitlements?: EntitlementAdapter;
    delivery?: AssetDeliveryAdapter;
    /** Host subscription-flow hook only; this never grants an entitlement. */
    onSubscriptionStarted?: (userId: string | null, assetId: string) => void | Promise<void>;
}
export declare function normalizeAccessTier(tier: AssetRecord['accessTier']): EntitlementTier;
export declare class AccessDeniedError extends Error {
    readonly access: AccessState;
    readonly code = "ACCESS_DENIED";
    constructor(access: AccessState);
}
export declare function createAccessController(registry: AssetRegistry, options: AccessOptions): Readonly<{
    check: (assetId: string) => Promise<AccessState>;
    authorize: (assetId: string) => Promise<string>;
    getState: (id: string) => AccessState;
    preview: (id: string) => AccessState;
    startSubscription: (id: string) => Promise<void>;
    subscribe: (listener: (event: AccessEvent) => void) => () => void;
    dispose: () => void;
}>;
export type AccessController = ReturnType<typeof createAccessController>;
