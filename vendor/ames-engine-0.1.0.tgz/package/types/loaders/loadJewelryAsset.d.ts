import type { JewelryAssetReadResult } from './types';
export interface LoadedJewelryAsset extends JewelryAssetReadResult {
    sourceUrl: string;
    animations: number;
}
export declare function loadJewelryAsset(sourceUrl: string): Promise<LoadedJewelryAsset>;
