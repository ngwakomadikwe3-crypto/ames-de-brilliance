import { type Object3D } from 'three';
import type { JewelryAssetReadResult } from './types';
export declare function readJewelryScene(scene: Object3D): JewelryAssetReadResult;
