import { type StoneCatalog, type StoneSelectionRequest, type StoneCut, type GemType, type OpticalProfile, type Stone, type StoneGeometryAsset } from '../stones';
import type { EngineCommand, EngineCommandResult } from '../core/protocol';
import type { ViewerScene } from '../viewer';
export interface ChatStoneMetadata {
    readonly assetId: string;
    readonly stoneId: Stone['id'];
    readonly name: string;
    readonly cut: StoneCut;
    readonly gemType: GemType;
    readonly identity: Stone['identity'];
    readonly opticalProfile: OpticalProfile;
    readonly geometry: StoneGeometryAsset;
    readonly metadata: Stone['metadata'];
    readonly acceptance: Stone['acceptance'];
    readonly experimental: boolean;
    /** Instance preview selection never changes registered gem/stone identity. */
    readonly previewGem: {
        readonly id: string;
        readonly name: string;
    } | null;
}
export interface StoneModeState {
    readonly status: 'idle' | 'loading' | 'ready' | 'error' | 'disposed';
    readonly selected: ChatStoneMetadata | null;
    readonly requested: ChatStoneMetadata | null;
    readonly error: string | null;
    readonly turntable: boolean;
    readonly selectingPrompt: boolean;
}
export type StoneModeCommand = Extract<EngineCommand, {
    type: 'SHOW_STONE' | 'SET_GEM' | 'START_TURNTABLE' | 'STOP_TURNTABLE' | 'DISPOSE';
}>;
export interface StoneModeOptions {
    catalog?: StoneCatalog;
    ownsViewer?: boolean;
    onMetadata?: (metadata: ChatStoneMetadata | null) => void;
    /** Future host AI/parser hook only. No model calls, generation or URL execution in the tray. */
    resolvePrompt?: (prompt: string, context: {
        readonly candidates: readonly ChatStoneMetadata[];
        readonly signal: AbortSignal;
    }) => StoneSelectionRequest | Promise<StoneSelectionRequest>;
}
export type StoneSelectionResult = {
    readonly status: 'selected';
    readonly metadata: ChatStoneMetadata;
} | {
    readonly status: 'unmatched' | 'ambiguous';
    readonly candidates: readonly ChatStoneMetadata[];
};
export declare function createStoneMode(viewer: ViewerScene, options?: StoneModeOptions): Readonly<{
    viewer: Readonly<{
        engine: import("..").AmesEngine;
        materials: Readonly<{
            metals: readonly import("..").MetalMaterialProfile[];
            gems: readonly import("..").GemMaterialProfile[];
            metal: (id: string) => import("..").MetalMaterialProfile;
            gem: (id: string) => import("..").GemMaterialProfile;
        }>;
        readonly paused: boolean;
        setPaused: (value: boolean) => void;
        readonly state: import("..").ViewerState;
        readonly performance: import("..").ViewerPerformanceStats;
        subscribe: (listener: () => void) => () => void;
        subscribePerformance: (listener: () => void) => () => void;
        loadAsset: (assetId: string) => Promise<EngineCommandResult>;
        execute: (command: EngineCommand) => Promise<EngineCommandResult>;
        resetCamera: () => void;
        resize: (width: number, height: number) => void;
        tick: (now: number) => void;
        resetPerformance: () => void;
        dispose: () => void;
    }>;
    readonly state: StoneModeState;
    subscribe: (fn: () => void) => () => void;
    getChatMetadata: () => ChatStoneMetadata | null;
    listStones: () => readonly ChatStoneMetadata[];
    getStoneMetadata: (assetId: string) => ChatStoneMetadata;
    show: (assetId: string) => Promise<ChatStoneMetadata>;
    execute: (command: StoneModeCommand) => Promise<EngineCommandResult>;
    applySelection: (request: StoneSelectionRequest) => Promise<StoneSelectionResult>;
    selectFromPrompt: (prompt: string) => Promise<StoneSelectionResult>;
    setGem: (materialId: string) => Promise<EngineCommandResult>;
    toggleTurntable: () => Promise<EngineCommandResult>;
    resetView: () => void;
    dispose: () => Promise<void>;
}>;
export type StoneMode = ReturnType<typeof createStoneMode>;
