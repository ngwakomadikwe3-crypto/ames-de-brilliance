import { type MountViewerOptions } from '../viewer';
import { type StoneModeOptions } from './createStoneMode';
export interface StoneTrayOptions extends StoneModeOptions {
    viewer?: Omit<MountViewerOptions, 'pan'>;
    /** Defaults to the first registered stone; null leaves an empty tray. */
    initialAssetId?: string | null;
}
/** Chat-top presentation only; all rendering and pointer interaction belong to the shared viewer. */
export declare function mountStoneTray(container: HTMLElement, options?: StoneTrayOptions): Promise<Readonly<{
    mode: Readonly<{
        viewer: Readonly<{
            engine: import("..").AmesEngine;
            materials: Readonly<{
                metals: readonly import("..").MetalMaterialProfile[];
                gems: readonly import("..").GemMaterialProfile[];
                metal: (id: string) => import("..").MetalMaterialProfile;
                gem: (id: string) => import("..").GemMaterialProfile;
            }>;
            readonly paused: boolean;
            setPaused: (value: boolean) => void;
            readonly state: import("..").ViewerState;
            readonly performance: import("..").ViewerPerformanceStats;
            subscribe: (listener: () => void) => () => void;
            subscribePerformance: (listener: () => void) => () => void;
            loadAsset: (assetId: string) => Promise<import("..").EngineCommandResult>;
            execute: (command: import("..").EngineCommand) => Promise<import("..").EngineCommandResult>;
            resetCamera: () => void;
            resize: (width: number, height: number) => void;
            tick: (now: number) => void;
            resetPerformance: () => void;
            dispose: () => void;
        }>;
        readonly state: import("./createStoneMode").StoneModeState;
        subscribe: (fn: () => void) => () => void;
        getChatMetadata: () => import("./createStoneMode").ChatStoneMetadata | null;
        listStones: () => readonly import("./createStoneMode").ChatStoneMetadata[];
        getStoneMetadata: (assetId: string) => import("./createStoneMode").ChatStoneMetadata;
        show: (assetId: string) => Promise<import("./createStoneMode").ChatStoneMetadata>;
        execute: (command: import("./createStoneMode").StoneModeCommand) => Promise<import("..").EngineCommandResult>;
        applySelection: (request: import("../stones").StoneSelectionRequest) => Promise<import("./createStoneMode").StoneSelectionResult>;
        selectFromPrompt: (prompt: string) => Promise<import("./createStoneMode").StoneSelectionResult>;
        setGem: (materialId: string) => Promise<import("..").EngineCommandResult>;
        toggleTurntable: () => Promise<import("..").EngineCommandResult>;
        resetView: () => void;
        dispose: () => Promise<void>;
    }>;
    viewer: Readonly<{
        engine: import("..").AmesEngine;
        materials: Readonly<{
            metals: readonly import("..").MetalMaterialProfile[];
            gems: readonly import("..").GemMaterialProfile[];
            metal: (id: string) => import("..").MetalMaterialProfile;
            gem: (id: string) => import("..").GemMaterialProfile;
        }>;
        readonly paused: boolean;
        setPaused: (value: boolean) => void;
        readonly state: import("..").ViewerState;
        readonly performance: import("..").ViewerPerformanceStats;
        subscribe: (listener: () => void) => () => void;
        subscribePerformance: (listener: () => void) => () => void;
        loadAsset: (assetId: string) => Promise<import("..").EngineCommandResult>;
        execute: (command: import("..").EngineCommand) => Promise<import("..").EngineCommandResult>;
        resetCamera: () => void;
        resize: (width: number, height: number) => void;
        tick: (now: number) => void;
        resetPerformance: () => void;
        dispose: () => void;
    }>;
    show: (assetId: string) => Promise<import("./createStoneMode").ChatStoneMetadata>;
    execute: (command: import("./createStoneMode").StoneModeCommand) => Promise<import("..").EngineCommandResult>;
    getChatMetadata: () => import("./createStoneMode").ChatStoneMetadata | null;
    dispose: () => Promise<void>;
}>>;
