import { type AssetRegistry } from '../assets';
import type { GeneratedJewelryAsset, JewelryGenerationPlan } from './spec';
import { type CatalogSnapshot, type CatalogIngestionOptions, type AssetRevision } from '../assets/batch';
/** Validate exported generated jewelry through the same batch pipeline before publishing. */
export declare function ingestGeneratedJewelry(snapshot: CatalogSnapshot, plans: readonly {
    plan: JewelryGenerationPlan;
    version: AssetRevision;
}[], options: CatalogIngestionOptions): Promise<CatalogSnapshot>;
export declare function generatedAssetRecord(plan: JewelryGenerationPlan, status?: GeneratedJewelryAsset['generation']['status']): GeneratedJewelryAsset;
/** Registration returns a new immutable snapshot; the canonical registry is never mutated. */
export declare function registerGeneratedAsset(registry: AssetRegistry, plan: JewelryGenerationPlan, status?: GeneratedJewelryAsset['generation']['status']): AssetRegistry;
