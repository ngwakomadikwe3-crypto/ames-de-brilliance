import type { JewelryGenerationPlan } from './spec';
/** Produces a deterministic Blender Python program; Blender MCP is the execution boundary. */
export declare function createBlenderGenerationScript(plan: JewelryGenerationPlan, projectRoot: string): string;
