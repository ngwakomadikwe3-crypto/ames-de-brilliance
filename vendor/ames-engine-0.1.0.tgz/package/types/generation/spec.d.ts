import type { AccessTier, AssetRecord } from '../assets';
import type { GemTypeId } from '../stones/schema';
export declare const JEWELRY_GENERATION_CATEGORIES: readonly ['ring', 'watch', 'bracelet', 'necklace', 'earring'];
export type JewelryGenerationCategory = typeof JEWELRY_GENERATION_CATEGORIES[number];
export type GenerationStatus = 'draft' | 'validated' | 'exported' | 'registered' | 'failed';
export interface JewelryDesignSpec {
    readonly category: JewelryGenerationCategory;
    readonly collection: string;
    readonly name: string;
    readonly metal: '18k-yellow-gold' | '18k-white-gold' | 'rose-gold' | 'platinum' | 'silver' | 'rhodium';
    readonly finish: 'polished' | 'brushed' | 'satin';
    readonly primaryGemstone: GemTypeId;
    readonly cut: 'round' | 'oval' | 'emerald' | 'pear' | 'asscher';
    readonly carat: number;
    readonly setting: 'solitaire' | 'halo' | 'hidden-halo' | 'three-stone' | 'bezel';
    readonly band: {
        readonly profile: 'round' | 'comfort' | 'knife-edge' | 'flat';
        readonly widthMm: number;
        readonly thicknessMm: number;
    };
    readonly halo: {
        readonly enabled: boolean;
        readonly count: number;
        readonly diameterMm: number;
    };
    readonly prongs: {
        readonly count: number;
        readonly style: 'round' | 'claw' | 'shared';
        readonly diameterMm: number;
    };
    readonly dimensions: {
        readonly ringSize: number;
        readonly centerHeightMm: number;
    };
    readonly semanticComponents: readonly string[];
    readonly accessTier: AccessTier;
    readonly generationStatus: GenerationStatus;
}
export interface JewelryGenerationPlan {
    readonly spec: JewelryDesignSpec;
    readonly assetId: string;
    readonly outputPath: string;
    readonly canonicalStonePath: string;
    readonly components: readonly string[];
}
export type GeneratedJewelryAsset = AssetRecord & {
    readonly generation: {
        readonly spec: JewelryDesignSpec;
        readonly status: GenerationStatus;
        readonly source: 'blender-mcp';
    };
};
export declare function validateJewelryDesignSpec(input: JewelryDesignSpec): JewelryDesignSpec;
export declare function createJewelryGenerationPlan(spec: JewelryDesignSpec, root?: string): JewelryGenerationPlan;
