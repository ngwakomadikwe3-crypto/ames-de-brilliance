/** Standalone public boundary. React hosts and research renderers are not exported. */
export { createAmesEngine, createAmesEngineForCanvas, createAccessControlledEngine } from './core/createAmesEngine';
export type { AmesEngine, AmesRenderBackend, AmesEngineOptions, EngineCommand, EngineCommandResult, EngineMode, EngineHooks, EngineHookContext, MetalSelection } from './core/protocol';
export type { AssetTarget, MetalSelectionRequest, GemSelectionRequest } from './core/protocol';
export type { JewelryLoadOptions, JewelryModel } from './renderer/JewelryRenderer';
export * from './assets';
export * from './material-system';
export * from './viewer';
export { createBoutiquePresenter, createStoneTrayPresenter } from './presentations/assetPresenters';
export { createBoutiqueMode, type BoutiqueMode, type BoutiqueModeOptions, type BoutiqueState, type BoutiqueProduct } from './boutique/createBoutiqueMode';
export { mountBoutiqueViewer, type BoutiqueViewerOptions } from './boutique/mountBoutiqueViewer';
export { createStoneMode, type StoneMode, type StoneModeOptions, type StoneModeState, type StoneModeCommand, type StoneSelectionResult, type ChatStoneMetadata } from './stone-tray/createStoneMode';
export { mountStoneTray, type StoneTrayOptions } from './stone-tray/mountStoneTray';
/** V1 is the product roadmap; this foundation is a pre-production 0.1 API. */
export declare const AMES_ENGINE_VERSION: '0.1.0';
export * from './access';
export * from './integration/api';
export * from './generation';
export { useAmesIntegration, useAmesMount, AmesBoutique, AmesStoneTray } from './integration/react';
