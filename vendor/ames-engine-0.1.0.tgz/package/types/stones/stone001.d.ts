import type { StoneLibraryDocument } from './schema';
/** Only existing assets and existing AMES optical data are registered. No renderer imports. */
export declare const stoneLibrarySeed: StoneLibraryDocument;
