export * from './schema';
export { createStoneCatalog, type StoneCatalog } from './catalog';
/** Immutable catalog; importing it performs no asset fetches, rendering or scene mutations. */
export declare const stoneCatalog: Readonly<{
    document: import("./schema").StoneLibraryDocument;
    getStone: (id: import("./schema").StoneId) => import("./schema").Stone | undefined;
    resolve: (id: import("./schema").StoneId) => import("./schema").ResolvedStone;
    search: (query?: import("./schema").StoneQuery) => readonly import("./schema").Stone[];
    select: (request: import("./schema").StoneSelectionRequest) => readonly import("./schema").Stone[];
}>;
export declare const STONE_001_ID: 'stone-001';
