/** Serializable domain contracts. No renderer, UI, Three.js or AI-service dependencies. */
export type GemTypeId = `gem:${string}`;
export type CutId = `cut:${string}`;
export type OpticalProfileId = `optics:${string}`;
export type GeometryAssetId = `geometry:${string}`;
export type StoneId = `stone-${string}`;
export type JsonValue = string | number | boolean | null | readonly JsonValue[] | {
    readonly [key: string]: JsonValue;
};
export type Vector3Tuple = readonly [number, number, number];
export type QuaternionTuple = readonly [number, number, number, number];
export interface CatalogEntity<Id extends string> {
    readonly id: Id;
    readonly name: string;
    readonly description: string;
    readonly aliases: readonly string[];
    readonly tags: readonly string[];
    readonly metadata: Readonly<Record<string, JsonValue>>;
}
/** Commercial grouping, not a scientific taxonomy or valuation. */
export type GemCategory = 'precious' | 'semi-precious' | 'other' | 'unclassified';
export interface GemType extends CatalogEntity<GemTypeId> {
    readonly category: GemCategory;
    readonly species?: string;
    readonly variety?: string;
    readonly defaultOpticalProfileId: OpticalProfileId;
}
export type RefractiveIndex = {
    readonly kind: 'unknown';
} | {
    readonly kind: 'isotropic';
    readonly wavelengthNm: number;
    readonly n: number;
} | {
    readonly kind: 'uniaxial';
    readonly wavelengthNm: number;
    readonly ordinary: number;
    readonly extraordinary: number;
} | {
    readonly kind: 'biaxial';
    readonly wavelengthNm: number;
    readonly alpha: number;
    readonly beta: number;
    readonly gamma: number;
};
export interface OpticalProfile extends CatalogEntity<OpticalProfileId> {
    readonly gemTypeId: GemTypeId;
    readonly refractiveIndex: RefractiveIndex;
    readonly abbeNumber?: number;
    readonly spectralIndices?: readonly {
        readonly wavelengthNm: number;
        readonly n: number;
        readonly axis: 'isotropic' | 'ordinary' | 'extraordinary' | 'alpha' | 'beta' | 'gamma';
    }[];
    readonly absorption?: readonly {
        readonly wavelengthNm: number;
        readonly coefficientPerMillimeter: number;
    }[];
    /** Descriptive capability requirements; not promises that a renderer implements them. */
    readonly phenomena: readonly string[];
    readonly evidence: {
        readonly kind: 'measured' | 'published' | 'existing-engine-approximation' | 'unknown';
        readonly sources: readonly string[];
        readonly notes: string;
    };
}
/** Cuts are extensible records, never a closed enum of familiar diamond cuts. */
export interface StoneCut extends CatalogEntity<CutId> {
    readonly outline: string;
    readonly family: string;
    readonly frequency: 'common' | 'rare' | 'obscure' | 'unknown';
    readonly finish: 'faceted' | 'cabochon' | 'carved' | 'rough' | 'other';
}
export interface AcceptanceEvidence {
    readonly status: 'unreviewed' | 'passed' | 'failed';
    readonly sources: readonly string[];
    readonly notes: string;
}
export interface StoneGeometryAsset extends CatalogEntity<GeometryAssetId> {
    readonly revision: number;
    readonly cutId: CutId;
    readonly format: 'glb';
    readonly url: string;
    readonly sha256: string;
    readonly byteLength: number;
    readonly dimensions: Vector3Tuple;
    readonly coordinates: {
        readonly units: 'normalized' | 'meters';
        readonly upAxis: '+Y' | '+Z';
        readonly origin: string;
        readonly referenceAxis: 'x' | 'y' | 'z';
        readonly referenceSize: number;
    };
    readonly meshCount: number;
    readonly triangleCount: number;
    readonly preserveFacetNormals: boolean;
    readonly geometryAcceptance: AcceptanceEvidence;
}
export interface StonePresentation {
    readonly rotation: {
        readonly enabled: boolean;
        readonly initialQuaternion: QuaternionTuple;
    };
    /** Camera distance expressed in multiples of the asset's reference size. */
    readonly zoom: {
        readonly enabled: boolean;
        readonly min: number;
        readonly initial: number;
        readonly max: number;
    };
}
export interface Stone extends CatalogEntity<StoneId> {
    readonly number: number;
    readonly gemTypeId: GemTypeId;
    readonly cutId: CutId;
    readonly opticalProfileId?: OpticalProfileId;
    readonly identity: {
        readonly kind: 'canonical-test' | 'generic' | 'identified-specimen';
        readonly origin: 'virtual' | 'natural' | 'lab-grown' | 'unknown';
        readonly identifiers: readonly {
            readonly scheme: string;
            readonly value: string;
            readonly issuer?: string;
            readonly verified: boolean;
        }[];
    };
    /** Absent when a stone is catalogued without geometry. No asset fabrication implied. */
    readonly geometry?: {
        readonly assetId: GeometryAssetId;
        readonly representation: 'canonical-test' | 'representative-cut' | 'specimen-scan';
    };
    readonly caratWeight?: number;
    readonly presentation: StonePresentation;
    readonly acceptance: {
        readonly visual: AcceptanceEvidence;
        readonly performance: AcceptanceEvidence;
    };
}
export interface StoneLibraryDocument {
    readonly schemaVersion: 1;
    readonly revision: number;
    readonly gemTypes: readonly GemType[];
    readonly opticalProfiles: readonly OpticalProfile[];
    readonly cuts: readonly StoneCut[];
    readonly assets: readonly StoneGeometryAsset[];
    readonly stones: readonly Stone[];
}
export interface StoneQuery {
    readonly text?: string;
    readonly gemTypeIds?: readonly GemTypeId[];
    readonly cutIds?: readonly CutId[];
    readonly categories?: readonly GemCategory[];
    readonly cutFrequencies?: readonly StoneCut['frequency'][];
    readonly tags?: readonly string[];
    readonly geometryAvailable?: boolean;
}
/** Future prompt interpretation produces this data; it never executes code or loads URLs. */
export type StoneSelectionRequest = {
    readonly kind: 'by-id';
    readonly stoneId: StoneId;
} | {
    readonly kind: 'query';
    readonly query: StoneQuery;
};
export interface StoneRecommendation {
    readonly stoneId: StoneId;
    readonly reason: string;
    readonly score?: number;
    readonly evidenceFields: readonly string[];
}
/** Independent placement for chat presentation or future Boutique composition. */
export interface StoneInstance {
    readonly instanceId: string;
    readonly stoneId: StoneId;
    readonly size: {
        readonly referenceAxis: 'x' | 'y' | 'z';
        readonly millimeters: number;
    };
    readonly transform: {
        readonly positionMillimeters: Vector3Tuple;
        readonly rotation: QuaternionTuple;
    };
}
export interface ResolvedStone {
    readonly stone: Stone;
    readonly gemType: GemType;
    readonly cut: StoneCut;
    readonly opticalProfile: OpticalProfile;
    readonly asset?: StoneGeometryAsset;
}
