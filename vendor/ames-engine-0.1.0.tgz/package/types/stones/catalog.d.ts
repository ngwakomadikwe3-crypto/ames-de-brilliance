import type { ResolvedStone, StoneId, StoneLibraryDocument, StoneQuery, StoneSelectionRequest } from './schema';
/** Validates trusted typed catalog documents, then snapshots them. Not an untrusted JSON parser. */
export declare function createStoneCatalog(input: StoneLibraryDocument): Readonly<{
    document: StoneLibraryDocument;
    getStone: (id: StoneId) => import("./schema").Stone | undefined;
    resolve: (id: StoneId) => ResolvedStone;
    search: (query?: StoneQuery) => readonly import("./schema").Stone[];
    select: (request: StoneSelectionRequest) => readonly import("./schema").Stone[];
}>;
export type StoneCatalog = ReturnType<typeof createStoneCatalog>;
