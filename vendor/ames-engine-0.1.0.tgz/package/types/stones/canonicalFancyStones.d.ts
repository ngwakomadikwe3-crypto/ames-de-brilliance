import type { Stone, StoneCut, StoneGeometryAsset } from './schema';
export declare const canonicalFancyCuts: readonly StoneCut[];
export declare const canonicalFancyAssets: readonly StoneGeometryAsset[];
export declare const canonicalFancyStones: readonly Stone[];
