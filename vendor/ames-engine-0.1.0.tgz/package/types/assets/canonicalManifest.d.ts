import type { AssetManifest } from './schema';
/** Asset metadata is derived from the existing Stone Library; geometry/optics are not duplicated. */
export declare const canonicalAssetManifest: AssetManifest;
export declare const assetRegistry: import("./registry").AssetRegistry;
