import { loadJewelryAsset } from '../loaders/loadJewelryAsset';
/** The existing GLTFLoader fetches/parses once; no speculative HEAD requests or shared mutable GLBs. */
export declare function loadGlbAsset(path: string, loader?: typeof loadJewelryAsset): Promise<import("../loaders/loadJewelryAsset").LoadedJewelryAsset>;
