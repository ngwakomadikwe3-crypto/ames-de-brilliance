import { type AssetCategory, type AssetManifest, type AssetRecord } from './schema';
export type AssetErrorCode = 'INVALID_MANIFEST' | 'INVALID_ASSET_PATH' | 'ASSET_NOT_FOUND' | 'WRONG_CATEGORY' | 'MANIFEST_LOAD_FAILED' | 'GLB_LOAD_FAILED';
export declare class AssetError extends Error {
    readonly code: AssetErrorCode;
    readonly assetId?: string | undefined;
    readonly path?: string | undefined;
    constructor(code: AssetErrorCode, message: string, assetId?: string | undefined, path?: string | undefined, options?: ErrorOptions);
}
/** Root-relative or HTTP(S) URLs; GLB paths must identify a .glb resource. No network preflight. */
export declare function validateAssetPath(value: unknown, glb?: boolean): string;
export declare function parseAssetManifest(input: unknown): AssetManifest;
export interface AssetRegistry {
    readonly manifest: AssetManifest;
    get(id: string): AssetRecord | undefined;
    require(id: string, category?: AssetCategory): AssetRecord;
    list(category?: AssetCategory): readonly AssetRecord[];
}
/** Owns an immutable validated snapshot; never freezes or shares caller-owned records. */
export declare function createAssetRegistry(input: unknown): AssetRegistry;
/** Optional remote JSON catalog ingestion; malformed data never becomes a partial registry. */
export declare function loadAssetManifest(url: string, fetcher?: typeof fetch): Promise<AssetRegistry>;
