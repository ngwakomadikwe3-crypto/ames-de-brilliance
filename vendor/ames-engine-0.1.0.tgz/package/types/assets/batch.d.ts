import { type AssetRegistry } from './registry';
import type { AssetRecord } from './schema';
export interface AssetRevision {
    readonly revision: number;
    readonly sha256: string;
    readonly byteLength: number;
}
export interface CatalogBatchEntry {
    readonly asset: AssetRecord;
    readonly version: AssetRevision;
}
export interface CatalogSnapshot {
    readonly registry: AssetRegistry;
    readonly versions: Readonly<Record<string, AssetRevision>>;
}
export interface CatalogIngestionOptions {
    /** Trusted ingestion adapter; may access private storage. Never run protected probes in a public client. */
    probe: (asset: AssetRecord, signal: AbortSignal) => Promise<{
        sha256: string;
        byteLength: number;
    }>;
    preview?: (asset: AssetRecord, signal: AbortSignal) => Promise<string | null>;
    signal?: AbortSignal;
    concurrency?: number;
    timeoutMs?: number;
}
export declare function catalogSnapshot(registry: AssetRegistry): CatalogSnapshot;
/** Atomic immutable publication. Failed batches leave the previous snapshot available for rollback. */
export declare function registerAssetBatch(previous: CatalogSnapshot, batch: readonly CatalogBatchEntry[], options: CatalogIngestionOptions): Promise<CatalogSnapshot>;
/** Bounded GET, not HEAD: confirms a self-contained GLB container and its content digest. */
export declare function createGlbProbe(fetcher?: typeof fetch, maximumBytes?: number): (asset: AssetRecord, signal: AbortSignal) => Promise<{
    sha256: string;
    byteLength: number;
}>;
export declare function validateGlbContainer(data: Uint8Array): void;
