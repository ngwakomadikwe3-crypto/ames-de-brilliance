import { type AssetRegistry } from './registry';
/** Boutique and Stone Tray share data, never a scene or mutable loader cache. */
export declare function createBoutiqueAssets(registry: AssetRegistry): Readonly<{
    list: () => readonly import("./schema").AssetRecord[];
    resolve: (id: string) => import("./schema").AssetRecord;
}>;
export declare function createStoneTrayAssets(registry: AssetRegistry): Readonly<{
    list: () => readonly import("./schema").AssetRecord[];
    resolve: (id: string) => import("./schema").AssetRecord;
}>;
