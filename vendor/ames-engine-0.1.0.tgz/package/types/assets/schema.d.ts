import type { StoneId } from '../stones/schema';
export declare const ASSET_CATEGORIES: readonly ['ring', 'watch', 'bracelet', 'necklace', 'earring', 'stone'];
export type AssetCategory = typeof ASSET_CATEGORIES[number];
export type JewelryCategory = Exclude<AssetCategory, 'stone'>;
export type AccessTier = 'public' | 'premium' | 'exclusive' | 'PUBLIC' | 'MEMBER' | 'PREMIUM' | 'COLLECTOR' | 'PRIVATE';
export type AssetMetal = 'gold' | 'silver' | 'platinum';
export interface AssetRecord {
    readonly id: string;
    readonly name: string;
    readonly category: AssetCategory;
    readonly assetPath: string;
    /** Null means no preview exists; consumers must not invent a URL. */
    readonly previewPath: string | null;
    /** Declarative assignment targets, not a claim that a shader is embedded. */
    readonly materialSlots: readonly {
        readonly id: string;
        readonly kind: 'metal' | 'gem';
        readonly materialName?: string;
    }[];
    readonly stoneReferences: readonly StoneId[];
    readonly metalCompatibility: readonly AssetMetal[];
    readonly accessTier: AccessTier;
    readonly tags: readonly string[];
    /** Validated describes asset ingestion/geometry, not photorealism acceptance. */
    readonly status: 'draft' | 'validated' | 'published' | 'archived';
}
export interface AssetManifest {
    readonly schemaVersion: 1;
    readonly assets: readonly AssetRecord[];
}
