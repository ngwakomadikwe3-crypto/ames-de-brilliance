export * from './schema';
export { createMaterialRegistry, materialRegistry, MaterialSystemError, type MaterialRegistry } from './registry';
export { RuntimeMaterialAssignment, semanticMaterialSlots } from './assignment';
export { createProfileMetalMaterial } from './metals';
export { createProfileGemMaterial } from './gems';
