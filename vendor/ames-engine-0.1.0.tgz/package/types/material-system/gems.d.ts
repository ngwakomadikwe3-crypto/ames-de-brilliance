import type { GemMaterialProfile } from './schema';
export declare const gemProfiles: readonly GemMaterialProfile[];
/** Reuses the existing PBR preview path; no changes to BVH, spectral or diamond shaders. */
export declare function createProfileGemMaterial(profile: GemMaterialProfile): import("three").MeshPhysicalMaterial;
