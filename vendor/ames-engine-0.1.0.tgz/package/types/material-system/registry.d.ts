import type { GemMaterialProfile, MetalMaterialProfile } from './schema';
export declare class MaterialSystemError extends Error {
    readonly code: 'INVALID_MATERIAL' | 'INVALID_SLOT' | 'NO_TARGETS' | 'OPTICS_ADAPTER_REQUIRED';
    constructor(code: 'INVALID_MATERIAL' | 'INVALID_SLOT' | 'NO_TARGETS' | 'OPTICS_ADAPTER_REQUIRED', message: string);
}
export declare function createMaterialRegistry(metals: readonly MetalMaterialProfile[], gems: readonly GemMaterialProfile[]): Readonly<{
    metals: readonly MetalMaterialProfile[];
    gems: readonly GemMaterialProfile[];
    metal: (id: string) => MetalMaterialProfile;
    gem: (id: string) => GemMaterialProfile;
}>;
export type MaterialRegistry = ReturnType<typeof createMaterialRegistry>;
export declare const materialRegistry: Readonly<{
    metals: readonly MetalMaterialProfile[];
    gems: readonly GemMaterialProfile[];
    metal: (id: string) => MetalMaterialProfile;
    gem: (id: string) => GemMaterialProfile;
}>;
