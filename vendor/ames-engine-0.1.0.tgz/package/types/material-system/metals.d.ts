import { MeshPhysicalMaterial } from 'three';
import type { MetalMaterialProfile, MetalFinish } from './schema';
export declare const metalProfiles: readonly MetalMaterialProfile[];
export declare function createProfileMetalMaterial(profile: MetalMaterialProfile, finish?: MetalFinish): MeshPhysicalMaterial;
