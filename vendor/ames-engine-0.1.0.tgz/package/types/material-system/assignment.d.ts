import type { JewelryModel } from '../renderer/JewelryRenderer';
import type { MetalFinish, SemanticMaterialSlot } from './schema';
import { type MaterialRegistry } from './registry';
/** Derives assignment targets without writing classification, names, IDs or geometry. */
export declare function semanticMaterialSlots(model: JewelryModel): readonly SemanticMaterialSlot[];
/** Reversible model-owned binding. Restore originals before the kernel releases source resources. */
export declare class RuntimeMaterialAssignment {
    private readonly registry;
    private readonly meshes;
    private readonly originals;
    private readonly owned;
    private readonly suspended;
    private disposed;
    private paused;
    private readonly slots;
    constructor(model: JewelryModel, slots?: readonly SemanticMaterialSlot[], registry?: MaterialRegistry);
    setMetal(id: string, finish?: MetalFinish, slotId?: string): number;
    setGem(id: string, slotId?: string): number;
    private assign;
    suspend(): void;
    resume(): void;
    dispose(): void;
}
