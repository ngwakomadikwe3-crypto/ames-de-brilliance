export type MetalMaterialId = `metal:${string}`;
export type GemMaterialId = `gem:${string}`;
export type MetalFinish = 'polished' | 'brushed' | 'satin';
export interface MetalMaterialProfile {
    readonly id: MetalMaterialId;
    readonly name: string;
    readonly color: string;
    readonly finishes: Readonly<Record<MetalFinish, {
        readonly roughness: number;
        readonly anisotropy: number;
    }>>;
}
export interface GemMaterialProfile {
    readonly id: GemMaterialId;
    readonly name: string;
    readonly color: string;
    readonly refractiveIndexRange: readonly [number, number];
    /** Scalar preview approximation, not a wavelength/crystal-axis transport model. */
    readonly previewIor: number;
    readonly source: string;
    readonly rendering: 'existing-diamond-preview' | 'colored-gem-preview';
}
export interface SemanticMaterialSlot {
    readonly id: string;
    readonly kind: 'metal' | 'gem';
    readonly meshIds: readonly string[];
    /** Required when a mesh has multiple source materials. */
    readonly materialIndex?: number;
}
