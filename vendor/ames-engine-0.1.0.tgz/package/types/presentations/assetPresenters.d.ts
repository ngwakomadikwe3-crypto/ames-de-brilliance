import type { ViewerScene } from '../viewer/createViewerScene';
/** Presentation consumers are separate adapters; neither creates a second registry or renderer. */
export declare function createBoutiquePresenter(viewer: ViewerScene): Readonly<{
    show: (assetId: string) => Promise<import("..").EngineCommandResult>;
}>;
export declare function createStoneTrayPresenter(viewer: ViewerScene): Readonly<{
    show: (assetId: string) => Promise<import("..").EngineCommandResult>;
}>;
