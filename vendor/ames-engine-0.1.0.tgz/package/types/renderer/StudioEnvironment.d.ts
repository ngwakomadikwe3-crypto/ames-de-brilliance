import { Scene, type WebGLRenderer } from 'three';
/** Linear HDR softboxes; black spaces between cards supply contrast on polished metal. */
export declare function createStudioRig(): Scene;
/** Owns PMREM output. Reflection lighting never controls the visible background. */
export declare class StudioEnvironment {
    private readonly target;
    private disposed;
    private constructor();
    get texture(): import("three").Texture<unknown, import("three").TextureEventMap>;
    static create(renderer: WebGLRenderer, size?: number, hdrUrl?: string): Promise<StudioEnvironment>;
    attach(scene: Scene, background?: string): void;
    dispose(): void;
}
