export declare const RENDER_QUALITY: Readonly<{
    readonly FAST: {
        readonly pixelRatio: 0.75;
        readonly environmentSize: 128;
    };
    readonly INTERACTIVE: {
        readonly pixelRatio: 1;
        readonly environmentSize: 256;
    };
    readonly HIGH: {
        readonly pixelRatio: 1.5;
        readonly environmentSize: 512;
    };
    readonly BEAUTY: {
        readonly pixelRatio: 2;
        readonly environmentSize: 1024;
    };
}>;
export type RenderQuality = keyof typeof RENDER_QUALITY;
export interface DeviceHints {
    cores?: number;
    memoryGB?: number;
    coarsePointer?: boolean;
}
/** Conservative initial choice; users can explicitly select higher resolution. */
export declare function selectRenderQuality(device: DeviceHints): RenderQuality;
