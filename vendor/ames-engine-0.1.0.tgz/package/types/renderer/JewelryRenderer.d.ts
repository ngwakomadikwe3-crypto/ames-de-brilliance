import { PerspectiveCamera, Scene, Vector3 } from 'three';
import { type LoadedJewelryAsset } from '../loaders/loadJewelryAsset';
import { type JewelryAssetClassificationResult, type JewelryPartClassification } from '../analyzer/classifyJewelryAsset';
/** The kernel owns this backend and disposes it. No DOM or React is required. */
export interface JewelryRenderBackend {
    render(scene: Scene, camera: PerspectiveCamera): void;
    setSize(width: number, height: number, updateStyle: boolean): void;
    dispose(): void;
}
export interface JewelryRendererOptions {
    backend: JewelryRenderBackend;
    /** Each successful call transfers an independently owned asset to the kernel. */
    loadAsset?: (url: string) => Promise<LoadedJewelryAsset>;
}
export interface JewelryModel {
    asset: LoadedJewelryAsset;
    analysis: JewelryAssetClassificationResult;
}
export interface JewelryLoadOptions {
    validateBenchmark02?: boolean;
    verifiedRoles?: Readonly<Record<string, JewelryPartClassification>>;
}
/**
 * UI-independent rendering kernel. The host calls resize/render and handles input.
 * Scene/camera are available for host lighting and controls. Model resources are
 * kernel-owned; host-added lights, environments and other resources stay host-owned.
 */
export declare class JewelryRenderer {
    private readonly options;
    readonly scene: Scene<import("three").Object3DEventMap>;
    readonly camera: PerspectiveCamera;
    readonly target: Vector3;
    private current;
    private revision;
    private disposed;
    private readonly loader;
    constructor(options: JewelryRendererOptions);
    /** Browser convenience factory; the core constructor also supports headless backends. */
    static forCanvas(canvas: HTMLCanvasElement): JewelryRenderer;
    get model(): JewelryModel | null;
    private assertActive;
    /** Latest request wins. Failed/rejected replacements leave the current model intact. */
    load(url: string, options?: JewelryLoadOptions): Promise<JewelryModel>;
    /** Fits the entire world-space model without changing its geometry or transforms. */
    focus(): void;
    resize(width: number, height: number): void;
    render(): void;
    unload(): void;
    dispose(): void;
}
