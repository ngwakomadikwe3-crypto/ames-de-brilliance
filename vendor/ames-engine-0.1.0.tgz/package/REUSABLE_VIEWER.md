# AMES reusable interactive viewer

`createViewerScene` is the headless-testable viewer controller; `mountViewer` supplies its browser canvas, WebGL backend, OrbitControls, frame loop, resize observer and existing StudioEnvironment. It composes the existing engine/asset/material registries and owns no Boutique or Stone Tray UI. The separate `createBoutiquePresenter` and `createStoneTrayPresenter` adapters submit category-specific SHOW commands to the same viewer.

```ts
import { mountViewer, createStoneTrayPresenter } from '@ames/engine'
const viewer = await mountViewer(container, { signal: abortController.signal })
await createStoneTrayPresenter(viewer).show('stone-001')
await viewer.execute({ type: 'START_TURNTABLE' })
viewer.resetCamera()
const unsubscribe = viewer.subscribePerformance(() => consume(viewer.performance))
// On unmount:
unsubscribe()
viewer.dispose()
```

The viewer uses manifest IDs for LOAD_ASSET, SHOW_JEWELRY and SHOW_STONE; direct source URL commands are rejected at this layer. Legacy stone IDs resolve through the same registry. Jewelry can pan unless `pan: 'never'` is configured; stones cannot pan. Orbit rotation and wheel/pinch zoom use OrbitControls. Camera fitting and reset use an enclosing sphere, aspect-aware FOV and dynamic clipping; neither changes asset geometry or scale. FOCUS_COMPONENT accepts a mesh UUID or unique source mesh name. Unknown/ambiguous components reject. Turntable commands delegate to the engine's instance rotation.

`state` and `subscribe` expose idle/loading/ready/error/disposed status, displayed/requested IDs, command errors, quality and turntable state. Failed loads retain the prior model; invalid identity/category requests are rejected before replacing it. Latest valid load wins. Observable state and performance snapshots are immutable. Subscribers must not throw. `setPaused` prevents rendering and resets timing; hidden/zero-size browser containers also skip rendering. Cleanup cancels RAF, disconnects ResizeObserver, removes visibility/abort listeners, disposes controls/environment/runtime resources, and removes only the owned canvas. An AbortSignal also handles unmount during asynchronous environment creation. Hosts must dispose the viewer rather than independently disposing its exposed engine.

SET_QUALITY uses the existing FAST/INTERACTIVE/HIGH/BEAUTY pixel-ratio presets (0.75/1/1.5/2). The shared studio PMREM stays at 256; this host does not regenerate lighting or alter exposure on quality changes. Default exposure is 1 with existing ACES/standard-color settings. Default material assignment delegates to existing SET_METAL/SET_GEM profile commands; unknown semantic parts and custom optics remain protected. Set `applyDefaultMaterials: false` to retain source materials. Preview material assignment is not diamond optical acceptance.

`performance` / `subscribePerformance` report FPS, mean animation-frame time, renderer draw calls and submitted triangles. Samples use a bounded 120-frame window and notifications at most four times per second. Draw counts come from the WebGL backend, including its actual passes; they are not unique asset topology counts. Missing backend counters are null. There is no fabricated GPU-cost estimate. Resume/resize/quality changes reset sampling. Hosts implementing their own scheduler call `tick(rafTimestamp)` once per frame.

Files: `src/engine/viewer/{camera,stats,createViewerScene,mountViewer,index}.ts`, `src/engine/presentations/assetPresenters.ts`, `tests/interactiveViewer.test.ts`, shared test fixtures, and `scripts/validate-boutique-viewer.mjs`. Tests cover loading, camera fit, turntable start/stop/pause, presenter separation, switching races, disposal, invalid identities and performance/quality hooks. The browser run exercises actual orbit/zoom, resize, canonical loading and abort cleanup. No new assets or renderer/shader implementation were introduced.
