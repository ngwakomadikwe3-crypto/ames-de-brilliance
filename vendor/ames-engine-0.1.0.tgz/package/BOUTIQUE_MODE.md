# AMES Engine V1 — Boutique Mode (milestone 5)

`createBoutiqueMode(viewer, options)` manages product metadata, access and actions on an existing shared viewer. `mountBoutiqueViewer(container, options)` is an optional DOM presentation that creates exactly one `mountViewer` and delegates all rendering, camera fitting, interaction and materials to it. Neither imports Stone Tray presentation or duplicates rendering code. The existing AMES app screens are unchanged.

Boutique accepts ring, watch, bracelet, necklace and earring records from the viewer's asset registry. Stone records and missing IDs reject before fetch. The built-in production registry still contains only five canonical stones, so the Boutique initially shows an empty jewelry catalog. No jewelry records or assets have been fabricated. Hosts supply a real jewelry manifest to populate it.

```ts
import { mountBoutiqueViewer } from '@ames/engine'
const boutique = await mountBoutiqueViewer(container, {
  viewer: { registry: jewelryRegistry, signal: abortController.signal },
  canAccess: asset => entitlements.allow(asset.id, asset.accessTier),
  onFavorite: (asset, favorite, signal) => favorites.save(asset.id, favorite, signal),
  onCompare: (asset, signal) => comparison.add(asset.id, signal),
  onRequestAccess: (asset, signal) => accessFlow.open(asset.id, signal),
})
await boutique.show(selectedJewelryId)
// On host unmount:
await boutique.dispose()
```

## Product presentation and controls

The presentation displays product name, jewelry category, tier/access badge, loading/error/locked state, supported metals and gemstone previews. Category labels and `data-category` are specific to the product; geometry-aware framing remains the viewer's responsibility. Switches hide/pause the viewport while loading, then show the settled product. A failed replacement exposes the error and retains available previous product state. Old async completions cannot overwrite a newer selection.

Supported metals are derived from the manifest's metal slots and compatibility metadata: gold enables the existing yellow/white/rose-gold profiles; silver and platinum map to their profiles. Rhodium is not invented as compatible when the current manifest does not declare that family. A declared gem slot exposes the shared registry's eleven gemstone preview profiles. This is material preview availability, not a claim that a physical setting supports every real-world stone size or shape. No gem slot means no gem switcher.

Metal/gem switching calls the existing SET_METAL/SET_GEM commands, with polished/brushed/satin finish selection. Unsupported assignment is shown as an error rather than claiming a successful switch. Custom optical materials stay protected. Turntable toggles existing START_TURNTABLE/STOP_TURNTABLE commands; reset invokes the viewer's camera reset. Controls are disabled for loading/locked products. Selection fields say “Choose” until an explicit switch succeeds, avoiding a false claim about source/default materials.

Favorite/save and compare are hooks only. The component enables their buttons when the host supplies handlers. Favorite state updates after successful completion and is remembered per product for this controller's lifetime; persistent storage remains host-owned. Async hooks receive a signal aborted on selection changes or disposal. Compare does not create a second renderer or a comparison screen. Request-access similarly delegates to a host hook.

## Access and ownership

Public records are available. Premium and exclusive records are locked by default unless `canAccess` grants access. Locked selections expose metadata but do not fetch that GLB; any previous canvas is hidden and paused. Access is checked again after loading and before material controls. `refreshAccess` reevaluates the selected product and can load it following a grant. The engine does not sell subscriptions, cache entitlements or secure a public URL: server authorization and asset delivery protection remain host responsibilities.

`createBoutiqueMode` borrows its viewer by default, unsubscribes/aborts on disposal, stops its turntable and restores the prior pause state. Use `ownsViewer: true` to transfer disposal ownership. The DOM mount owns its viewer and removes its root on `dispose()`. Keep one active presentation owner per viewer; borrowing does not imply simultaneous independent product selections on one scene. State is observable with `subscribe` and immutable snapshots, making a React host possible without putting React inside the runtime.

## Validation

Application and standalone builds PASS; built-package Node smoke check PASS. Full suite: **109 tests / 28 files PASS**, preserving all 94 previous tests. New tests cover Boutique load/category validation, material switching, public/premium/exclusive state, product switching/viewer reuse, favorite/compare hooks and owned/borrowed cleanup; viewer tests cover the underlying interaction lifecycle.

Chrome browser integration PASS with zero page/console errors. It uses the real canonical round for core viewer interaction and a **test-only manifest pointing at the existing unmodified Benchmark 02** for Boutique controls. No test products are inserted into the production registry. Verified material controls, turntable/reset, favorite/compare callbacks, locked-state hiding/pause without replacement load, DOM cleanup and abort during mount. All **87 protected source/asset file hashes remain unchanged**, including Benchmark 02 and every canonical asset. Screenshots and raw observations are in `../../outputs/boutique-viewer/`.

The browser stats are short functional-run snapshots, not a controlled performance or photorealism gate. Existing diamond rendering acceptance remains unresolved. No new shader work, geometry, assets or production app integration is included. Stop after this milestone.

Files: `src/engine/boutique/{createBoutiqueMode,mountBoutiqueViewer}.ts`, shared viewer/presenter modules, public exports, `tests/{boutiqueMode,interactiveViewer}.test.ts`, `tests/viewerFixtures.ts`, `scripts/validate-boutique-viewer.mjs`, and this documentation.
