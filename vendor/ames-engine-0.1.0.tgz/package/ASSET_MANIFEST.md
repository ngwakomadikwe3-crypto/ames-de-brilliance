# AMES asset manifest and GLB registry

The shared registry supports `ring`, `watch`, `bracelet`, `necklace`, `earring` and `stone`. Boutique and Stone Tray have separate category-scoped consumers over the same immutable registry. No UI, jewelry assets, shaders or geometry are introduced by this foundation.

`AssetManifest` is a schema-version-1 document of `AssetRecord` entries: `id`, `name`, `category`, `assetPath`, nullable `previewPath`, `materialSlots`, `stoneReferences`, `metalCompatibility`, `accessTier`, `tags` and `status`. Material slots describe intended kinds and optional source material names; runtime selectors bind them to mesh UUIDs without reclassifying source parts. Metadata does not itself assign a material.

The built-in manifest derives stones 001–005 from the existing Stone Library. IDs match existing stone IDs; GLB paths are unchanged. Previews are explicitly null, metal compatibility is empty, access is public, and status is validated for geometry/ingestion. This does not mean visual acceptance passed, grant an asset license, or implement subscriptions. Public/premium/exclusive are metadata only. Draft/validated/published/archived status does not automatically hide or block an asset. The catalog contains no fictional jewelry records.

```ts
import { createAmesEngine, assetRegistry, createBoutiqueAssets, createStoneTrayAssets } from '@ames/engine'
const boutique = createBoutiqueAssets(assetRegistry)
const tray = createStoneTrayAssets(assetRegistry)
tray.resolve('stone-001')
// boutique.resolve('stone-001') rejects WRONG_CATEGORY.
const engine = createAmesEngine({ backend, registry: assetRegistry })
engine.init()
await engine.loadById('stone-001', 'stone')
await engine.execute({ type: 'SHOW_STONE', assetId: 'stone-002' })
engine.dispose()
```

`createAssetRegistry(unknown)` validates and copies complete metadata, rejecting duplicates, unsupported categories/tiers, missing fields and invalid paths. `loadAssetManifest(url, fetcher?)` fetches and validates JSON atomically. Root-relative and HTTP(S) paths are supported, including query parameters; GLB URLs must end in `.glb` before the query. Parent traversal, backslashes, protocol-relative URLs and invalid schemes are rejected. Root-relative asset paths resolve against the host origin, not the manifest directory. No existence claim is made until an asset is fetched. Preview paths are metadata only and are not downloaded by this milestone.

`registry.get` returns undefined on a miss; `require` raises `ASSET_NOT_FOUND` or `WRONG_CATEGORY`. `loadById` resolves before changing the current model and delegates to the unchanged GLTF/GLB loader through `loadGlbAsset`. `GLB_LOAD_FAILED` includes the ID/path and underlying error for HTTP/network/parser failures. There are no duplicate HEAD requests, retry loops or shared mutable model caches. The kernel owns loaded geometry/materials and retains the previous model on failed replacement. Standalone `loadGlbAsset` transfers resource ownership to its caller. Existing URL-based runtime commands remain compatible; ID-based Boutique calls reject stone categories before fetch. Stone-ID commands resolve through the same registry by `stoneReferences`.

Files: `src/engine/assets/{schema,registry,canonicalManifest,consumers,loadGlbAsset,index}.ts`, core protocol/runtime integration, and `tests/{assetRegistry,assetLoader.integration}.test.ts`. Tests cover the requested lookups, category separation, all tiers, immutable snapshots, malformed manifests, HTTP errors and actual loading of all five canonical GLBs. The real-asset test also verifies bytes remain unchanged.

Validated with the material-system milestone: full suite **94 tests / 26 files PASS**; application and standalone builds PASS. No existing tests were removed or weakened.
