# AMES V1 material system — milestone 3

Reusable, immutable `MetalMaterialProfile` and `GemMaterialProfile` records are separate from per-instance Three.js materials. `materialRegistry` exposes typed metal/gem lookups; `createMaterialRegistry` validates custom typed profiles and takes an independent frozen snapshot. Boutique and Stone Tray use the same profiles and runtime assignment API. No UI, assets, canonical geometry, locked classification code or diamond transport implementation is changed.

## Metals and finishes

| ID | Metal |
| --- | --- |
| `metal:18k-yellow-gold` | 18k yellow gold |
| `metal:18k-white-gold` | 18k white gold |
| `metal:rose-gold` | Rose gold |
| `metal:platinum` | Platinum |
| `metal:silver` | Silver |
| `metal:rhodium` | Rhodium |

Every profile supports polished, brushed and satin. Colors and polished roughness come from the existing AMES metal presets. Brushed uses roughness 0.32 with physical-material anisotropy 0.45; satin uses roughness 0.42 without anisotropy. These are authored PBR finish presets, not measured alloy spectra or microscopic scratch textures. They use standard Three.js MeshPhysicalMaterial parameters, with no custom shader code.

## Gemstones

The registry contains `gem:diamond`, `gem:ruby`, `gem:sapphire`, `gem:emerald`, `gem:spinel`, `gem:alexandrite`, `gem:tanzanite`, `gem:aquamarine`, `gem:tourmaline`, `gem:topaz` and `gem:garnet`.

Diamond reuses the existing `createGemstonePreviewMaterial` unchanged, including IOR 2.417. Colored profiles use that existing PBR preview factory with authored tint and a representative scalar IOR (midpoint of the documented range). The source ranges come from GIA: [ruby](https://www.gia.edu/ruby), [sapphire](https://www.gia.edu/sapphire?lang=en), [emerald](https://www.gia.edu/emerald), [spinel](https://www.gia.edu/spinel), [alexandrite](https://www.gia.edu/alexandrite), [tanzanite](https://www.gia.edu/tanzanite), [aquamarine](https://www.gia.edu/gia-website/aquamarine), [tourmaline](https://www.gia.edu/tourmaline), [topaz](https://www.gia.edu/topaz) and [garnet](https://www.gia.edu/garnet). Sources were checked on 2026-09-07; each profile retains its source reference.

These profiles support reusable identity and preview assignment. They do **not** implement crystal-axis birefringence, spectral absorption, fluorescence, alexandrite color change or tanzanite pleochroism. Garnet is a broad gem-group preset; its midpoint is an illustrative approximation, not a specimen measurement. No new photorealism or fire acceptance is claimed. Existing BVH/Spectral-Glass diamond optics remain untouched.

## Semantic assignment and commands

`RuntimeMaterialAssignment` derives slots from existing classifications: METAL → `metal`, SETTING → `setting`, CENTER_STONE → `center-stone`, ACCENT_STONE → `accent-stone`. UNKNOWN remains unchanged. Callers can provide explicit `SemanticMaterialSlot` records containing mesh UUIDs and optional material indices. Slots must not overlap; multiple source materials require explicit indices. A known single-mesh Stone Tray asset gets an explicit `gem` slot from its registered identity, without rewriting its classifier result.

```ts
await engine.execute({ type: 'SHOW_STONE', assetId: 'stone-001' })
await engine.execute({ type: 'SET_GEM', materialId: 'gem:sapphire', slotId: 'gem' })
// For a loaded jewelry model with semantic metal parts:
await engine.execute({ type: 'SET_METAL', materialId: 'metal:18k-white-gold', finish: 'brushed' })
```

Legacy `{ metal: 'gold' | 'silver' | 'platinum' }` and `{ gemTypeId: 'gem:...' }` payloads remain supported. Host `setMetal` / `setGem` hooks take precedence. Without a hook the runtime resolves the profile and assigns matching semantic targets. It reports `unsupported` when there is no settled model, no matching target, or a protected custom optical material. Invalid IDs/slots reject before partial assignment. Loaded ShaderMaterial/NodeMaterial optics are never overwritten automatically; an explicit renderer adapter is required even when switching back to diamond. No material changes occur just because a model loads.

Assignments alter material references only: UUIDs, mesh names, semantic analysis, tags, geometry, groups, transforms and canonical identity are retained. Selecting ruby on a canonical diamond changes only the instance preview; it does not re-register that stone as a ruby specimen or overwrite its catalog optical identity.

The binding retains original source materials, shares new materials only within its owned assignment, disposes superseded materials once and restores originals before kernel disposal. Replacement loads suspend assignment while pending; failures resume the previous assignment, successful replacement releases it. Direct users of `RuntimeMaterialAssignment` must dispose it before unloading their model. Async external adapters own their resources and must observe the runtime abort signal.

## Files and validation

`src/engine/material-system/{schema,metals,gems,registry,assignment,index}.ts` contains the new system. `src/engine/core/{protocol,createAmesEngine}.ts` connects commands and ownership. The standalone build permits only the two existing PBR preset/preview helper modules from the legacy materials directory; research shaders and React hosts remain excluded.

Tests cover all six metal lookups/finishes, eleven gem lookups, semantic and per-index assignment, invalid IDs/slots, custom shader protection, SET_METAL/SET_GEM, restoration after failed loads and resource disposal. Registry and real-GLB tests complete the preceding manifest/loader foundation. This milestone stops at reusable assignment; no viewer redesign or diamond-renderer investigation follows automatically.

Validation on 2026-09-07: application and standalone builds PASS; built-package Node smoke check PASS; full thread-worker suite **94 tests / 26 files PASS**, including all 80 previously passing tests. Existing application BVH namespace/chunk-size warnings remain. These checks validate data, assignment and ownership, not a new photorealistic rendering gate.
