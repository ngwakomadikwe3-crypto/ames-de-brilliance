import { Vector3 } from 'three'
import { ConvexGeometry } from 'three/examples/jsm/geometries/ConvexGeometry.js'
import { createRoundBrilliantGeometry } from './createRoundBrilliantGeometry'

/** Preserve eightfold brilliant optics, refine both closed girdle boundaries. */
export function createStudioBrilliantGeometry() {
  const base=createRoundBrilliantGeometry(), attribute=base.getAttribute('position')
  const points:Vector3[]=[],seen=new Set<string>()
  for(let i=0;i<attribute.count;i++) {
    const v=new Vector3().fromBufferAttribute(attribute,i),key=v.toArray().map(x=>x.toFixed(7)).join(',')
    if(!seen.has(key)){seen.add(key);points.push(v)}
  }
  for(let i=0;i<64;i++)for(const y of [-.02,.02]) {
    const a=i*Math.PI*2/64,v=new Vector3(Math.cos(a),y,Math.sin(a)),key=v.toArray().map(x=>x.toFixed(7)).join(',')
    if(!seen.has(key)){seen.add(key);points.push(v)}
  }
  base.dispose()
  const geometry=new ConvexGeometry(points)
  geometry.computeBoundingBox();geometry.computeBoundingSphere()
  const normals=geometry.getAttribute('normal'),planes=new Set<string>()
  for(let i=0;i<normals.count;i+=3)planes.add([normals.getX(i),normals.getY(i),normals.getZ(i)].map(n=>n.toFixed(5)).join(','))
  geometry.userData={cut:'eightfold-brilliant-refined-girdle',flatFacets:planes.size,girdleSegments:64}
  return geometry
}
