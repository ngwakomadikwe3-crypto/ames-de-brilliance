import { Suspense, useState } from 'react'
import { usePhysicalStudio } from './usePhysicalStudio'
import { PhysicalStudioModel } from '../jewelry/PhysicalStudioModel'
import { ViewerControls } from './ViewerControls'
import { StudioBloom } from './StudioBloom'
import type { CameraPreset } from './cameraFraming'

export function PhysicalStudioScene({modelUrl,cameraPreset,zoom,turntableEnabled,resetToken,controlsEnabled,onModelReady}: {
  modelUrl: string;cameraPreset?:CameraPreset;zoom?:number;turntableEnabled?:boolean;resetToken?:number;controlsEnabled?:boolean;onModelReady?:()=>void
}) {
  const studio=usePhysicalStudio()
  const [interacting,setInteracting]=useState(false)
  if(!studio)return null
  return <>
    <directionalLight position={[3,4,5]} intensity={1.2} color="#ffffff"/>
    <directionalLight position={[-3,2,-4]} intensity={.6} color="#f1f6ff"/>
    <Suspense fallback={null}><PhysicalStudioModel url={modelUrl} studio={studio} enabled={turntableEnabled??false} interacting={interacting} resetToken={resetToken} onReady={onModelReady}/></Suspense>
    {controlsEnabled&&<ViewerControls cameraPreset={cameraPreset} zoom={zoom} resetToken={resetToken} onInteractionChange={setInteracting}/>}
    <StudioBloom/>
  </>
}
