import { PhysicalStudioScene } from './PhysicalStudioScene'
import type { CameraPreset } from './cameraFraming'
import { Canvas } from '@react-three/fiber'
import { ACESFilmicToneMapping, SRGBColorSpace } from 'three'
import type { BufferGeometry, CubeTexture } from 'three'
import { useEffect, useState } from 'react'
import type { CSSProperties } from 'react'
import { DIAMOND_CALIBRATION } from '../calibration'
import { getRoundBrilliantDiagnostics } from '../jewelry/canonicalRoundBrilliantGeometry'
import { ViewerScene } from './ViewerScene'
import { chooseGemstoneQuality, chooseViewerQuality, nextLowerViewerQuality, qualityProfile, readViewerRuntime } from './viewerQuality'
import type { JewelryOpticsProfile } from './opticsProfiles'

export const DIAMOND_VIEWER_CAMERA = {
  position: [...DIAMOND_CALIBRATION.camera.position] as [number, number, number],
  fov: DIAMOND_CALIBRATION.camera.fov,
  near: DIAMOND_CALIBRATION.camera.near,
  far: DIAMOND_CALIBRATION.camera.far,
}

export const DIAMOND_TONE_MAPPING_EXPOSURE = DIAMOND_CALIBRATION.camera.exposure

export interface JewelryViewerProps {
  className?: string
  diamondRotationY?: number
  geometry?: BufferGeometry
  environment?: CubeTexture
  /** Absolute camera angles around the normalized catalog model. */
  cameraPreset?: CameraPreset
  /** Magnification relative to calibrated fit; distance clamps to [2.5, 8]. */
  zoom?: number
  /** Explicit host rotation; undefined retains the default quality-tier behavior. */
  turntableEnabled?: boolean
  /** Pause frames while preserving the mounted scene and customer camera state. */
  paused?: boolean
  /** Optional review-lab optics; reference preserves the existing presentation. */
  opticsProfile?: JewelryOpticsProfile
  /** Change to restore preset framing and zero controlled model rotation. */
  resetToken?: number
  controlsEnabled?: boolean
  /** Real catalog GLB to render as the primary live object. */
  modelUrl?: string
  /** Explicit opt-in to the procedural round-brilliant path. */
  procedural?: boolean
  /** Called once the requested GLB has loaded into the live viewer. */
  onModelReady?: () => void
  /** Let the host application provide the visible page environment behind the canvas. */
  transparentBackground?: boolean
  style?: CSSProperties
}

export function JewelryViewer({
  className = '',
  diamondRotationY,
  geometry,
  environment,
  cameraPreset, zoom, turntableEnabled, resetToken,
  paused = false,
  opticsProfile = 'reference',
  controlsEnabled = true,
  modelUrl,
  procedural = false,
  onModelReady,
  transparentBackground = false,
  style,
}: JewelryViewerProps) {
  const [initialRuntime] = useState(() => readViewerRuntime())
  const [tier, setTier] = useState(() => (opticsProfile === 'gemstone-studio' || opticsProfile === 'mounted-gem-studio') ? chooseGemstoneQuality(initialRuntime) : chooseViewerQuality(initialRuntime))
  useEffect(() => {
    const update = () => setTier((opticsProfile === 'gemstone-studio' || opticsProfile === 'mounted-gem-studio') ? chooseGemstoneQuality(readViewerRuntime()) : chooseViewerQuality(readViewerRuntime()))
    window.addEventListener('resize', update)
    return () => window.removeEventListener('resize', update)
  }, [opticsProfile])
  const baseQuality = qualityProfile(tier)
  const quality = (opticsProfile === 'gemstone-studio' || opticsProfile === 'mounted-gem-studio')
    ? { ...baseQuality, dpr: (tier === 'LOW' && turntableEnabled === true ? [1, 1.5] : [1, 2]) as [number, number], contactShadows: false }
    : opticsProfile === 'soft-studio' && (tier === 'SAFE' || tier === 'LOW')
      ? { ...baseQuality, dpr: [1, 1.5] as [number, number] }
      : baseQuality
  const classes = ['jewelry-viewer', className].filter(Boolean).join(' ')
  const diagnostics = geometry ? getRoundBrilliantDiagnostics(geometry) : undefined

  return (
    <section
      className={classes}
      role="region"
      aria-label="AMES Engine 3D jewelry viewer"
      data-geometry-uuid={diagnostics?.uuid}
      data-geometry-fingerprint={diagnostics?.fingerprint}
        data-environment-uuid={environment?.uuid}
        data-render-mode={procedural ? 'procedural' : modelUrl ? 'glb' : 'procedural'}
      data-model-url={modelUrl ?? undefined}
      data-quality-tier={quality.tier}
      data-optics-profile={opticsProfile}
      style={style}
      >
      <Canvas
        camera={DIAMOND_VIEWER_CAMERA}
        dpr={quality.dpr}
        frameloop={paused ? 'never' : ((opticsProfile === 'gemstone-studio' || opticsProfile === 'mounted-gem-studio') || opticsProfile === 'soft-studio') && turntableEnabled === false ? 'demand' : quality.tier === 'SAFE' ? 'demand' : 'always'}
        gl={{
          antialias: (opticsProfile === 'gemstone-studio' || opticsProfile === 'mounted-gem-studio') || opticsProfile === 'soft-studio' || quality.tier === 'HIGH' || quality.tier === 'MEDIUM',
          alpha: true,
          preserveDrawingBuffer: initialRuntime.webKitMobile === true,
          toneMapping: ACESFilmicToneMapping,
          outputColorSpace: SRGBColorSpace,
        }}
        onCreated={({ camera, gl }) => {
          gl.debug.onShaderError = (context, program) => {
            console.error('AMES studio shader failed:', context.getProgramInfoLog(program))
            gl.domElement.dispatchEvent(new CustomEvent('ames-viewer-error', { bubbles: true, detail: 'The 3D renderer could not initialise. Showing the still preview.' }))
          }
          camera.lookAt(...DIAMOND_CALIBRATION.camera.target)
          camera.updateMatrixWorld()
          gl.toneMappingExposure = DIAMOND_TONE_MAPPING_EXPOSURE
        }}
        shadows={quality.contactShadows}
      >
        {modelUrl && (opticsProfile === 'gemstone-studio' || opticsProfile === 'mounted-gem-studio') ? <PhysicalStudioScene modelUrl={modelUrl} cameraPreset={cameraPreset} zoom={zoom} turntableEnabled={turntableEnabled} resetToken={resetToken} controlsEnabled={controlsEnabled} onModelReady={onModelReady}/> : <ViewerScene
          diamondRotationY={diamondRotationY}
          geometry={geometry}
          environment={environment}
          cameraPreset={cameraPreset} zoom={zoom} turntableEnabled={turntableEnabled} resetToken={resetToken}
          controlsEnabled={controlsEnabled}
          modelUrl={modelUrl}
          procedural={procedural}
          quality={quality}
          opticsProfile={opticsProfile}
          transparentBackground={transparentBackground}
          onQualityDowngrade={() => setTier(current => nextLowerViewerQuality(current))}
          onModelReady={onModelReady}
        />}
      </Canvas>
    </section>
  )
}
