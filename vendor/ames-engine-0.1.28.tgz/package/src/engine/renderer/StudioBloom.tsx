import { useEffect, useMemo } from 'react'
import { useFrame, useThree } from '@react-three/fiber'
import { Color, HalfFloatType, NoToneMapping, ShaderMaterial, Vector2, WebGLRenderTarget } from 'three'
import { FullScreenQuad } from 'three/examples/jsm/postprocessing/Pass.js'

let bloomSamples = 4
const STAR_THRESHOLD = 1.8, STAR_GAIN = .07
/** Stones join this layer: only light leaving a stone becomes a star, never a highlight on the metal. */
export const STAR_LAYER = 3
/** Edge smoothing samples for the studio render (fewer on phones). */
export function setBloomSamples(n: number) { bloomSamples = n }

/** HDR-only highlight bloom, preserving transparent alpha and tone-mapping once. */
export function StudioBloom() {
  const {gl,size}=useThree(),dpr=useThree(s=>s.viewport.dpr)
  const state=useMemo(()=>{
    const target=()=>new WebGLRenderTarget(1,1,{type:HalfFloatType,depthBuffer:true})
    const base=target(), blurA=target(),blurB=target(),peaks=target(),rayA=target(),rayB=target(),gemPass=target()
    base.samples=bloomSamples
    const vertexShader='varying vec2 vUv; void main(){vUv=uv;gl_Position=vec4(position.xy,0.,1.);}'
    const blur=new ShaderMaterial({vertexShader,depthTest:false,depthWrite:false,toneMapped:false,
      uniforms:{inputMap:{value:base.texture},stepUv:{value:new Vector2()},threshold:{value:2}},
      fragmentShader:`varying vec2 vUv;uniform sampler2D inputMap;uniform vec2 stepUv;uniform float threshold;
      void main(){vec3 sum=vec3(0.);float weightSum=0.;for(int i=-4;i<=4;i++){
        float w=exp(-float(i*i)/7.);vec3 c=texture2D(inputMap,vUv+float(i)*stepUv).rgb;
        float peak=dot(c,vec3(.2126,.7152,.0722));c*=max(peak-threshold,0.)/max(peak,.0001);sum+=c*w;weightSum+=w;
      }gl_FragColor=vec4(sum/weightSum,1.);}`})
    // Brilliance: the brightest flashes of light in the stones (and only those) are drawn out into fine four-point
    // stars, as a photographer's eye and lens see a diamond's fire. Found on a quarter-size copy, so it stays cheap.
    const peak=new ShaderMaterial({vertexShader,depthTest:false,depthWrite:false,toneMapped:false,
      uniforms:{inputMap:{value:gemPass.texture},texel:{value:new Vector2()},threshold:{value:STAR_THRESHOLD}},
      fragmentShader:`varying vec2 vUv;uniform sampler2D inputMap;uniform vec2 texel;uniform float threshold;
      // White light only: a star is a flash of the lamp itself, not a bright coloured facet.
      float lum(vec3 c){return min(c.r,min(c.g,c.b));}
      void main(){vec3 c=texture2D(inputMap,vUv).rgb;float p=lum(c),around=0.,inside=1.;
        // A star only where a point of light stands out from the stone around it, not across a bright face,
        // and never on a stone's outline, where the dark page beside it would make any edge look like a point.
        for(int i=0;i<8;i++){float a=float(i)*.785398;vec4 s=texture2D(inputMap,vUv+vec2(cos(a),sin(a))*texel*2.);around+=lum(s.rgb);inside=min(inside,s.a);}
        around/=8.;if(inside<.5)p=0.;float floor_=max(threshold,around*3.);gl_FragColor=vec4(c*max(p-floor_,0.)/max(p,.0001),1.);}`})
    const ray=new ShaderMaterial({vertexShader,depthTest:false,depthWrite:false,toneMapped:false,
      uniforms:{inputMap:{value:peaks.texture},stepUv:{value:new Vector2()}},
      fragmentShader:`varying vec2 vUv;uniform sampler2D inputMap;uniform vec2 stepUv;
      void main(){vec3 sum=vec3(0.);for(int i=1;i<=8;i++){float w=pow(.66,float(i));
        sum+=(texture2D(inputMap,vUv+float(i)*stepUv).rgb+texture2D(inputMap,vUv-float(i)*stepUv).rgb)*w;}
        gl_FragColor=vec4(sum,1.);}`})
    const output=new ShaderMaterial({vertexShader,depthTest:false,depthWrite:false,toneMapped:true,
      uniforms:{baseMap:{value:base.texture},glowMap:{value:blurB.texture},rayMapA:{value:rayA.texture},rayMapB:{value:rayB.texture},starGain:{value:STAR_GAIN}},
      fragmentShader:`varying vec2 vUv;uniform sampler2D baseMap;uniform sampler2D glowMap;uniform sampler2D rayMapA;uniform sampler2D rayMapB;uniform float starGain;
      void main(){vec4 base=texture2D(baseMap,vUv);vec3 glow=texture2D(glowMap,vUv).rgb*.035+(texture2D(rayMapA,vUv).rgb+texture2D(rayMapB,vUv).rgb)*starGain;
        float halo=clamp(max(glow.r,max(glow.g,glow.b)),0.,.18);float a=max(base.a,halo);
        gl_FragColor=vec4((base.rgb+glow)/max(a,.0001),a);
        #include <tonemapping_fragment>
        #include <colorspace_fragment>
        gl_FragColor.rgb *= gl_FragColor.a;
      }`})
    return {base,blurA,blurB,gemPass,peaks,rayA,rayB,peak,ray,blur,output,quad:new FullScreenQuad(blur),clear:new Color()}
  },[])
  useEffect(()=>{
    const dpr=gl.getPixelRatio(),w=Math.max(1,Math.round(size.width*dpr)),h=Math.max(1,Math.round(size.height*dpr))
    state.base.setSize(w,h);state.blurA.setSize(Math.ceil(w/2),Math.ceil(h/2));state.blurB.setSize(Math.ceil(w/2),Math.ceil(h/2))
    const qw=Math.ceil(w/4),qh=Math.ceil(h/4);state.peaks.setSize(qw,qh);state.gemPass.setSize(qw,qh);state.rayA.setSize(qw,qh);state.rayB.setSize(qw,qh)
    gl.domElement.dataset.studioBloom='hdr-threshold';return()=>{delete gl.domElement.dataset.studioBloom}
  },[gl,size,state,dpr])
  useEffect(()=>()=>{state.base.dispose();state.blurA.dispose();state.blurB.dispose();state.peaks.dispose();state.gemPass.dispose();state.rayA.dispose();state.rayB.dispose();state.peak.dispose();state.ray.dispose();state.blur.dispose();state.output.dispose();state.quad.dispose()},[state])
  useFrame(({scene,camera})=>{
    const target=gl.getRenderTarget(),tone=gl.toneMapping,alpha=gl.getClearAlpha();gl.getClearColor(state.clear)
    gl.setClearColor(0,0);gl.toneMapping=NoToneMapping;gl.setRenderTarget(state.base);gl.clear();gl.render(scene,camera)
    state.quad.material=state.blur;state.blur.uniforms.inputMap.value=state.base.texture
    state.blur.uniforms.threshold.value=2;state.blur.uniforms.stepUv.value.set(1/state.blurA.width,0)
    gl.setRenderTarget(state.blurA);state.quad.render(gl)
    state.blur.uniforms.inputMap.value=state.blurA.texture;state.blur.uniforms.threshold.value=0;state.blur.uniforms.stepUv.value.set(0,1/state.blurB.height)
    gl.setRenderTarget(state.blurB);state.quad.render(gl)
    // Star rays, set a little off square (about 20 degrees) as a cross filter turns them.
    // The stones alone, at quarter size, so metal highlights never become stars.
    const mask=camera.layers.mask;camera.layers.set(STAR_LAYER);gl.setRenderTarget(state.gemPass);gl.clear();gl.render(scene,camera);camera.layers.mask=mask
    state.quad.material=state.peak;state.peak.uniforms.texel.value.set(1/state.gemPass.width,1/state.gemPass.height)
    gl.setRenderTarget(state.peaks);state.quad.render(gl)
    state.quad.material=state.ray;state.ray.uniforms.stepUv.value.set(Math.cos(.35)/state.peaks.width,Math.sin(.35)/state.peaks.height);gl.setRenderTarget(state.rayA);state.quad.render(gl)
    state.ray.uniforms.stepUv.value.set(-Math.sin(.35)/state.peaks.width,Math.cos(.35)/state.peaks.height);gl.setRenderTarget(state.rayB);state.quad.render(gl)
    gl.toneMapping=tone;gl.setRenderTarget(target);state.quad.material=state.output;state.quad.render(gl);gl.setClearColor(state.clear,alpha)
  },1)
  return null
}
