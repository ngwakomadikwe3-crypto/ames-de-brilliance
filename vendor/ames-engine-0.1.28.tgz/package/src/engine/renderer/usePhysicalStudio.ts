import { useEffect, useState } from 'react'
import { useThree } from '@react-three/fiber'
import { DataTexture, EquirectangularReflectionMapping, HalfFloatType, LinearFilter, PMREMGenerator, LinearSRGBColorSpace, RGBAFormat } from 'three'
import { HDRLoader } from 'three/examples/jsm/loaders/HDRLoader.js'
import type { Texture, WebGLRenderTarget } from 'three'
import { createStripStudioEnvironment } from './createStripStudioEnvironment'

// Bright jewellery light tent: diamonds return white light and polished metal reads crisp.
const DIAMOND_TENT = .12
// v3 is the same light tent, pixel for pixel, saved run-length compressed: 0.2 MB instead of 2.1 MB.
export const STUDIO_HDR_URL = '/ames-engine/environments/jewellery-tent-v3.hdr'
/** environment: the light tent (gems); metal: strip lights in a dark room (polished metal reflections). */
export interface PhysicalStudio { radiance: DataTexture; environment: Texture; metal: Texture; diamond: Texture }

/** Each renderer owns its PMREM. Failure is fatal to 3D, never a substitute map. */
export function usePhysicalStudio(): PhysicalStudio | null {
  const { gl, scene, invalidate } = useThree()
  const [maps, setMaps] = useState<PhysicalStudio | null>(null)
  const [error, setError] = useState<Error | null>(null)
  useEffect(() => {
    let alive = true
    let radiance: DataTexture | undefined, target: WebGLRenderTarget | undefined, strips: { dispose: () => void } | undefined, darker: { dispose: () => void } | undefined
    const previous = scene.environment
    const generator = new PMREMGenerator(gl)
    const controller = new AbortController()
    const timeout = setTimeout(()=>controller.abort(),20000)
    gl.domElement.dataset.studioEnvironment = 'loading-hdr'
    fetch(STUDIO_HDR_URL,{signal:controller.signal}).then(async response=>{
      if(!response.ok)throw Error('Studio HDR request failed.')
      const decoded=new HDRLoader().setDataType(HalfFloatType).parse(await response.arrayBuffer())
      if(!decoded?.data||!decoded.width||!decoded.height)throw Error('Invalid studio HDR image.')
      return decoded
    }).then(decoded => {
      if (!alive) return
      const hdr=new DataTexture(decoded.data,decoded.width,decoded.height,RGBAFormat,HalfFloatType)
      hdr.flipY=true;hdr.minFilter=LinearFilter;hdr.magFilter=LinearFilter;hdr.generateMipmaps=false;hdr.needsUpdate=true
      radiance = hdr
      hdr.mapping = EquirectangularReflectionMapping
      hdr.colorSpace = LinearSRGBColorSpace
      if (!hdr.image.width || !hdr.image.height) throw Error('Studio HDR image is empty.')
      target = generator.fromEquirectangular(hdr)
      if (!target.texture || gl.getContext().isContextLost()) throw Error('Studio HDR processing failed.')
      const priorTarget=gl.getRenderTarget(),context=gl.getContext()
      gl.setRenderTarget(target)
      const complete=context.checkFramebufferStatus(context.FRAMEBUFFER)===context.FRAMEBUFFER_COMPLETE
      gl.setRenderTarget(priorTarget)
      if(!complete)throw Error('Studio HDR render target is unavailable.')
      scene.environment = target.texture
      scene.environmentIntensity = 1
      gl.domElement.dataset.studioEnvironment = 'hdr-pmrem'
      const metal = createStripStudioEnvironment(gl); strips = metal
      // Diamonds see the same lamps in a darker room: crisper black and white in the stone, brighter flashes.
      const diamond = createStripStudioEnvironment(gl, DIAMOND_TENT); darker = diamond
      setMaps({ radiance: hdr, environment: target.texture, metal: metal.texture, diamond: diamond.texture }); invalidate()
    }).catch(() => {
      if (alive) setError(Error('Studio lighting could not load. Showing the still preview.'))
    }).finally(() => { clearTimeout(timeout); generator.dispose() })
    return () => {
      alive = false; controller.abort(); clearTimeout(timeout); scene.environment = previous
      radiance?.dispose(); target?.dispose(); strips?.dispose(); darker?.dispose()
      delete gl.domElement.dataset.studioEnvironment
    }
  }, [gl, scene, invalidate])
  if (error) throw error
  return maps
}
