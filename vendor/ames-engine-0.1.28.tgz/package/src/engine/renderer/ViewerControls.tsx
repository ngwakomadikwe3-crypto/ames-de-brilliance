import { GEMSTONE_CAMERA_FOV, GEMSTONE_LENS_RATIO } from './cameraFraming'
import { DIAMOND_CALIBRATION } from '../calibration'
import type { PerspectiveCamera } from 'three'
import { OrbitControls } from '@react-three/drei'
import { useThree } from '@react-three/fiber'
import { useEffect, useRef } from 'react'
import { Spherical } from 'three'
import type { OrbitControls as OrbitControlsImpl } from 'three-stdlib'
import { cameraFraming, CAMERA_MIN_DISTANCE, CAMERA_MAX_DISTANCE, CAMERA_MIN_POLAR } from './cameraFraming'
import type { CameraPreset } from './cameraFraming'
export function ViewerControls({ onInteractionChange, cameraPreset, zoom, resetToken }: {
  onInteractionChange?: (active: boolean) => void
  cameraPreset?: CameraPreset
  zoom?: number
  resetToken?: number
}) {
  const controls = useRef<OrbitControlsImpl>(null)
  const camera = useThree(state => state.camera)
  const invalidate = useThree(state => state.invalidate)
  useEffect(() => {
    if (!cameraPreset || !controls.current) return
    // Clear prior damping deltas so a reset/preset cannot drift toward the old orbit.
    const damping = controls.current.enableDamping
    controls.current.enableDamping = false
    controls.current.update()
    controls.current.reset()
    const perspective = camera as PerspectiveCamera
    if (perspective.isPerspectiveCamera) {
      perspective.fov = cameraPreset === 'gemstone' ? GEMSTONE_CAMERA_FOV : DIAMOND_CALIBRATION.camera.fov
      perspective.updateProjectionMatrix()
    }
    const framing = cameraFraming(cameraPreset, zoom)
    controls.current.target.set(0, 0, 0)
    camera.position.setFromSpherical(new Spherical(framing.radius, framing.phi, framing.theta))
    controls.current.update()
    controls.current.enableDamping = damping
    // Request the committed camera frame after React/R3F finishes this update.
    const frame = requestAnimationFrame(invalidate)
    // Zoom is applied separately so zoom commands retain a manually chosen angle.
    return () => cancelAnimationFrame(frame)
  }, [cameraPreset, resetToken, camera, invalidate])
  useEffect(() => {
    if (zoom === undefined || !controls.current) return
    const target = controls.current.target
    camera.position.sub(target).setLength(cameraFraming(cameraPreset ?? 'three_quarter', zoom).radius).add(target)
    controls.current.update()
    const frame = requestAnimationFrame(invalidate)
    return () => cancelAnimationFrame(frame)
  }, [zoom, resetToken, camera, invalidate])
  // Zoom toward the finger or cursor so a zoomed stone stays in frame, and allow
  // a near-overhead orbit so the table (top view) of a centre stone can be seen.
  return <OrbitControls ref={controls} makeDefault enablePan={false} zoomToCursor enableDamping dampingFactor={0.07}
    minDistance={CAMERA_MIN_DISTANCE} maxDistance={CAMERA_MAX_DISTANCE * (cameraPreset === 'gemstone' ? GEMSTONE_LENS_RATIO : 1)}
    minPolarAngle={Math.PI * CAMERA_MIN_POLAR} maxPolarAngle={Math.PI * 0.85}
    onStart={() => onInteractionChange?.(true)} onEnd={() => onInteractionChange?.(false)} />
}
