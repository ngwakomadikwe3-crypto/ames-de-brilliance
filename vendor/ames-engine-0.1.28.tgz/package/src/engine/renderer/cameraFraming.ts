import { DIAMOND_CALIBRATION } from '../calibration'
export type CameraPreset = 'front' | 'three_quarter' | 'side' | 'setting' | 'gemstone'
export const GEMSTONE_CAMERA_FOV = 24
export const GEMSTONE_LENS_RATIO = Math.tan(DIAMOND_CALIBRATION.camera.fov * Math.PI / 360) / Math.tan(GEMSTONE_CAMERA_FOV * Math.PI / 360)
export const CAMERA_MIN_DISTANCE = 2.5
export const CAMERA_MAX_DISTANCE = 8
/** Smallest polar angle as a fraction of PI: about 4 degrees from straight overhead. */
export const CAMERA_MIN_POLAR = 0.022
export const CAMERA_BASE_DISTANCE = Math.hypot(...DIAMOND_CALIBRATION.camera.position)
export function cameraFraming(preset: CameraPreset, zoom = 1) {
  const angles = { front: [0, 75], three_quarter: [35, 40], side: [90, 75], setting: [35, 35], gemstone: [30, 35] }
  const [theta, phi] = angles[preset] ?? angles.three_quarter
  const factor = Number.isFinite(zoom) && zoom > 0 ? zoom : 1
  const lens = preset === 'gemstone' ? GEMSTONE_LENS_RATIO : 1
  const minPolar = Math.PI * CAMERA_MIN_POLAR
  return { theta: theta * Math.PI / 180, phi: Math.max(minPolar, Math.min(Math.PI * 0.85, phi * Math.PI / 180)), radius: Math.max(CAMERA_MIN_DISTANCE, Math.min(CAMERA_MAX_DISTANCE * lens, CAMERA_BASE_DISTANCE * lens / factor)) }
}
