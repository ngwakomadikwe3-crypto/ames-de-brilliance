import { CubeTexture, SRGBColorSpace } from 'three'
import { JEWELRY_OPTICS_PROFILES } from './opticsProfiles'
import type { JewelryOpticsProfile } from './opticsProfiles'

/**
 * Studio environment for real jewelry gems and metal.
 *
 * A diamond's body is the environment it reflects and refracts. Phase 2.5 used
 * hard-edged pure-white cards on near-black, which read as graphic black/white
 * facets and a busy pave. This version keeps the dark luxury surround but uses
 * large *soft-edged* off-white softboxes for smooth optical transitions, a few
 * tight crisp highlights for controlled sparkle, and soft dark flags for
 * contrast that does not clip to black.
 */
export const DIAMOND_DISPLAY_ENVIRONMENT = Object.freeze({
  size: 512,
  base: Object.freeze({ top: '#20262e', mid: '#0d1015', bottom: '#06070a' }),
  cards: Object.freeze([
    // Broad soft softboxes: clean white brilliance with gradual falloff.
    Object.freeze({ face: 0, x: 60, y: 20, width: 360, height: 470, color: '#eef1f5', blur: 34 }),
    Object.freeze({ face: 1, x: 100, y: 40, width: 300, height: 420, color: '#f6f8fb', blur: 34 }),
    Object.freeze({ face: 2, x: 50, y: 110, width: 400, height: 260, color: '#e9edf3', blur: 34 }),
    Object.freeze({ face: 3, x: 80, y: 240, width: 340, height: 220, color: '#fff0dc', blur: 30 }),
    Object.freeze({ face: 4, x: 110, y: 30, width: 290, height: 450, color: '#f2f5f9', blur: 34 }),
    Object.freeze({ face: 5, x: 80, y: 70, width: 320, height: 370, color: '#e6eeff', blur: 30 }),
    // Tight specular strips: controlled, photogenic sparkle without noise.
    Object.freeze({ face: 0, x: 250, y: 120, width: 44, height: 240, color: '#ffffff', blur: 6 }),
    Object.freeze({ face: 2, x: 210, y: 60, width: 120, height: 40, color: '#ffffff', blur: 6 }),
    Object.freeze({ face: 4, x: 150, y: 150, width: 40, height: 260, color: '#ffffff', blur: 6 }),
    Object.freeze({ face: 5, x: 180, y: 200, width: 150, height: 34, color: '#ffffff', blur: 6 }),
    // Soft dark flags: facet contrast without hard black posterization.
    Object.freeze({ face: 1, x: 16, y: 70, width: 90, height: 360, color: '#0b0d11', blur: 26 }),
    Object.freeze({ face: 3, x: 24, y: 40, width: 110, height: 160, color: '#0b0d11', blur: 26 }),
  ]),
})

interface EnvironmentCard {
  face: number
  x: number
  y: number
  width: number
  height: number
  color: string
  blur?: number
}

function paintFace(context: CanvasRenderingContext2D, index: number, opticsProfile: JewelryOpticsProfile) {
  const { size, cards } = DIAMOND_DISPLAY_ENVIRONMENT
  const { base, darkFlag } = JEWELRY_OPTICS_PROFILES[opticsProfile].environment
  const gradient = context.createLinearGradient(0, 0, 0, size)
  gradient.addColorStop(0, base.top)
  gradient.addColorStop(0.55, base.mid)
  gradient.addColorStop(1, base.bottom)
  context.fillStyle = gradient
  context.fillRect(0, 0, size, size)

  const gemstoneCards: readonly EnvironmentCard[] = [
    { face: 0, x: 34, y: 30, width: 156, height: 410, color: '#f8fbff', blur: 14 },
    { face: 0, x: 214, y: 90, width: 28, height: 290, color: '#ffffff', blur: 3 },
    { face: 1, x: 300, y: 56, width: 100, height: 330, color: '#dfe9f2', blur: 18 },
    { face: 2, x: 100, y: 44, width: 300, height: 105, color: '#ffffff', blur: 12 },
    { face: 2, x: 220, y: 196, width: 112, height: 28, color: '#ffffff', blur: 2 },
    { face: 3, x: 74, y: 270, width: 190, height: 130, color: '#ffe9cf', blur: 18 },
    { face: 4, x: 260, y: 28, width: 160, height: 410, color: '#f5f8ff', blur: 14 },
    { face: 4, x: 188, y: 148, width: 26, height: 240, color: '#ffffff', blur: 3 },
    { face: 5, x: 62, y: 90, width: 115, height: 300, color: '#dceaff', blur: 16 },
  ]
  const activeCards = opticsProfile === 'gemstone-studio' ? gemstoneCards : cards as readonly EnvironmentCard[]
  for (const card of activeCards) {
    if (card.face !== index) continue
    context.save()
    context.filter = card.blur ? `blur(${card.blur}px)` : 'none'
    context.fillStyle = card.color === '#0b0d11' ? darkFlag : card.color
    context.fillRect(card.x, card.y, card.width, card.height)
    context.restore()
  }
}

export function createDiamondDisplayEnvironment(opticsProfile: JewelryOpticsProfile = 'reference') {
  const { size } = DIAMOND_DISPLAY_ENVIRONMENT
  const texture = new CubeTexture(
    Array.from({ length: 6 }, (_, index) => {
      const canvas = document.createElement('canvas')
      canvas.width = size
      canvas.height = size
      paintFace(canvas.getContext('2d')!, index, opticsProfile)
      return canvas
    }),
  )
  texture.colorSpace = SRGBColorSpace
  texture.needsUpdate = true
  return texture
}
