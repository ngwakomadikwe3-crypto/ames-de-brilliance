import { useEffect, useRef } from 'react'
import type { RefObject } from 'react'
import type { Group } from 'three'
// Match the host Chat turntable: 4 degrees/s, immediate drag pause, delayed ramped resume.
export const CONTROLLED_TURN_SPEED = 4 * Math.PI / 180
export const CONTROLLED_RESUME_DELAY = 1800
export function useControlledTurntable(pivot: RefObject<Group | null>, enabled: boolean, ready: boolean, interacting: boolean, resetToken: number | undefined, invalidate: () => void) {
  const resumeAt = useRef(0)
  const wasEnabled = useRef(enabled)
  useEffect(() => {
    if (pivot.current) pivot.current.rotation.y = 0
    resumeAt.current = performance.now()
    invalidate()
  }, [pivot, resetToken, invalidate])
  useEffect(() => {
    if (enabled && !wasEnabled.current) resumeAt.current = performance.now()
    wasEnabled.current = enabled
    if (interacting) resumeAt.current = Infinity
    else if (resumeAt.current === Infinity) resumeAt.current = performance.now() + CONTROLLED_RESUME_DELAY
    if (!enabled || !ready || interacting) return
    let frame = 0
    let timer: ReturnType<typeof setTimeout> | undefined
    let last = performance.now()
    const tick = (now: number) => {
      const delta = Math.max(0, Math.min(0.05, (now - last) / 1000))
      last = now
      const ramp = Math.min(1, Math.max(0, (now - resumeAt.current) / 1000))
      if (pivot.current) pivot.current.rotation.y = (pivot.current.rotation.y + CONTROLLED_TURN_SPEED * delta * ramp) % (Math.PI * 2)
      invalidate()
      frame = requestAnimationFrame(tick)
    }
    const start = () => { last = performance.now(); frame = requestAnimationFrame(tick) }
    const delay = resumeAt.current - performance.now()
    if (delay > 0) timer = setTimeout(start, delay)
    else start()
    return () => { cancelAnimationFrame(frame); if (timer !== undefined) clearTimeout(timer) }
  }, [pivot, enabled, ready, interacting, resetToken, invalidate])
}
