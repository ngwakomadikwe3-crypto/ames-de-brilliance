import {useEffect,useState} from 'react'
import {useThree} from '@react-three/fiber'
import {CubeTextureLoader,LinearMipmapLinearFilter,SRGBColorSpace} from 'three'
import type {CubeTexture} from 'three'

interface StudioMaps {surface:CubeTexture;refraction:CubeTexture}
let shared:Promise<StudioMaps>|undefined
function loadStudio(){
  if(!shared){
    const base='/ames-engine/environments/gemstone-softbox-v2/'
    const faces=['px','nx','py','ny','pz','nz']
    shared=Promise.all([
      new CubeTextureLoader().loadAsync(faces.map(face=>base+face+'-display.webp')),
      new CubeTextureLoader().loadAsync(faces.map(face=>base+face+'-radiance.png')),
    ]).then(([surface,refraction])=>{
      surface.colorSpace=SRGBColorSpace
      refraction.colorSpace=SRGBColorSpace
      refraction.generateMipmaps=true
      refraction.minFilter=LinearMipmapLinearFilter
      refraction.userData.rgbmRange=8 // Fixed opaque multiplier, not interpolated RGBM alpha.
      refraction.userData.fixedRangeRadiance=true
      surface.needsUpdate=true;refraction.needsUpdate=true
      return {surface,refraction}
    }).catch(error=>{shared=undefined;throw error})
  }
  return shared
}
/** RGBA8 only: no half-float filtering, framebuffer transmission, or external requests. */
export function useGemstoneSoftboxEnvironment(enabled:boolean):StudioMaps|null{
  const canvas=useThree(state=>state.gl.domElement)
  const [maps,setMaps]=useState<StudioMaps|null>(null)
  useEffect(()=>{if(!enabled)return;let active=true;loadStudio().then(value=>{if(active)setMaps(value)}).catch(()=>{});return()=>{active=false}},[enabled])
  useEffect(()=>{if(!enabled)return;canvas.dataset.studioEnvironment=maps?'softbox-v2':'generated-fallback';return()=>{delete canvas.dataset.studioEnvironment}},[canvas,enabled,maps])
  return enabled?maps:null
}
