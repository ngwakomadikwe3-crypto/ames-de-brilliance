import {useEffect,useMemo} from 'react'
import {useThree} from '@react-three/fiber'
import {Matrix4,ShaderMaterial,Vector3} from 'three'
import type {BufferGeometry,Texture} from 'three'

/** Bounded visual approximation of a translucent cabochon and moving blue layer sheen.
 * Not a thin-layer diffraction solver or a claim about a physical gemstone.
 */
export function MoonstoneMaterial({envMap,geometry,baseFraction=.2}:{envMap:Texture;geometry:BufferGeometry;baseFraction?:number}){
  const invalidate=useThree(state=>state.invalidate)
  const material=useMemo(()=>{
    geometry.computeBoundingBox()
    const bounds=geometry.boundingBox!,center=bounds.getCenter(new Vector3()),size=bounds.getSize(new Vector3())
    const value=new ShaderMaterial({
      uniforms:{envMap:{value:envMap},radianceRange:{value:Number(envMap.userData.rgbmRange??1)},baseLimit:{value:-baseFraction/(1-baseFraction)},
        localToWorld:{value:new Matrix4()},worldToLocal:{value:new Matrix4()},center:{value:new Vector3(center.x,bounds.min.y+size.y*baseFraction,center.z)},inverseSize:{value:new Vector3(2/size.x,1/(size.y*(1-baseFraction)),2/size.z)}},
      vertexShader:`
        varying vec3 worldPoint;varying vec3 worldNormal;varying vec3 localPoint;varying vec3 localNormal;
        void main(){
          localPoint=position;localNormal=normal;
          worldPoint=(modelMatrix*vec4(position,1.0)).xyz;
          worldNormal=normalize(vec3(vec4(normalize(normalMatrix*normal),0.0)*viewMatrix));
          gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.0);
        }`,
      fragmentShader:`
        uniform samplerCube envMap;uniform float radianceRange;uniform float baseLimit;
        uniform mat4 localToWorld;uniform mat4 worldToLocal;uniform vec3 center;uniform vec3 inverseSize;
        varying vec3 worldPoint;varying vec3 worldNormal;varying vec3 localPoint;varying vec3 localNormal;
        vec3 light(vec3 d){return textureCube(envMap,normalize(d)).rgb*radianceRange;}
        float hash(vec3 p){return fract(sin(dot(p,vec3(127.1,311.7,74.7)))*43758.5453);}
        float cloud(vec3 p){
          vec3 i=floor(p),f=fract(p);f=f*f*(3.0-2.0*f);
          return mix(mix(mix(hash(i),hash(i+vec3(1,0,0)),f.x),mix(hash(i+vec3(0,1,0)),hash(i+vec3(1,1,0)),f.x),f.y),
            mix(mix(hash(i+vec3(0,0,1)),hash(i+vec3(1,0,1)),f.x),mix(hash(i+vec3(0,1,1)),hash(i+vec3(1,1,1)),f.x),f.y),f.z);
        }
        bool exitDome(vec3 origin,vec3 direction,out vec3 hitPoint,out vec3 hitNormal){
          vec3 q=(origin-center)*inverseSize,d=direction*inverseSize;
          float nearest=1.0e8;
          float a=dot(d,d),b=dot(q,d),c=dot(q,q)-1.0,disc=b*b-a*c;
          if(disc>0.0){
            float t=(-b+sqrt(disc))/a;vec3 h=q+d*t;
            if(t>0.00001&&h.y>=0.0){nearest=t;hitNormal=normalize(h*inverseSize);}
          }
          a=dot(d.xz,d.xz);b=dot(q.xz,d.xz);c=dot(q.xz,q.xz)-1.0;disc=b*b-a*c;
          if(a>.000001&&disc>0.0){
            float t=(-b+sqrt(disc))/a;vec3 h=q+d*t;
            if(t>0.00001&&t<nearest&&h.y<=0.0&&h.y>=baseLimit){nearest=t;hitNormal=normalize(vec3(h.x*inverseSize.x,0.0,h.z*inverseSize.z));}
          }
          if(d.y<-.000001){
            float t=(baseLimit-q.y)/d.y;vec3 h=q+d*t;
            if(t>0.00001&&t<nearest&&dot(h.xz,h.xz)<=1.0001){nearest=t;hitNormal=vec3(0,-1,0);}
          }
          hitPoint=origin+direction*nearest;
          return nearest<1.0e7;
        }
        vec3 localLight(vec3 d){
          vec3 w=normalize(mat3(localToWorld)*d);
          vec3 result=vec3(.32,.34,.35)*(.8+.2*max(w.y,0.0));
          result+=vec3(9.0)*pow(max(dot(w,normalize(vec3(.25,1.5,1.0))),0.0),65.0);
          result+=vec3(.9,1.1,1.35)*pow(max(dot(w,normalize(vec3(-1,.3,-.8))),0.0),24.0);
          result+=vec3(3.0)*pow(max(dot(w,normalize(vec3(1,.15,.1))),0.0),35.0);
          return result;
        }
        void main(){
          vec3 V=normalize((worldToLocal*vec4(cameraPosition,1.0)).xyz-localPoint);
          vec3 N=normalize(localNormal);
          float facing=clamp(dot(N,V),0.0,1.0);
          float fresnel=.044+.956*pow(1.0-facing,5.0);
          vec3 p=(localPoint-center)*inverseSize;
          vec3 ray=refract(-V,N,1.0/1.52);
          float epsilon=.00008/inverseSize.y;
          vec3 origin=localPoint+ray*epsilon;
          vec3 throughput=vec3(1),interior=vec3(0);
          for(int bounce=0;bounce<4;bounce++){
            vec3 point,normal;
            if(!exitDome(origin,ray,point,normal)){interior+=throughput*localLight(ray);break;}
            float distance=length((point-origin)*inverseSize);
            float mist=cloud((point+origin)*inverseSize*2.0)*.65+cloud((point+origin)*inverseSize*4.0)*.35;
            throughput*=exp(-vec3(.18,.12,.08)*distance*(.75+.5*mist));
            interior+=throughput*vec3(.16,.17,.18)*(1.0-exp(-distance*.6));
            vec3 transmitted=refract(ray,-normal,1.52);
            if(dot(transmitted,transmitted)>.00001){
              float reflection=.044+.956*pow(1.0-clamp(dot(ray,normal),0.0,1.0),5.0);
              interior+=throughput*(1.0-reflection)*localLight(transmitted);
              throughput*=reflection;
            }
            ray=reflect(ray,normal);origin=point+ray*epsilon;
          }
          vec2 sheenCenter=clamp(V.xz*.6,vec2(-.45),vec2(.45));
          vec2 offset=p.xz-sheenCenter;
          float billow=exp(-dot(offset*vec2(1.3,.9),offset*vec2(1.3,.9))*2.8);
          vec3 layer=normalize(vec3(.18,1,.22));
          vec3 key=normalize((worldToLocal*vec4(normalize(vec3(-.8,1.1,1.4)),0.0)).xyz);
          float alignment=pow(max(dot(reflect(-V,layer),key),0.0),3.0);
          float sheen=billow*(.55+.45*alignment)*pow(facing,.5);
          interior+=vec3(.015,.10,.32)*sheen;
          vec3 result=mix(interior,localLight(reflect(-V,N)),fresnel);
          result+=vec3(.075,.08,.085)*pow(max(dot(N,key),0.0),1.5);
          gl_FragColor=vec4(result,1.0);
          #include <tonemapping_fragment>
          #include <colorspace_fragment>
        }`,toneMapped:true,
    })
    value.name='AMES moonstone translucent layer study'
    value.onBeforeRender=(_renderer,_scene,_camera,_geometry,object)=>{
      value.uniforms.localToWorld.value.copy(object.matrixWorld)
      value.uniforms.worldToLocal.value.copy(object.matrixWorld).invert()
      value.uniformsNeedUpdate=true
    }
    return value
  },[envMap,geometry,baseFraction])
  useEffect(()=>{invalidate();return()=>material.dispose()},[material,invalidate])
  return <primitive object={material} attach="material" />
}
