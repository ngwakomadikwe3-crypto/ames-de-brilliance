import { useEffect, useMemo } from 'react'
import { useThree } from '@react-three/fiber'
import { Matrix4, ShaderMaterial } from 'three'
import type { Color, Texture } from 'three'
import type { ConvexGemVolume } from './convexGemVolume'

/** Trace a bounded convex faceted volume without BVH textures, recursion or traversal stacks. */
export function GemstoneFacetMaterial({ envMap, color, ior, volume, bounces = 5, refining = true, colorDepth = 0.9, bodyFill = 0.012 }: {
  envMap: Texture; color: Color; ior: number; volume: ConvexGemVolume; bounces?: number; refining?: boolean; colorDepth?: number; bodyFill?: number
}) {
  const invalidate = useThree(state => state.invalidate)
  const traceBudget = volume.planes.length > 80 && bounces <= 4 ? 4 : 6
  const material = useMemo(() => {
    const value = new ShaderMaterial({
      defines: { FACET_COUNT: volume.planes.length, BOUNCE_COUNT: traceBudget },
      uniforms: {
        envMap: { value: envMap }, radianceRange: { value: Number(envMap.userData.rgbmRange ?? 0) }, photographicHDR: { value: envMap.userData.photographicHDR ? 1 : 0 }, colorDepth: { value: colorDepth }, bodyFill: { value: bodyFill }, bodyColor: { value: color }, ior: { value: ior },
        facetCount: { value: volume.planes.length }, facets: { value: volume.planes }, diameter: { value: volume.diameter }, detailSamples: { value: 1 }, traceBounces: { value: Math.min(traceBudget, bounces) },
        worldToLocal: { value: new Matrix4() }, localToWorld: { value: new Matrix4() },
      },
      vertexShader: `
        varying vec3 localPosition;
        varying vec3 localNormal;
        void main() {
          localPosition = position;
          localNormal = normal;
          gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
        }`,
      fragmentShader: `
        uniform samplerCube envMap;
        uniform float radianceRange;
        uniform float photographicHDR;
        uniform float colorDepth;
        uniform float bodyFill;
        uniform vec3 bodyColor;
        uniform float ior;
        uniform vec4 facets[FACET_COUNT];
        uniform int facetCount;
        uniform float diameter;
        uniform float detailSamples;
        uniform int traceBounces;
        uniform mat4 worldToLocal;
        uniform mat4 localToWorld;
        varying vec3 localPosition;
        varying vec3 localNormal;
        vec3 environmentDx;
        vec3 environmentDy;
        vec3 environment(vec3 direction) {
          vec4 packedLight = textureCubeGradEXT(envMap, normalize(mat3(localToWorld) * direction), environmentDx, environmentDy);
          if (photographicHDR > 0.5) return packedLight.rgb;
          if (radianceRange > 0.0) return packedLight.rgb * packedLight.a * radianceRange;
          vec3 light = packedLight.rgb;
          // Display-light reconstruction gives softboxes radiance above the room fill
          // without requiring float render targets or HDR texture extensions on mobile.
          float luminance = dot(light, vec3(0.2126, 0.7152, 0.0722));
          return light * (1.0 + 8.0 * pow(luminance, 8.0));
        }
        vec3 shadeGem(vec3 point, vec3 normal, vec3 localCamera) {
          vec3 incident = normalize(point - localCamera);
          vec3 surface = environment(reflect(incident, normal));
          vec3 ray = refract(incident, normal, 1.0 / ior);
          float epsilon = diameter * 0.00003;
          vec3 origin = point + ray * epsilon;
          vec3 throughput = vec3(1.0);
          vec3 interior = vec3(0.0);
          for (int bounce = 0; bounce < BOUNCE_COUNT; bounce++) {
            if (bounce >= traceBounces) break;
            float nearest = diameter * 100.0;
            vec3 exitNormal = normal;
            bool hit = false;
            for (int facet = 0; facet < facetCount; facet++) {
              vec3 n = facets[facet].xyz;
              float denominator = dot(n, ray);
              if (denominator > 0.000001) {
                float distanceToFacet = (facets[facet].w - dot(n, origin)) / denominator;
                if (distanceToFacet > epsilon * 0.1 && distanceToFacet < nearest) {
                  nearest = distanceToFacet; exitNormal = n; hit = true;
                }
              }
            }
            if (!hit) { interior += throughput * environment(ray); throughput = vec3(0.0); break; }
            throughput *= pow(max(bodyColor, vec3(0.002)), vec3(nearest / diameter * colorDepth));
            vec3 boundary = origin + ray * nearest;
            vec3 transmitted = refract(ray, -exitNormal, ior);
            if (dot(transmitted, transmitted) > 0.00001) {
              float interfaceF0 = pow((ior - 1.0) / (ior + 1.0), 2.0);
              float interfaceFresnel = interfaceF0 + (1.0 - interfaceF0) * pow(1.0 - clamp(dot(ray, exitNormal), 0.0, 1.0), 5.0);
              interior += throughput * (1.0 - interfaceFresnel) * environment(transmitted);
              throughput *= interfaceFresnel;
            }
            ray = reflect(ray, exitNormal);
            origin = boundary + ray * epsilon;

          }
          // Preserve bounded residual energy, including paths still under total
          // internal reflection when the mobile bounce budget is exhausted.
          interior += throughput * environment(ray) * 0.25 + bodyColor * bodyFill;
          float f0 = pow((ior - 1.0) / (ior + 1.0), 2.0);
          float fresnel = f0 + (1.0 - f0) * pow(1.0 - clamp(dot(-incident, normal), 0.0, 1.0), 5.0);
          return mix(interior, surface, fresnel);
        }
        void main() {
          vec3 localCamera = (worldToLocal * vec4(cameraPosition, 1.0)).xyz;
          // Derivatives of traced exit directions jump at facet boundaries. Use
          // the smooth camera ray for mip selection so triangulation cannot create
          // dotted seams or wash out internal reflections.
          vec3 cameraRay = normalize(mat3(localToWorld) * (localPosition - localCamera));
          environmentDx = dFdx(cameraRay) * 1.25;
          environmentDy = dFdy(cameraRay) * 1.25;
          // Canonicalise flat facet normals to suppress interpolation precision seams.
          vec3 normal = normalize(floor(localNormal * 100000.0 + 0.5) / 100000.0);
          vec3 offset = (dFdx(localPosition) + dFdy(localPosition)) * 0.22;
          vec3 result;
          if (detailSamples > 1.5) {
            result = (shadeGem(localPosition - offset, normal, localCamera)
              + shadeGem(localPosition + offset, normal, localCamera)) * 0.5;
          } else {
            result = shadeGem(localPosition, normal, localCamera);
          }
          gl_FragColor = vec4(result, 1.0);
          #include <tonemapping_fragment>
          #include <colorspace_fragment>
        }`,
      toneMapped: true,
    })
    value.name = 'AMES convex facet volume'
    value.onBeforeRender = (_renderer, _scene, _camera, _geometry, object) => {
      value.uniforms.localToWorld.value.copy(object.matrixWorld)
      value.uniforms.worldToLocal.value.copy(object.matrixWorld).invert()
      value.uniformsNeedUpdate = true
    }
    return value
  }, [envMap, color, ior, volume, bounces, traceBudget, colorDepth, bodyFill])
  useEffect(() => () => material.dispose(), [material])
  useEffect(() => {
    material.uniforms.detailSamples.value = 1
    material.uniforms.traceBounces.value = Math.min(traceBudget,bounces)
    invalidate()
    if (!refining) return
    const timer = setTimeout(() => { material.uniforms.detailSamples.value = 2; material.uniforms.traceBounces.value = traceBudget; invalidate() }, 500)
    return () => clearTimeout(timer)
  }, [material, refining, bounces, traceBudget, invalidate])
  return <primitive object={material} attach="material" />
}
