import { useEffect, useMemo } from 'react'
import { ShaderMaterial } from 'three'
import type { Color, Texture } from 'three'

/** Bounded mobile approximation: environment refraction and surface reflection,
 * without BVH traversal, screen-space transmission or shader loops. */
export function GemstonePreviewMaterial({ envMap, color, ior }: { envMap: Texture; color: Color; ior: number }) {
  const material = useMemo(() => new ShaderMaterial({
    uniforms: { envMap: { value: envMap }, bodyColor: { value: color }, ior: { value: ior } },
    vertexShader: `
      varying vec3 worldPosition;
      varying vec3 worldNormal;
      void main() {
        vec4 positionWorld = modelMatrix * vec4(position, 1.0);
        worldPosition = positionWorld.xyz;
        worldNormal = normalize(mat3(modelMatrix) * normal);
        gl_Position = projectionMatrix * viewMatrix * positionWorld;
      }`,
    fragmentShader: `
      uniform samplerCube envMap;
      uniform vec3 bodyColor;
      uniform float ior;
      varying vec3 worldPosition;
      varying vec3 worldNormal;
      void main() {
        vec3 incident = normalize(worldPosition - cameraPosition);
        vec3 normalWorld = normalize(worldNormal);
        vec3 reflectedDirection = reflect(incident, normalWorld);
        vec3 transmittedDirection = refract(incident, normalWorld, 1.0 / ior);
        vec3 surface = textureCube(envMap, reflectedDirection).rgb;
        // The second environment sample approximates pavilion light return.
        // This is a display approximation, not geometry-traced internal optics.
        vec3 interior = mix(textureCube(envMap, transmittedDirection).rgb,
          textureCube(envMap, reflect(transmittedDirection, vec3(0.0, 1.0, 0.0))).rgb, 0.4);
        float f0 = pow((ior - 1.0) / (ior + 1.0), 2.0);
        float fresnel = f0 + (1.0 - f0) * pow(1.0 - clamp(dot(-incident, normalWorld), 0.0, 1.0), 5.0);
        gl_FragColor = vec4(mix(interior * bodyColor, surface, fresnel), 1.0);
        #include <tonemapping_fragment>
        #include <colorspace_fragment>
      }`,
    toneMapped: true,
  }), [envMap, color, ior])
  useEffect(() => () => material.dispose(), [material])
  return <primitive object={material} attach="material" />
}
