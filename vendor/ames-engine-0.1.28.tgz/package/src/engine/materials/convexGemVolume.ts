import { Vector3, Vector4, BufferGeometry, Float32BufferAttribute } from 'three'
export interface ConvexGemVolume { planes: Vector4[]; diameter: number }
/** Facet half-spaces in mesh-local coordinates. Reject unsupported/non-convex meshes. */
export function convexGemVolume(geometry: BufferGeometry): ConvexGemVolume | null {
  const position = geometry.getAttribute('position'), index = geometry.index
  if (!position || position.count < 4 || position.count > 4000) return null
  const points = Array.from({ length: position.count }, (_, i) => new Vector3().fromBufferAttribute(position, i))
  const center = points.reduce((sum, p) => sum.add(p), new Vector3()).divideScalar(points.length)
  geometry.computeBoundingBox()
  const diameter = geometry.boundingBox!.getSize(new Vector3()).length()
  if (!Number.isFinite(diameter) || diameter < 1e-8) return null
  const tolerance = diameter * 2e-5, planes: Vector4[] = []
  const edges = new Map<string, number>()
  const pointKey = (p: Vector3) => [p.x, p.y, p.z].map(v => Math.round(v / (diameter * 1e-6))).join(',')
  for (let i = 0; i < (index?.count ?? position.count); i += 3) {
    const [a, b, c] = [0, 1, 2].map(offset => points[index ? index.getX(i + offset) : i + offset])
    if (!a || !b || !c) return null
    const normal = b.clone().sub(a).cross(c.clone().sub(a))
    if (normal.lengthSq() < tolerance ** 4) continue
    for (const [start, end] of [[a, b], [b, c], [c, a]]) {
      const edge = [pointKey(start), pointKey(end)].sort().join('|')
      edges.set(edge, (edges.get(edge) ?? 0) + 1)
    }
    normal.normalize()
    if (normal.dot(a.clone().sub(center)) < 0) normal.negate()
    const distance = normal.dot(a)
    if (planes.some(p => normal.x * p.x + normal.y * p.y + normal.z * p.z > 1 - 1e-6 && Math.abs(p.w - distance) < tolerance)) continue
    if (points.some(point => normal.dot(point) > distance + tolerance)) return null
    planes.push(new Vector4(normal.x, normal.y, normal.z, distance))
    if (planes.length > 144) return null
  }
  if ([...edges.values()].some(count => count !== 2)) return null
  return planes.length >= 4 ? { planes, diameter } : null
}

/** Material primitives may partition one closed gem; combine only in the same local frame. */
export function convexGemAssemblyVolume(geometries: BufferGeometry[]): ConvexGemVolume | null {
  if (!geometries.length || geometries.length > 8) return null
  const positions: number[] = []
  for (const geometry of geometries) {
    const position = geometry.getAttribute('position'), index = geometry.index
    if (!position || (positions.length / 3 + (index?.count ?? position.count)) > 4000) return null
    for (let i = 0; i < (index?.count ?? position.count); i++) {
      const v = index ? index.getX(i) : i
      positions.push(position.getX(v), position.getY(v), position.getZ(v))
    }
  }
  const merged = new BufferGeometry().setAttribute('position', new Float32BufferAttribute(positions, 3))
  const volume = convexGemVolume(merged)
  merged.dispose()
  return volume
}
