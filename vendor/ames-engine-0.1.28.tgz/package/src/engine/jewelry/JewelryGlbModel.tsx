import { MoonstoneMaterial } from '../materials/MoonstoneMaterial'
import { createPortal, useFrame, useThree } from '@react-three/fiber'
import { useGLTF, MeshRefractionMaterial } from '@react-three/drei'
import { useEffect, useMemo, useRef } from 'react'
import { Box3, Color, Group, Mesh, Vector3 } from 'three'
import type { BufferGeometry, Matrix4, MeshPhysicalMaterial, Texture } from 'three'
import {
  applyJewelryMaterials,
  gemQualityForGeometry,
  isPureGemMesh,
  isQualifiedDielectricMesh,
  JEWELRY_DIAMOND_OPTICS,
  mobileGemProfile,
} from './jewelryGlbMaterials'
import type { GemQualityProfile } from './jewelryGlbMaterials'
import { RoundBrilliantGem } from './RoundBrilliantGem'
import { convexGemVolume, convexGemAssemblyVolume } from '../materials/convexGemVolume'
import type { ConvexGemVolume } from '../materials/convexGemVolume'
import { GemstoneFacetMaterial } from '../materials/GemstoneFacetMaterial'
import { GemstonePreviewMaterial } from '../materials/GemstonePreviewMaterial'
import { MountedCenterDiamondMaterial } from '../materials/MountedCenterDiamondMaterial'
import type { ViewerQualityProfile } from '../renderer/viewerQuality'
import type { JewelryOpticsProfile } from '../renderer/opticsProfiles'

const STUDIO_BODY_COLORS: Record<string, string> = {
  'stone-ruby': '#d71d42', 'stone-emerald': '#15945e',
  'stone-sapphire': '#4268cc', 'stone-garnet': '#b52339',
  'stone-amethyst': '#a879cd', 'stone-tanzanite': '#6f71c4', 'stone-iolite': '#7c79b5',
  'stone-aquamarine': '#91cedf', 'stone-topaz': '#79c6df', 'stone-kunzite': '#dfa6ca',
}

/** Approved mounted production asset for the live dev viewer. */
export const DEFAULT_JEWELRY_GLB_URL = '/models/mounted-reference-ring.glb'

/** Longest-axis fit size in world units, matched to the calibrated camera framing. */
export const JEWELRY_FIT_SIZE = 2.6

/** Idle turntable angular speed in radians per second. */
export const JEWELRY_TURNTABLE_SPEED = 0.18

/** How quickly the turntable eases in after interaction (higher = quicker). */
const TURNTABLE_EASE = 2.5

interface ExtractedGem {
  key: string
  geometry: BufferGeometry
  matrix: Matrix4
  profile: GemQualityProfile
  color: Color
  ior: number
  aberrationStrength: number
  volume: ConvexGemVolume | null
  colorDepth: number
  bodyFill: number
}

interface ExtractedCenterStone {
  key: string
  matrix: Matrix4
}

/**
 * The legacy prepared asset exposes its unsuitable centre stone as the
 * `Diamond` node with the `dmesh` geometry. The approved mounted reference
 * asset keeps its imported centre stone and bypasses this replacement path.
 */
const CENTER_STONE_NODE = 'diamond'
const CENTER_STONE_GEOMETRY = 'dmesh'

function isCenterStoneMesh(mesh: Mesh): boolean {
  const nodeName = (mesh.name ?? '').trim().toLowerCase()
  if (nodeName === CENTER_STONE_NODE) return true
  const geometryName = (mesh.geometry?.name ?? '').trim().toLowerCase()
  return geometryName === CENTER_STONE_GEOMETRY
}

export function isReferenceDiamond001Mesh(mesh: Mesh): boolean {
  const metadata = mesh.userData as {
    ames_asset_id?: unknown
    ames_role?: unknown
    ames_part_id?: unknown
    ames_source_binding?: unknown
  }
  return metadata.ames_asset_id === 'reference-diamond-001'
    && metadata.ames_role === 'center'
    && metadata.ames_part_id === 'C00'
    && metadata.ames_source_binding === 'center-stone'
}

function findReferenceDiamond001Mesh(root: Group): Mesh | undefined {
  let center: Mesh | undefined
  root.traverse((object) => {
    if (!center && object instanceof Mesh && isReferenceDiamond001Mesh(object)) center = object
  })
  return center
}

function collectGemMeshes(root: Group, includeBicolor = false): Mesh[] {
  const gems: Mesh[] = []
  root.traverse((object) => {
    const mesh = object as Mesh
    const bicolor = includeBicolor && mesh instanceof Mesh && mesh.parent?.userData.ames_gemstone_id === 'stone-ametrine' && [3, 4].includes(Number(mesh.parent?.userData.ames_cut_revision))
    if (bicolor || (isQualifiedDielectricMesh(mesh) && isPureGemMesh(mesh))) gems.push(mesh)
  })
  return gems
}

/**
 * Generic real-jewelry GLB model.
 *
 * Preserves the loaded node and material hierarchy and only adds a
 * centering/scaling wrapper so an arbitrary catalog asset fits the calibrated
 * camera. Geometry is never rewritten. Gem meshes are lifted out of the clone
 * and rendered with the ray-marched refraction material (real internal
 * reflections and facet contrast); metal keeps a physically based material.
 *
 * A smooth idle turntable spins the fitted model around its vertical axis and
 * eases to a stop while `interactionRef` is true, then eases back in.
 */
export function JewelryGlbModel({
  url,
  envMap,
  gemEnvMap,
  fit = JEWELRY_FIT_SIZE,
  turntable = true,
  refining = true,
  interactionRef,
  quality,
  onReady,
  opticsProfile = 'reference',
}: {
  url: string
  envMap?: Texture | null
  gemEnvMap?: Texture | null
  fit?: number
  turntable?: boolean
  refining?: boolean
  /** Set to true while the user is dragging so the turntable eases to a stop. */
  interactionRef?: { current: boolean }
  quality: ViewerQualityProfile
  onReady?: () => void
  opticsProfile?: JewelryOpticsProfile
}) {
  const { scene } = useGLTF(url)
  const maxUniforms = useThree(state => state.gl.capabilities.maxFragmentUniforms)
  const spin = useRef(0)
  const pivot = useRef<Group>(null)

  const invalidate = useThree(state => state.invalidate)
  useEffect(() => {
    // SAFE renders on demand. Let the committed model draw before the host
    // removes its poster; invalidate schedules R3F's frame before our callback.
    let frame = requestAnimationFrame(() => {
      invalidate()
      frame = requestAnimationFrame(() => onReady?.())
    })
    return () => cancelAnimationFrame(frame)
  }, [invalidate, onReady, scene])

  const { root, gems, centerStones, scale, materials, mountedCenter, moonstones } = useMemo(() => {
    const root = scene.clone(true)

    const box = new Box3().setFromObject(root)
    const size = box.getSize(new Vector3())
    const center = box.getCenter(new Vector3())
    const scale = fit / Math.max(size.x, size.y, size.z, 0.001)
    root.position.sub(center)
    root.updateMatrixWorld(true)

    // Capture gem transforms in pivot space, then lift them out of the metal hierarchy.
    // Without an environment the ray-marched path is unavailable, so gems stay in
    // the hierarchy and receive the physical fallback material instead.
    const gemMeshes = envMap ? collectGemMeshes(root, (opticsProfile === 'gemstone-studio' || opticsProfile === 'mounted-gem-studio')) : []
    const bicolorMeshes = gemMeshes.filter(mesh => mesh.parent?.userData.ames_gemstone_id === 'stone-ametrine')
    const sameFrame = bicolorMeshes.every(mesh => mesh.matrixWorld.elements.every((value, i) => Math.abs(value - bicolorMeshes[0].matrixWorld.elements[i]) < 1e-7))
    const bicolorVolume = sameFrame && bicolorMeshes.length > 1 ? convexGemAssemblyVolume(bicolorMeshes.map(mesh => mesh.geometry)) : null
    const mountedCenter = findReferenceDiamond001Mesh(root)
    const preserveImportedCenterStone = Boolean(mountedCenter)
    const centerMeshes = preserveImportedCenterStone ? [] : gemMeshes.filter(isCenterStoneMesh)
    const extractedGemMeshes = preserveImportedCenterStone
      ? gemMeshes.filter((mesh) => mesh !== mountedCenter)
      : gemMeshes
    const gems: ExtractedGem[] = extractedGemMeshes
      .map((mesh, index) => {
        const source = (Array.isArray(mesh.material) ? mesh.material[0] : mesh.material) as MeshPhysicalMaterial | undefined
        const gemId = String(mesh.userData?.ames_gemstone_id ?? mesh.parent?.userData.ames_gemstone_id ?? '')
        const dispersive = gemId.includes('diamond') || gemId === 'stone-zircon' || !gemId
        return {
          key: `${mesh.name || 'gem'}-${index}`,
          geometry: mesh.geometry,
          matrix: mesh.matrixWorld.clone(),
          profile: gemQualityForGeometry(mesh.geometry),
          color: (opticsProfile === 'gemstone-studio' || opticsProfile === 'mounted-gem-studio') && STUDIO_BODY_COLORS[gemId]
            ? new Color(STUDIO_BODY_COLORS[gemId]) : source?.color?.clone() ?? new Color(0xffffff),
          bodyFill: gemId === 'stone-diamond' ? 0.004 : 0.012,
          colorDepth: ({ 'stone-ruby': 1.1, 'stone-sapphire': .9, 'stone-emerald': 1.1, 'stone-garnet': 1.6 } as Record<string, number>)[gemId] ?? .65,
          volume: (() => {
            const volume = (opticsProfile === 'gemstone-studio' || opticsProfile === 'mounted-gem-studio') ? (gemId === 'stone-ametrine' ? bicolorVolume : convexGemVolume(mesh.geometry)) : null
            return volume && volume.planes.length + 24 <= maxUniforms ? volume : null
          })(),
          ior: source?.ior || JEWELRY_DIAMOND_OPTICS.ior,
          aberrationStrength: dispersive ? JEWELRY_DIAMOND_OPTICS.aberrationStrength : JEWELRY_DIAMOND_OPTICS.aberrationStrength * 0.3,
        }
      })
    const centerStones: ExtractedCenterStone[] = centerMeshes.map((mesh, index) => ({
      key: `${mesh.name || 'center-stone'}-${index}`,
      matrix: mesh.matrixWorld.clone(),
    }))
    for (const mesh of extractedGemMeshes) mesh.parent?.remove(mesh)

    const moonstones: {key:string;geometry:BufferGeometry;matrix:Matrix4;baseFraction:number}[] = []
    const moonstoneMeshes: Mesh[] = []
    if((opticsProfile === 'gemstone-studio' || opticsProfile === 'mounted-gem-studio'))root.traverse(object=>{
      if(object instanceof Mesh && object.userData?.ames_gemstone_id === 'stone-moonstone')moonstoneMeshes.push(object)
    })
    for(const mesh of moonstoneMeshes){
      moonstones.push({key:mesh.uuid,geometry:mesh.geometry,matrix:mesh.matrixWorld.clone(),baseFraction:Number(mesh.userData.ames_cabochon_base_fraction??.2)})
      mesh.parent?.remove(mesh)
    }

    const assignment = applyJewelryMaterials(root, envMap, {
      preserveMesh: mountedCenter ? (mesh) => mesh === mountedCenter : undefined,
      opticsProfile,
    })
    return { root, gems, centerStones, scale, materials: assignment.materials, mountedCenter, moonstones }
  }, [scene, envMap, fit, url, opticsProfile, maxUniforms])

  useEffect(() => () => {
    for (const material of materials) material.dispose()
  }, [materials])

  useEffect(() => () => {
    useGLTF.clear(url)
  }, [url])

  useFrame((_, delta) => {
    const interacting = interactionRef?.current === true
    const target = turntable && !interacting ? JEWELRY_TURNTABLE_SPEED : 0
    spin.current += (target - spin.current) * Math.min(1, delta * TURNTABLE_EASE)
    if (pivot.current) pivot.current.rotation.y += spin.current * delta
  })

  return (
    <group ref={pivot}>
      <group scale={scale}>
        <primitive object={root} />
        {mountedCenter && envMap ? createPortal(<MountedCenterDiamondMaterial quality={quality} center={mountedCenter} opticsProfile={opticsProfile} />, mountedCenter) : null}
        {envMap ? centerStones.map((stone) => (
          <RoundBrilliantGem
            key={stone.key}
            envMap={envMap}
            matrix={stone.matrix}
            constrained={quality.tier !== 'HIGH'}
          />
        )) : null}
        {envMap ? moonstones.map(gem=><mesh key={gem.key} geometry={gem.geometry} dispose={null} matrixAutoUpdate={false}
          ref={mesh=>{if(mesh){mesh.matrix.copy(gem.matrix);mesh.matrixWorldNeedsUpdate=true}}}>
          <MoonstoneMaterial envMap={gemEnvMap ?? envMap} geometry={gem.geometry} baseFraction={gem.baseFraction} />
        </mesh>) : null}
        {envMap ? gems.map((gem) => {
          const gemQuality = quality.tier === 'HIGH' ? gem.profile : mobileGemProfile(gem.profile)
          return (
            <mesh
              key={gem.key}
              geometry={gem.geometry}
              dispose={null}
              matrixAutoUpdate={false}
              ref={(mesh) => {
                if (!mesh) return
                mesh.matrix.copy(gem.matrix)
                mesh.matrixWorldNeedsUpdate = true
              }}
            >
              {gem.volume ? <GemstoneFacetMaterial envMap={gemEnvMap ?? envMap} color={gem.color} ior={gem.ior} volume={gem.volume} colorDepth={gem.colorDepth} bodyFill={gem.bodyFill} refining={refining} bounces={quality.tier === 'SAFE' || quality.tier === 'LOW' ? 4 : 6} /> : (opticsProfile === 'gemstone-studio' || opticsProfile === 'mounted-gem-studio') ? <GemstonePreviewMaterial envMap={envMap} color={gem.color} ior={gem.ior} /> : quality.refraction ? <MeshRefractionMaterial
                envMap={envMap}
                ior={gem.ior}
                fresnel={gemQuality.fresnel}
                aberrationStrength={quality.tier === 'IOS_LOW' || quality.tier === 'LOW' ? 0 : gem.aberrationStrength}
                fastChroma={JEWELRY_DIAMOND_OPTICS.fastChroma}
                bounces={Math.min(gemQuality.bounces, quality.gemBounces)}
                color={gem.color}
                toneMapped
              /> : <meshPhysicalMaterial
                envMap={envMap}
                color={gem.color}
                roughness={0.025}
                metalness={0}
                transmission={0.88}
                thickness={0.8}
                ior={gem.ior}
                clearcoat={0.25}
                clearcoatRoughness={0.08}
                envMapIntensity={1.8}
                toneMapped
              />}
            </mesh>
          )
        }) : null}
      </group>
    </group>
  )
}


