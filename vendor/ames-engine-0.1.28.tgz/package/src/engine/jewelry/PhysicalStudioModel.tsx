import { useGLTF } from '@react-three/drei'
import { useThree } from '@react-three/fiber'
import { useEffect, useMemo, useRef, useState } from 'react'
import { AddEquation, Box3, CustomBlending, OneFactor, ZeroFactor, BoxGeometry, BufferAttribute, BufferGeometry, Group, HalfFloatType, Matrix4, Mesh, WebGLRenderTarget, MeshBasicMaterial, MeshPhysicalMaterial, Plane, Quaternion, Raycaster, Vector2, Vector3 } from 'three'
import type { Material, Object3D } from 'three'
import { applyJewelryMaterials, isQualifiedDielectricMesh } from './jewelryGlbMaterials'
import { createStudioBrilliantGeometry } from './createStudioBrilliantGeometry'
import { createPaveFromLayout } from './createPaveFromLayout'
import { createPhysicalStudioGem } from '../materials/PhysicalStudioGem'
import { CAMERA_MIN_DISTANCE } from '../renderer/cameraFraming'
import type { OrbitControls as OrbitControlsImpl } from 'three-stdlib'
import { useControlledTurntable } from '../renderer/useControlledTurntable'
import { StudioStage } from '../renderer/StudioStage'
import { STAR_LAYER } from '../renderer/StudioBloom'
import type { PhysicalStudio } from '../renderer/usePhysicalStudio'

/** Plain float copy of a geometry. Compressed GLBs (meshopt, KHR_mesh_quantization) load
 * interleaved and normalised-integer attributes, which the gem BVH textures cannot read. */
function plainGeometry(source: BufferGeometry){
  const geometry=new BufferGeometry()
  for(const [name,attribute] of Object.entries(source.attributes)){
    const {count,itemSize}=attribute, array=new Float32Array(count*itemSize)
    for(let i=0;i<count;i++)for(let k=0;k<itemSize;k++)array[i*itemSize+k]=attribute.getComponent(i,k)
    geometry.setAttribute(name,new BufferAttribute(array,itemSize))
  }
  if(source.index)geometry.setIndex(Array.from(source.index.array as ArrayLike<number>))
  geometry.userData={...source.userData};return geometry
}

type StudioCut = 'round'|'oval'|'pear'|'cushion'|'radiant'
/** lay 'hang': laid flat facing the viewer with the drops hanging down (necklaces), else lying on the table (bracelets). */
type BraceletInfo = { links: number; pitch: number; length_mm: number; width_mm: number; clasp?: string; stones?: number; stone?: string; kind?: string; lay?: string; drop_mm?: number }
const STUDIO_CUTS = new Set<StudioCut>(['round','oval','pear','cushion','radiant'])
const BRILLIANT_IDS = new Set(['stone-diamond','stone-fancy-color-diamond','stone-ruby','stone-sapphire','stone-morganite','stone-alexandrite','stone-spinel','stone-garnet','stone-zircon','stone-peridot'])

const METAL_STRIP_INTENSITY=1,METAL_STRIP_ROUGHNESS=.06
/** Hand polish: a real polished surface is not perfectly even. Very fine polishing lines and soft patches make the
 * highlight a touch less glassy in places (roughness varies by about a third), fixed to the piece as it turns. */
function handPolish(material:MeshPhysicalMaterial){
  material.onBeforeCompile=shader=>{
    shader.vertexShader=shader.vertexShader.replace('#include <common>','#include <common>\nvarying vec3 vAmesPos;').replace('#include <begin_vertex>','#include <begin_vertex>\nvAmesPos=position;')
    shader.fragmentShader=shader.fragmentShader.replace('#include <common>',`#include <common>
varying vec3 vAmesPos;
float amesHash(vec3 p){p=fract(p*.3183099+.1);p*=17.;return fract(p.x*p.y*p.z*(p.x+p.y+p.z));}
float amesNoise(vec3 x){vec3 i=floor(x),f=fract(x);f=f*f*(3.-2.*f);
  return mix(mix(mix(amesHash(i),amesHash(i+vec3(1,0,0)),f.x),mix(amesHash(i+vec3(0,1,0)),amesHash(i+vec3(1,1,0)),f.x),f.y),
             mix(mix(amesHash(i+vec3(0,0,1)),amesHash(i+vec3(1,0,1)),f.x),mix(amesHash(i+vec3(0,1,1)),amesHash(i+vec3(1,1,1)),f.x),f.y),f.z);}`)
      .replace('#include <roughnessmap_fragment>',`#include <roughnessmap_fragment>
{vec3 q=vAmesPos;float patches=amesNoise(q*.35),lines=amesNoise(vec3(q.x*.25,q.y*9.,q.z*.25));
 roughnessFactor=clamp(roughnessFactor*(.78+.32*patches+.18*lines),.03,1.);}`)
  }
  material.customProgramCacheKey=()=>'ames-hand-polish'
  material.needsUpdate=true
}
export function PhysicalStudioModel({url, studio, enabled, interacting, resetToken, onReady}: {
  url: string; studio: PhysicalStudio; enabled: boolean; interacting: boolean; resetToken?: number; onReady?: () => void
}) {
  const {scene} = useGLTF(url)
  const {gl, invalidate, camera, scene: stageScene} = useThree()
  const controls = useThree(state => state.controls) as unknown as OrbitControlsImpl | null
  const pivot = useRef<Group>(null)
  const built = useMemo(() => {
    const root=scene.clone(true), geometries: BufferGeometry[]=[], materials: Material[]=[], diagnostics: object[]=[]
    const bounds=new Box3().setFromObject(root), scale=2.6/Math.max(...bounds.getSize(new Vector3()).toArray())
    root.position.sub(bounds.getCenter(new Vector3())); root.updateMatrixWorld(true)
    const gems: Mesh[]=[], cutCache=new Map<StudioCut, BufferGeometry>()
    // Watch hand pivots sit on the dial centre; they are turned to local time below.
    const hands: {object: Object3D; kind: string}[]=[]
    root.traverse(object=>{const kind=object.userData.ames_watch_hand;if(kind==='hour'||kind==='minute'||kind==='second')hands.push({object,kind})})
    // A bracelet built link by link (ames_link = place in the flat line from the clasp) can be unclasped and laid flat.
    let bracelet: BraceletInfo | null = null
    const links: {object: Object3D; order: number; p: Vector3; q: Quaternion}[]=[]
    root.traverse(object=>{const info=object.userData.ames_bracelet;if(info&&typeof info.pitch==='number')bracelet=info as BraceletInfo
      const order=object.userData.ames_link;if(typeof order==='number')links.push({object,order,p:object.position.clone(),q:object.quaternion.clone()})})
    // Hinged parts (earring drops): a node tagged ames_dangle swings about its own origin, the hinge.
    const dangles: {object: Object3D; rest: Quaternion; hang: Vector3; length: number}[]=[]
    root.traverse(object=>{if(!object.userData.ames_dangle||object===root)return
      const box=new Box3();object.updateMatrixWorld(true)
      const toLocal=new Matrix4().copy(object.matrixWorld).invert()
      object.traverse(child=>{if(child instanceof Mesh){child.geometry.computeBoundingBox();box.union(child.geometry.boundingBox!.clone().applyMatrix4(new Matrix4().multiplyMatrices(toLocal,child.matrixWorld)))}})
      if(box.isEmpty())return
      const centre=box.getCenter(new Vector3()),length=centre.length()
      if(length>1e-6)dangles.push({object,rest:object.quaternion.clone(),hang:centre.clone().applyQuaternion(object.quaternion).normalize(),length})})
    // Opening parts (a case lid): ames_open {axis (local), angle (deg)} swings the node about its own origin, the hinge.
    const opens: {object: Object3D; rest: Quaternion; axis: Vector3; angle: number}[]=[]; let openLabel=''
    // Clasp parts (a fold-over clasp's blade): swing open on their hinge as a bracelet starts to unclasp, shut as it closes.
    const claspParts: {object: Object3D; rest: Quaternion; axis: Vector3; angle: number}[]=[]
    root.traverse(object=>{const o=object.userData.ames_clasp_part;if(o&&Array.isArray(o.axis)&&typeof o.angle==='number')claspParts.push({object,rest:object.quaternion.clone(),axis:new Vector3(...o.axis).normalize(),angle:o.angle*Math.PI/180})})
    root.traverse(object=>{const o=object.userData.ames_open;if(!o||!Array.isArray(o.axis)||typeof o.angle!=='number')return
      opens.push({object,rest:object.quaternion.clone(),axis:new Vector3(...o.axis).normalize(),angle:o.angle*Math.PI/180});openLabel||=String(o.label??'')})
    root.traverse(object=>{if(object instanceof Mesh && isQualifiedDielectricMesh(object))gems.push(object)})
    const assignment=applyJewelryMaterials(root,studio.environment,{preserveMesh:mesh=>gems.includes(mesh),opticsProfile:'mounted-gem-studio'})
    materials.push(...assignment.materials)
    // Polished metal reflects the strip-light room, so it reads like a photographed piece rather than chrome.
    for(const m of assignment.materials){const p=m as MeshPhysicalMaterial;if(p.isMeshPhysicalMaterial&&p.metalness>=.9&&!p.transmission){p.envMap=studio.metal;p.envMapIntensity=METAL_STRIP_INTENSITY;p.roughness=Math.max(p.roughness,METAL_STRIP_ROUGHNESS);handPolish(p)}}
    // Watch glass: a clear crystal (anti-reflective coated, so faint) adds only its reflections (Fresnel-weighted, strongest at a glancing angle) over the
    // dial, so the dial reads as being under glass. It adds light only (its alpha is left alone, which the studio's
    // glow pass reads), so it never darkens, hides or washes out what is below.
    root.traverse(object=>{const m=object as Mesh;if(!m.isMesh||!(m.userData.ames_glass||m.parent?.userData.ames_glass))return
      const glass=new MeshPhysicalMaterial({name:'AMES watch glass',color:0x000000,metalness:0,roughness:.03,envMap:studio.metal,envMapIntensity:.32,
        transparent:true,blending:CustomBlending,blendEquation:AddEquation,blendSrc:OneFactor,blendDst:OneFactor,blendSrcAlpha:ZeroFactor,blendDstAlpha:OneFactor,depthWrite:false,specularIntensity:1,ior:1.77})
      m.material=glass;m.renderOrder=2;materials.push(glass)})
    for(const mesh of gems) {
      const source=(Array.isArray(mesh.material)?mesh.material[0]:mesh.material) as MeshPhysicalMaterial
      const id=String(mesh.userData.ames_gemstone_id ?? mesh.parent?.userData.ames_gemstone_id ?? 'stone-diamond')
      // AMES pavé ships as a layout of melee rather than a mesh: rebuild the stones here.
      const layout=mesh.userData.ames_pave_layout
      if(typeof layout==='string'){mesh.updateMatrix();const pave=createPaveFromLayout(layout,mesh.matrix.clone().invert());mesh.geometry=pave;geometries.push(pave)}
      // Replace only AMES-authored representative cuts. Uploaded jeweller geometry is retained.
      // An AMES-authored piece may name each stone's cut in its node extras (ames_cut).
      const authoredCut=String(mesh.userData.ames_cut ?? '') as StudioCut
      if(BRILLIANT_IDS.has(id) && (STUDIO_CUTS.has(authoredCut) || /\/(stone-[a-z-]+|demo-pave-solitaire)\//.test(url))) {
        mesh.geometry.computeBoundingBox();const old=mesh.geometry.boundingBox!, size=old.getSize(new Vector3()),center=old.getCenter(new Vector3())
        const outline: StudioCut = STUDIO_CUTS.has(authoredCut) ? authoredCut : id==='stone-morganite' ? 'pear' : id==='stone-fancy-color-diamond' ? 'radiant' : ['stone-garnet','stone-spinel'].includes(id) ? 'cushion' : ['stone-sapphire','stone-alexandrite','stone-peridot'].includes(id) ? 'oval' : 'round'
        // Pavé repeats one cut many times: build each outline once per model.
        if(!cutCache.has(outline)){const cut=createStudioBrilliantGeometry(outline);cutCache.set(outline,cut);geometries.push(cut)}
        const geometry=cutCache.get(outline)!.clone();geometry.computeBoundingBox()
        const own=geometry.boundingBox!, ownSize=own.getSize(new Vector3()),ownCenter=own.getCenter(new Vector3())
        geometry.translate(-ownCenter.x,-ownCenter.y,-ownCenter.z)
        geometry.scale(size.x/ownSize.x,size.y/ownSize.y,size.z/ownSize.z)
        geometry.translate(center.x,center.y,center.z);mesh.geometry=geometry;geometries.push(geometry)
      }
      // GPU intersection tolerances operate in geometry-local coordinates. Authoring
      // units can be metres or millimetres: normalise each stone before building its
      // BVH, then preserve its exact placement with the inverse mesh transform.
      mesh.geometry.computeBoundingBox()
      const opticalBounds=mesh.geometry.boundingBox!, opticalCenter=opticalBounds.getCenter(new Vector3())
      const opticalScale=opticalBounds.getSize(new Vector3()).length()
      if(!Number.isFinite(opticalScale)||opticalScale<=0)throw Error('Invalid gemstone volume.')
      const normalised=plainGeometry(mesh.geometry)
      normalised.translate(-opticalCenter.x,-opticalCenter.y,-opticalCenter.z)
      normalised.scale(1/opticalScale,1/opticalScale,1/opticalScale)
      mesh.geometry=normalised;geometries.push(normalised)
      mesh.updateMatrix()
      mesh.matrix.multiply(new Matrix4().makeTranslation(opticalCenter)).multiply(new Matrix4().makeScale(opticalScale,opticalScale,opticalScale))
      mesh.matrix.decompose(mesh.position,mesh.quaternion,mesh.scale);mesh.updateMatrixWorld(true)
      const worldScale=scale * mesh.getWorldScale(new Vector3()).y
      mesh.geometry.computeBoundingBox()
      // Merged pavé (ames_pave) is many melee in one volume: trace it with the small-stone budget.
      const small=mesh.userData.ames_pave===true || mesh.geometry.boundingBox!.getSize(new Vector3()).length()*worldScale<.2
      // Diamonds see the high-contrast studio (black cards between bright strips): their sparkle is that contrast.
      const material=createPhysicalStudioGem(mesh.geometry,id,source,id.includes('diamond')?studio.diamond:studio.environment,studio.radiance,worldScale,small)
      mesh.material=material;materials.push(material);mesh.layers.enable(STAR_LAYER)
      diagnostics.push({id,type:material.type,ior:material.ior,transmission:material.transmission,roughness:material.roughness,
        color:material.color.getHexString(),attenuationColor:material.attenuationColor.getHexString(),attenuationDistance:material.attenuationDistance,
        thickness:material.thickness,dispersion:material.dispersion,triangles:(mesh.geometry.index?.count??mesh.geometry.getAttribute('position').count)/3,
        cut:mesh.geometry.userData.cut??'imported',...mesh.geometry.userData})
    }
    // Ruler under the flat bracelet: a bar the bracelet's length with centimetre ticks, and its width across one end (mm, piece frame).
    let ruler: Group | null = null
    const info = bracelet as BraceletInfo | null
    if(info && links.length===info.links && links[0].object.parent){
      ruler=new Group();ruler.name='AMES bracelet ruler';ruler.visible=false
      const ink=new MeshBasicMaterial({color:'#dceee8',transparent:true,opacity:0,depthWrite:false});materials.push(ink)
      const bar=(x:number,y:number,z:number,sx:number,sy:number,sz:number)=>{const g=new BoxGeometry(sx,sy,sz);geometries.push(g);const m=new Mesh(g,ink);m.position.set(x,y,z);ruler!.add(m)}
      const L=info.length_mm
      if(info.lay==='hang'){
        // Hanging flat, facing the viewer: the scale runs under the drops, the drop length up the left end.
        const drop=info.drop_mm??info.width_mm,yLine=-(drop+info.width_mm/2+3.2)
        bar(0,yLine,0,L,.22,.22)
        for(let mm=0;mm<=L+.01;mm+=10)bar(mm-L/2,yLine,0,.22,mm%50===0?2.4:1.4,.22)
        bar(L/2,yLine,0,.22,2.4,.22)
        const x=-L/2-2.2,top=info.width_mm/2,low=-(drop+info.width_mm/2)
        bar(x,(top+low)/2,0,.22,top-low,.22);bar(x,top,0,.9,.22,.22);bar(x,low,0,.9,.22,.22)
      }else{
        const zLine=info.width_mm/2+3.2,y=-2.4
        bar(0,y,zLine,L,.22,.22)
        for(let mm=0;mm<=L+.01;mm+=10)bar(mm-L/2,y,zLine,.22,.22,mm%50===0?2.4:1.4)
        bar(L/2,y,zLine,.22,.22,2.4)
        bar(-L/2-2.2,y,0,.22,.22,info.width_mm);bar(-L/2-2.2,y,info.width_mm/2,.9,.22,.22);bar(-L/2-2.2,y,-info.width_mm/2,.9,.22,.22)
      }
      links[0].object.parent.add(ruler)
    }
    const span=bounds.getSize(new Vector3()).toArray().reduce((a,b)=>Math.max(a,b),0)*1000
    return {root,size:bounds.getSize(new Vector3()),scale,materials,geometries,diagnostics,hands,links,bracelet:info,ruler,span,dangles,opens,openLabel,claspParts}
  },[scene,studio,url])
  useEffect(()=>()=>{built.materials.forEach(m=>m.dispose());built.geometries.forEach(g=>g.dispose())},[built])
  useEffect(()=>{
    gl.domElement.dataset.gemMaterials=JSON.stringify(built.diagnostics)
    // Compile the piece's shaders before showing it, in the background where the browser allows
    // (KHR_parallel_shader_compile), so the page never freezes on the first frame. Compiled as the studio pass
    // draws them (into a half-float target, untoned), so the first real frame finds them ready.
    let alive=true,frame=0
    built.root.visible=false
    const target=new WebGLRenderTarget(1,1,{type:HalfFloatType}),prior=gl.getRenderTarget()
    let ready: Promise<unknown>
    try{gl.setRenderTarget(target);ready=gl.compileAsync(built.root,camera,stageScene)}catch{ready=Promise.resolve()}finally{gl.setRenderTarget(prior)}
    ready.catch(()=>{}).then(()=>{if(!alive)return;built.root.visible=true;invalidate()
      frame=requestAnimationFrame(()=>{invalidate();frame=requestAnimationFrame(()=>onReady?.())})})
    return()=>{alive=false;cancelAnimationFrame(frame);target.dispose();built.root.visible=true;delete gl.domElement.dataset.gemMaterials}
  },[built,gl,invalidate,onReady,camera,stageScene])
  // A watch keeps the viewer's local time: hour and minute glide, the seconds hand sweeps
  // in eight beats a second like an automatic movement.
  useEffect(()=>{
    if(!built.hands.length)return
    const tick=()=>{
      const now=new Date(),seconds=now.getSeconds()+now.getMilliseconds()/1000,minutes=now.getMinutes()+seconds/60,hours=now.getHours()%12+minutes/60
      for(const {object,kind} of built.hands){
        const turns=kind==='hour'?hours/12:kind==='minute'?minutes/60:Math.floor(seconds*8)/8/60
        object.rotation.set(0,0,-turns*Math.PI*2)
      }
      invalidate()
    }
    tick();const timer=setInterval(tick,125)
    return()=>clearInterval(timer)
  },[built,invalidate])
  // Bracelet: the host page sends 'ames:bracelet' {flat} to the canvas; the links unroll from the clasp into a
  // straight line (and back), the view zooms out to fit, and the ruler fades in. The page reads data-ames-bracelet.
  const flatProgress=useRef(0),reapply=useRef<(()=>void)|null>(null)
  const [folding,setFolding]=useState(false)
  // Reset puts a folded piece back as it was (closed, or laid flat).
  useEffect(()=>{reapply.current?.();invalidate()},[resetToken,invalidate])
  useEffect(()=>{
    const info=built.bracelet,links=built.links
    if(!info||links.length!==info.links)return
    const el=gl.domElement
    el.dataset.amesBracelet=JSON.stringify({...info,clasp:info.clasp??''})
    el.dataset.amesBraceletState='closed'
    // Hanging: each link turned so its table faces the viewer (+z) and its drop side (local -z) points down;
    // that mirrors the chain direction, so the line runs right to left.
    const hang=info.lay==='hang',half=(info.links-1)/2
    const flatQ=hang?new Quaternion().setFromRotationMatrix(new Matrix4().makeBasis(new Vector3(-1,0,0),new Vector3(0,0,1),new Vector3(0,1,0))):new Quaternion()
    // A link may say where it lies in the flat line (ames_flat_x, mm: a watch head is wider than a link).
    const flatP=links.map(l=>{const at=l.object.userData.ames_flat_x;return new Vector3((hang?-1:1)*(typeof at==='number'?at:(l.order-half)*info.pitch),0,0)})
    const flatScale=Math.min(1,built.span*1.5/(info.length_mm+16)),ease=(t:number)=>t*t*(3-2*t),closeIn=Math.max(.08,flatScale*.35)
    let frame=0,turnFrom=0,turnTo=0,saved:{t:Vector3;c:Vector3}|null=null
    // Unclasping moves the bracelet as the linked chain it is: every link keeps hold of its neighbour, and each
    // hinge eases from its closed bend to straight, the ends by the clasp first, so the two halves swing open
    // from the case (a watch) or the middle link (a bracelet). Nothing slides through anything on the way.
    const chainOrder=links.map((_,i)=>i).sort((a,b)=>links[a].order-links[b].order)
    const headAt=links.findIndex(l=>/head/i.test(l.object.name))
    const rootAt=headAt>=0?chainOrder.indexOf(headAt):Math.floor(chainOrder.length/2),root=chainOrder[rootAt]
    const steps:{i:number;parent:number;hops:number;qc:Quaternion;pc:Vector3;qf:Quaternion;pf:Vector3}[]=[]
    const rel=(pp:Vector3,pq:Quaternion,cp:Vector3,cq:Quaternion)=>{const inv=pq.clone().invert();return {q:inv.clone().multiply(cq),p:cp.clone().sub(pp).applyQuaternion(inv)}}
    for(const dir of [1,-1])for(let k=rootAt+dir,hops=1;k>=0&&k<chainOrder.length;k+=dir,hops++){
      const i=chainOrder[k],parent=chainOrder[k-dir],c=rel(links[parent].p,links[parent].q,links[i].p,links[i].q),f=rel(flatP[parent],flatQ,flatP[i],flatQ)
      steps.push({i,parent,hops,qc:c.q,pc:c.p,qf:f.q,pf:f.p})}
    const reach=Math.max(1,...steps.map(x=>x.hops)),place=links.map(()=>({p:new Vector3(),q:new Quaternion()})),relQ=new Quaternion(),relP=new Vector3()
    const unroll=(q:number)=>{
      const e=ease(Math.min(1,Math.max(0,q))),r=links[root]
      place[root].p.lerpVectors(r.p,flatP[root],e);place[root].q.slerpQuaternions(r.q,flatQ,e)
      for(const x of steps){const t=ease(Math.min(1,Math.max(0,q*1.5-.5*(1-x.hops/reach)))),pa=place[x.parent]
        relQ.slerpQuaternions(x.qc,x.qf,t);relP.lerpVectors(x.pc,x.pf,t)
        place[x.i].q.copy(pa.q).multiply(relQ);place[x.i].p.copy(relP).applyQuaternion(pa.q).add(pa.p)}
      links.forEach((l,i)=>{l.object.position.copy(place[i].p);l.object.quaternion.copy(place[i].q)})
    }
    const apply=(p:number)=>{
      // With a clasp blade, it opens first (the first fifth), then the links unroll.
      const c=built.claspParts.length?.2:0,q=Math.max(0,(p-c)/(1-c)),open=ease(Math.min(1,p/(c||1)))
      for(const part of built.claspParts)part.object.quaternion.copy(part.rest).multiply(new Quaternion().setFromAxisAngle(part.axis,part.angle*(c?open:0)))
      unroll(q)
      if(pivot.current){pivot.current.scale.setScalar(built.scale*(1+(flatScale-1)*ease(p)));pivot.current.rotation.y=turnFrom+(turnTo-turnFrom)*ease(Math.min(1,p*1.4))}
      // The length is given in words beside the piece; a drawn ruler under it was one thing too many.
      if(built.ruler)built.ruler.visible=false
      el.dataset.amesBraceletState=p>=1?'flat':p<=0?'closed':'moving'
      // Laid flat, the piece is drawn smaller to fit; the view may then come in that much closer (and a bit more),
      // and slide along the line, so every link and stone can be looked at up close.
      if(controls){controls.minDistance=CAMERA_MIN_DISTANCE*(1+(closeIn-1)*ease(p));controls.enablePan=p>=1;controls.screenSpacePanning=true}
    }
    const animate=(target:number)=>{
      cancelAnimationFrame(frame)
      const from=flatProgress.current,start=performance.now(),duration=Math.max(1,1700*Math.abs(target-from))
      curl=0
      // Opening: turn the line square to the camera, so it reads left to right with the ruler in front.
      if(target>from&&from===0&&pivot.current){turnFrom=pivot.current.rotation.y%(Math.PI*2);turnTo=Math.atan2(camera.position.x,camera.position.z)
        while(turnTo-turnFrom>Math.PI)turnTo-=Math.PI*2;while(turnTo-turnFrom<-Math.PI)turnTo+=Math.PI*2}
      // Laying flat: the view centres on the line, so zooming lands on the piece. Closing: the view goes back to
      // where it was before, so the folded piece is framed as it was.
      const fromT=controls?.target.clone()??null,fromC=camera.position.clone();let toT:Vector3|null=null,toC:Vector3|null=null
      if(controls&&fromT){
        if(target>from){if(from===0)saved={t:fromT.clone(),c:fromC.clone()}
          apply(1);pivot.current?.updateMatrixWorld(true);const w=new Vector3();toT=new Vector3();links.forEach(l=>toT!.add(l.object.getWorldPosition(w)));toT.divideScalar(links.length||1);apply(from)
          toC=fromC.clone().add(toT).sub(fromT)}
        else if(target<from&&saved){toT=saved.t;toC=saved.c}
      }
      const step=(now:number)=>{const k=Math.min(1,(now-start)/duration);flatProgress.current=from+(target-from)*k
        apply(flatProgress.current)
        if(controls&&fromT&&toT&&toC){const e=ease(k);controls.target.lerpVectors(fromT,toT,e);camera.position.lerpVectors(fromC,toC,e);controls.update()}
        invalidate();if(k<1)frame=requestAnimationFrame(step)}
      frame=requestAnimationFrame(step)
    }
    const onMessage=(event:Event)=>animate((event as CustomEvent<{flat?:boolean}>).detail?.flat?1:0)
    el.addEventListener('ames:bracelet',onMessage)
    reapply.current=()=>apply(flatProgress.current)
    // Folding by hand: press a link and drag it; the chain follows link by link (each keeps its distance to its
    // neighbours, closed through the clasp unless it is unclasped), and stays where it is let go. The press is
    // caught before the orbit controls, so dragging anywhere else still turns the piece.
    const byOrder=links.map((_,i)=>i).sort((a,b)=>links[a].order-links[b].order),count=byOrder.length
    const raycaster=new Raycaster(),ndc=new Vector2(),plane=new Plane(),hit=new Vector3(),normal=new Vector3()
    let drag:{k:number;offset:Vector3;P:Vector3[];rest:{a:number;b:number;d:number}[];closed:boolean;id:number;goal:Vector3;cur:Vector3}|null=null
    let spacing=new Map<string,number>();const gap=(a:number,b:number)=>spacing.get(`${a}:${b}`)??info.pitch
    const bendDeg=typeof (info as {bend_deg?:number}).bend_deg==='number'?(info as {bend_deg?:number}).bend_deg!:info.kind==='watch'?20:info.kind==='necklace'?55:35,maxBend=bendDeg*Math.PI/180
    const owner=(o:Object3D|null)=>{for(;o;o=o.parent){if(o===built.ruler)return -1;const i=links.findIndex(l=>l.object===o);if(i>=0)return i}return -1}
    // A watch head (a link named "head") is held still while the strap folds, and is not itself picked up.
    const pinned=links.findIndex(l=>/head/i.test(l.object.name))
    // A watch bracelet is a row of links on pins: each joint turns only about its pin (the link's width axis), and
    // only one way, curling in toward the wrist; outward it barely gives. It never twists or kinks sideways, laid
    // flat or not. inward: which side of a link (its +y or -y) faces the wrist, read from the closed watch.
    const hinged=info.kind==='watch',outBend=3*Math.PI/180
    // The whole-bracelet curl of a watch laid flat (radians per joint): a few degrees back, about 20 in.
    let curl=0
    const CURL_MIN=-1.5*Math.PI/180,CURL_MAX=20*Math.PI/180,CURL_PER_PX=.12*Math.PI/180
    const curlTo=(angle:number)=>{
      if(pinned<0)return
      curl=Math.min(CURL_MAX,Math.max(CURL_MIN,angle))
      // Laid flat the strap runs along x (hanging lay), link width along y, the dial facing +z; curling in turns
      // each joint about y so the ends go back (-z). Walk out from the case on each side, joint by joint.
      const head=flatP[pinned],half=info.pitch/2,Q=new Quaternion(),Y=new Vector3(0,1,0)
      for(const s of [1,-1]){
        const side=links.map((_,i)=>i).filter(i=>i!==pinned&&(flatP[i].x-head.x)*s>0).sort((a,b)=>Math.abs(flatP[a].x-head.x)-Math.abs(flatP[b].x-head.x))
        let c=head.clone(),prevX=head.x,phi=0
        for(const i of side){
          const D=Math.abs(flatP[i].x-prevX),h=Math.min(half,D/2),dirOut=(a:number)=>new Vector3(s*Math.cos(a),0,-Math.sin(a))
          const joint=c.clone().addScaledVector(dirOut(phi),D-h);phi+=curl
          c=joint.addScaledVector(dirOut(phi),h);prevX=flatP[i].x
          links[i].object.position.copy(c);links[i].object.quaternion.copy(Q.setFromAxisAngle(Y,s*phi)).multiply(flatQ)
        }
      }
      invalidate()
    }
    let inward=-1
    if(hinged&&count>2){let sum=0;for(let j=0;j<count;j++){const a=links[byOrder[(j-1+count)%count]].p,b=links[byOrder[j]].p,c=links[byOrder[(j+1)%count]].p
      const u=b.clone().sub(a).normalize(),v=c.clone().sub(b).normalize(),y=new Vector3(0,1,0).applyQuaternion(links[byOrder[j]].object.quaternion);sum+=v.addScaledVector(u,-u.dot(v)).dot(y)}
      inward=sum>=0?1:-1}
    const point=(e:PointerEvent)=>{const r=el.getBoundingClientRect();ndc.set((e.clientX-r.left)/r.width*2-1,-((e.clientY-r.top)/r.height)*2+1);raycaster.setFromCamera(ndc,camera)}
    // The held link glides toward the finger (eased each frame) rather than jumping, and the chain settles after it.
    let glide=0
    const onMove=(e:PointerEvent)=>{
      if(!drag||e.pointerId!==drag.id)return
      point(e);if(!raycaster.ray.intersectPlane(plane,hit))return
      drag.goal.copy(links[drag.k].object.parent!.worldToLocal(hit.clone()).sub(drag.offset))
      if(!glide)glide=requestAnimationFrame(step)
    }
    const step=()=>{
      glide=0;const d=drag;if(!d)return
      d.cur.lerp(d.goal,.28);solveAt(d.cur)
      if(d.cur.distanceTo(d.goal)>.02)glide=requestAnimationFrame(step)
    }
    const solveAt=(target:Vector3)=>{
      const d=drag;if(!d)return
      const P=d.P
      P[d.k].copy(target)
      // FABRIK: each link follows the one before it at its own spacing, outward from the held link. A closed
      // piece is two chains from the held link that meet opposite it; they are relaxed toward each other.
      // Real links bend only at their hinges, a little each, and only in the chain's own plane (about each link's
      // width axis, local z): a watch strap rolls gently, a necklace is supple. bend_deg may set it per piece.
      const place=(prev:Vector3|null,a:Vector3,b:Vector3,link:number,length:number)=>{
        const v=b.clone().sub(a);if(v.lengthSq()<1e-12)return
        // Closed, the hinges curl the chain only in its own plane; laid flat, it may be lifted any way (still a little a link).
        const z=new Vector3(0,0,1).applyQuaternion(links[link].object.quaternion);if(d.closed||hinged)v.addScaledVector(z,-v.dot(z))
        if(v.lengthSq()<1e-12)v.copy(b).sub(a)
        v.normalize()
        // Next to the held link, bend from the held link's own line (its x axis, either way along the chain).
        if(!prev){const x=new Vector3(1,0,0).applyQuaternion(links[link].object.quaternion);prev=a.clone().addScaledVector(x,x.dot(v)>=0?-1:1)}
        {const u=a.clone().sub(prev).normalize(),c=u.dot(v)
          // A watch link curls in toward the wrist up to its limit, and outward only a few degrees.
          let limit=maxBend
          if(hinged){const y=new Vector3(0,1,0).applyQuaternion(links[link].object.quaternion),side=v.clone().addScaledVector(u,-c).dot(y)*inward;if(side<0)limit=outBend}
          if(c<Math.cos(limit)){const w=v.clone().addScaledVector(u,-c);if(w.lengthSq()<1e-12)w.copy(z).cross(u);w.normalize();v.copy(u).multiplyScalar(Math.cos(limit)).addScaledVector(w,Math.sin(limit))}}
        b.copy(a).addScaledVector(v,length)
      }
      const follow=(path:number[],from:number)=>{for(let i=from+1;i<path.length;i++)place(i>=2?P[path[i-2]]:null,P[path[i-1]],P[path[i]],path[i-1],gap(path[i-1],path[i]))}
      const back=(path:number[])=>{for(let i=path.length-2;i>=1;i--)place(i+2<path.length?P[path[i+2]]:null,P[path[i+1]],P[path[i]],path[i+1],gap(path[i+1],path[i]))}
      const j0=byOrder.indexOf(d.k)
      // A watch head stays where it is (as if held): the strap bends between it and the held link.
      // Each side is then a chain fixed at both ends; the held link cannot be pulled past the strap's reach.
      const fixed=(path:number[])=>{
        const pin=P[path[path.length-1]].clone(),held=P[d.k].clone();let reach=0;for(let i=1;i<path.length;i++)reach+=gap(path[i-1],path[i])
        return {pin,held,reach}
      }
      if(pinned>=0&&pinned!==d.k){
        const paths:number[][]=[]
        if(d.closed){const f:number[]=[],r:number[]=[];for(let i=0;i<count;i++){const x=byOrder[(j0+i)%count];f.push(x);if(x===pinned)break}
          for(let i=0;i<count;i++){const x=byOrder[(j0-i+count)%count];r.push(x);if(x===pinned)break};paths.push(f,r)}
        else{const f=byOrder.slice(j0),r=byOrder.slice(0,j0+1).reverse();for(const p of [f,r]){const m=p.indexOf(pinned);paths.push(m>=0?p.slice(0,m+1):p)}}
        const pinPos=P[pinned].clone()
        // Keep the held link within reach of the head.
        const reach=Math.min(...paths.filter(p=>p[p.length-1]===pinned).map(p=>fixed(p).reach))*.97
        if(Number.isFinite(reach)){const off=P[d.k].clone().sub(pinPos);if(off.length()>reach)P[d.k].copy(pinPos).addScaledVector(off.normalize(),reach)}
        const held=P[d.k].clone(),ends:Vector3[]=[]
        // The side(s) running to the head first, which settle where the held link can be; then the free end follows it.
        for(const p of paths){
          if(p[p.length-1]!==pinned)continue
          for(let it=0;it<10;it++){follow(p,0);P[pinned].copy(pinPos);back(p);P[d.k].copy(held)}
          // Finish from the head outward, the held link included: the strap stays whole and the held link sits
          // at its end, as near the finger as the hinges allow.
          P[pinned].copy(pinPos);back(p);P[d.k].copy(held);place(p.length>2?P[p[2]]:null,P[p[1]],P[p[0]],p[1],gap(p[1],p[0]));ends.push(P[d.k].clone())
        }
        // Closed round the head, both sides reach the held link: it sits between where each side ends.
        if(ends.length)P[d.k].copy(ends.reduce((acc,v)=>acc.add(v),new Vector3()).multiplyScalar(1/ends.length))
        for(const p of paths)if(p[p.length-1]!==pinned)follow(p,0)
      }else if(d.closed){
        const h=Math.floor(count/2),A=[...Array(h+1)].map((_,i)=>byOrder[(j0+i)%count]),B=[...Array(count-h+1)].map((_,i)=>byOrder[(j0-i+count)%count])
        const end=A[h],held=P[d.k].clone()
        for(let it=0;it<12;it++){
          const save=P[end].clone();follow(A,0);const ea=P[end].clone();P[end].copy(save);follow(B,0);const eb=P[end].clone()
          P[end].copy(ea).add(eb).multiplyScalar(.5);back(A);back(B);P[d.k].copy(held)
        }
        follow(A,0);const ea=P[end].clone();follow(B,0);P[end].add(ea).multiplyScalar(.5)
      }else{follow(byOrder.slice(j0),0);follow(byOrder.slice(0,j0+1).reverse(),0)}
      // Each link turns to follow the chain: its +x toward the next link.
      byOrder.forEach((i,j)=>{
        const prev=byOrder[d.closed?(j-1+count)%count:Math.max(0,j-1)],next=byOrder[d.closed?(j+1)%count:Math.min(count-1,j+1)]
        const t=P[next].clone().sub(P[prev]);const o=links[i].object;o.position.copy(P[i]);if(t.lengthSq()<1e-9)return
        o.quaternion.premultiply(new Quaternion().setFromUnitVectors(new Vector3(1,0,0).applyQuaternion(o.quaternion),t.normalize()))
      })
      invalidate()
    }
    const endDrag=()=>{cancelAnimationFrame(glide);glide=0;drag=null;setFolding(false);window.removeEventListener('pointermove',onMove);window.removeEventListener('pointerup',onUp);window.removeEventListener('pointercancel',onUp)}
    const onUp=(e:PointerEvent)=>{if(!drag||e.pointerId!==drag.id)return;endDrag()}
    const onDown=(e:PointerEvent)=>{
      if(drag||(e.pointerType==='mouse'&&e.button!==0))return
      // A second finger means pinch or slide: the view handles it, not the fold.
      if(e.pointerType==='touch'&&touches.size>1)return
      // A closed watch barely bends: dragging it turns it (the strap folds once it is unclasped).
      const p=flatProgress.current;if(p>0&&p<1)return;if(pinned>=0&&p===0)return
      point(e);const first=raycaster.intersectObject(built.root,true).find(h=>h.object.visible)
      let k=first?owner(first.object):-1,grab=first?.point.clone()
      // A fine chain is a few pixels wide: a press within about 28 px of a link also takes it.
      if(k<0){const r=el.getBoundingClientRect(),w=new Vector3();let best=28
        links.forEach((l,i)=>{if(i===pinned)return;l.object.getWorldPosition(w);const q=w.clone().project(camera);if(q.z>1)return
          const dx=(q.x-ndc.x)/2*r.width,dy=(q.y-ndc.y)/2*r.height,dd=Math.hypot(dx,dy);if(dd<best){best=dd;k=i;grab=w.clone()}})}
      // A watch laid flat curls as a whole, like a real bracelet: a drag down curls every joint in toward the wrist
      // by the same small amount, a drag up straightens it. The case stays put and no link can come away.
      // Only the strap curls: a press on the case turns the watch, as the view normally does.
      if(hinged&&hang&&pinned>=0&&p===1&&k>=0&&k!==pinned){
        e.stopPropagation();e.preventDefault()
        const y0=e.clientY,c0=curl,id=e.pointerId
        const move=(ev:PointerEvent)=>{if(ev.pointerId!==id)return;curlTo(c0+(ev.clientY-y0)*CURL_PER_PX)}
        const up=(ev:PointerEvent)=>{if(ev.pointerId!==id)return;setFolding(false);window.removeEventListener('pointermove',move);window.removeEventListener('pointerup',up);window.removeEventListener('pointercancel',up)}
        setFolding(true);window.addEventListener('pointermove',move);window.addEventListener('pointerup',up);window.addEventListener('pointercancel',up)
        return
      }
      if(k<0||!grab||k===pinned)return
      e.stopPropagation();e.preventDefault()
      camera.getWorldDirection(normal);plane.setFromNormalAndCoplanarPoint(normal,grab)
      const closed=p===0,base=closed?links.map(l=>l.p):flatP,rest=[]
      for(let j=0;j<count-(closed?0:1);j++){const a=byOrder[j],b=byOrder[(j+1)%count];rest.push({a,b,d:base[a].distanceTo(base[b])})}
      spacing=new Map(rest.flatMap(c=>[[`${c.a}:${c.b}`,c.d],[`${c.b}:${c.a}`,c.d]]))
      drag={k,offset:links[k].object.parent!.worldToLocal(grab.clone()).sub(links[k].object.position),P:links.map(l=>l.object.position.clone()),rest,closed,id:e.pointerId,goal:links[k].object.position.clone(),cur:links[k].object.position.clone()}
      setFolding(true);window.addEventListener('pointermove',onMove);window.addEventListener('pointerup',onUp);window.addEventListener('pointercancel',onUp)
    }
    // Two fingers: pinch to come in close (toward the fingers) and slide to move along the piece. When the first
    // finger was folding, the fold stops and the two fingers take over the view.
    const touches=new Map<number,{x:number;y:number}>(),mid=new Vector2(),toward=new Vector3(),dir=new Vector3(),rightV=new Vector3(),upV=new Vector3()
    let pinch:{d:number;x:number;y:number}|null=null
    const pair=()=>{const [a,b]=[...touches.values()];return{d:Math.hypot(a.x-b.x,a.y-b.y)||1,x:(a.x+b.x)/2,y:(a.y+b.y)/2}}
    const onPinchMove=(e:PointerEvent)=>{
      if(!pinch||!touches.has(e.pointerId))return;touches.set(e.pointerId,{x:e.clientX,y:e.clientY});const n=pair(),r=el.getBoundingClientRect()
      const aim=controls?.target??new Vector3(),dist=camera.position.distanceTo(aim)||1,fov=(camera as unknown as {fov?:number}).fov??40,per=2*dist*Math.tan(fov*Math.PI/360)/r.height
      rightV.setFromMatrixColumn(camera.matrixWorld,0);upV.setFromMatrixColumn(camera.matrixWorld,1)
      const shift=rightV.multiplyScalar(-(n.x-pinch.x)*per).add(upV.multiplyScalar((n.y-pinch.y)*per));camera.position.add(shift);aim.add(shift)
      const min=controls?.minDistance??0,max=controls?.maxDistance??Infinity,s=Math.min(max,Math.max(min,dist*pinch.d/n.d))/dist
      mid.set((n.x-r.left)/r.width*2-1,-((n.y-r.top)/r.height)*2+1);camera.updateMatrixWorld();raycaster.setFromCamera(mid,camera)
      camera.getWorldDirection(dir);plane.setFromNormalAndCoplanarPoint(dir,aim)
      if(raycaster.ray.intersectPlane(plane,toward)){camera.position.sub(toward).multiplyScalar(s).add(toward);aim.sub(toward).multiplyScalar(s).add(toward)}
      pinch=n;camera.updateMatrixWorld();controls?.update();invalidate()
    }
    const onTouchDown=(e:PointerEvent)=>{
      if(e.pointerType!=='touch')return;touches.set(e.pointerId,{x:e.clientX,y:e.clientY})
      if(touches.size===2&&drag){e.stopPropagation();e.preventDefault();endDrag();pinch=pair();window.addEventListener('pointermove',onPinchMove)}
    }
    const onTouchUp=(e:PointerEvent)=>{touches.delete(e.pointerId);if(pinch&&touches.size<2){pinch=null;window.removeEventListener('pointermove',onPinchMove)}}
    const host=el.parentElement??el
    host.addEventListener('pointerdown',onTouchDown,{capture:true});window.addEventListener('pointerup',onTouchUp,true);window.addEventListener('pointercancel',onTouchUp,true)
    host.addEventListener('pointerdown',onDown,{capture:true})
    // 'unclasped': folds only once laid flat (a watch).
    el.dataset.amesFoldable=pinned>=0?'unclasped':'true'
    return()=>{el.removeEventListener('ames:bracelet',onMessage);host.removeEventListener('pointerdown',onDown,{capture:true});onUp({pointerId:drag?.id??-1} as PointerEvent)
      host.removeEventListener('pointerdown',onTouchDown,{capture:true});window.removeEventListener('pointerup',onTouchUp,true);window.removeEventListener('pointercancel',onTouchUp,true);window.removeEventListener('pointermove',onPinchMove)
      if(controls){controls.minDistance=CAMERA_MIN_DISTANCE;controls.enablePan=false}
      cancelAnimationFrame(frame);reapply.current=null;delete el.dataset.amesBracelet;delete el.dataset.amesBraceletState;delete el.dataset.amesFoldable}
  },[built,gl,invalidate,camera,controls])
  // Dangling: each hinged part is a damped pendulum. When the piece is turned (orbit or turntable) its hinge
  // moves on screen and the part swings behind it, then settles; it also sways gently once as it appears.
  useEffect(()=>{
    const dangles=built.dangles;if(!dangles.length)return
    gl.domElement.dataset.amesDangles=String(dangles.length)
    const reduce=typeof window!=='undefined'&&window.matchMedia?.('(prefers-reduced-motion: reduce)').matches
    const state=dangles.map((d,i)=>{
      // Slowed from real time (about a third) so the swing reads on screen; light damping.
      const omega=Math.min(14,Math.max(5,Math.sqrt(9.81/Math.max(.004,d.length/1000))/3))
      const side=new Vector3(1,0,0).sub(d.hang.clone().multiplyScalar(d.hang.x)).normalize()
      return {omega,zeta:.16,angle:new Vector3(),speed:reduce?new Vector3():side.multiplyScalar(i%2?-.7:.7),prev:null as Vector3|null,prevV:null as Vector3|null}
    })
    const world=new Vector3(),cam=new Vector3(),acc=new Vector3(),q=new Quaternion(),parentQ=new Quaternion(),scaleV=new Vector3(),axis=new Vector3(),swing=new Quaternion()
    let frame=0,last=performance.now()
    const tick=(now:number)=>{
      const dt=Math.min(.05,(now-last)/1000);last=now;let moving=false
      dangles.forEach((d,i)=>{
        const s=state[i],parent=d.object.parent;if(!parent)return
        // The hinge's acceleration as seen from the camera, in the part's parent frame (mm/s²).
        d.object.getWorldPosition(world);cam.copy(world).applyMatrix4(camera.matrixWorldInverse)
        acc.set(0,0,0)
        if(s.prev&&dt>0){const v=cam.clone().sub(s.prev).divideScalar(dt);if(s.prevV)acc.copy(v).sub(s.prevV).divideScalar(dt);s.prevV=v}
        s.prev=cam.clone()
        parent.getWorldQuaternion(parentQ);parent.getWorldScale(scaleV)
        acc.applyQuaternion(camera.quaternion).applyQuaternion(q.copy(parentQ).invert()).divideScalar(scaleV.x||1)
        acc.sub(d.hang.clone().multiplyScalar(acc.dot(d.hang)))
        if(acc.length()>2e5)acc.setLength(2e5)
        // θ'' = -ω²θ - 2ζωθ' - a/L (the part lags behind its hinge), a few sub-steps per frame.
        const steps=Math.max(1,Math.ceil(dt*240)),h=dt/steps
        for(let k=0;k<steps;k++){
          const a=s.angle.clone().multiplyScalar(-s.omega*s.omega).addScaledVector(s.speed,-2*s.zeta*s.omega).addScaledVector(acc,-.18/d.length)
          s.speed.addScaledVector(a,h);s.angle.addScaledVector(s.speed,h)
          s.angle.sub(d.hang.clone().multiplyScalar(s.angle.dot(d.hang)))
        }
        if(s.angle.length()>.4)s.angle.setLength(.4)
        const turn=s.angle.length()
        if(turn>1e-5){axis.crossVectors(d.hang,s.angle).normalize();swing.setFromAxisAngle(axis,turn);d.object.quaternion.copy(d.rest).premultiply(swing)}
        else d.object.quaternion.copy(d.rest)
        if(turn>2e-4||s.speed.length()>2e-3)moving=true
      })
      if(moving){invalidate();gl.domElement.dataset.amesDangleSwing=(Math.max(...state.map(x=>x.angle.length()))*180/Math.PI).toFixed(1)}
      else if(gl.domElement.dataset.amesDangleSwing!=='0.0')gl.domElement.dataset.amesDangleSwing='0.0'
      frame=requestAnimationFrame(tick)
    }
    frame=requestAnimationFrame(tick)
    return()=>{cancelAnimationFrame(frame);dangles.forEach(d=>d.object.quaternion.copy(d.rest));delete gl.domElement.dataset.amesDangles}
  },[built,gl,invalidate,camera])
  // Opening: the page sends 'ames:open' {open} (or the viewer taps the opening part); lids swing on their hinges.
  useEffect(()=>{
    const opens=built.opens;if(!opens.length)return
    const el=gl.domElement,host=el.parentElement??el
    el.dataset.amesOpenable=built.openLabel||'piece';el.dataset.amesOpenState='closed'
    let progress=0,frame=0
    const ease=(t:number)=>t<.5?4*t*t*t:1-Math.pow(-2*t+2,3)/2
    const apply=(p:number)=>{for(const o of opens)o.object.quaternion.copy(o.rest).multiply(new Quaternion().setFromAxisAngle(o.axis,o.angle*ease(p)))
      el.dataset.amesOpenState=p>=1?'open':p<=0?'closed':'moving'}
    const animate=(target:number)=>{cancelAnimationFrame(frame);const from=progress,start=performance.now(),duration=Math.max(1,1300*Math.abs(target-from))
      const step=(now:number)=>{const k=Math.min(1,(now-start)/duration);progress=from+(target-from)*k;apply(progress);invalidate();if(k<1)frame=requestAnimationFrame(step)}
      frame=requestAnimationFrame(step)}
    const onMessage=(event:Event)=>{const want=(event as CustomEvent<{open?:boolean}>).detail?.open;animate(want===undefined?(progress>.5?0:1):want?1:0)}
    // A tap (not a drag) on an opening part toggles it.
    const raycaster=new Raycaster(),ndc=new Vector2();let down:{x:number;y:number;hit:boolean}|null=null
    const owned=(o:Object3D|null)=>{for(;o;o=o.parent)if(opens.some(x=>x.object===o))return true;return false}
    const onDown=(e:PointerEvent)=>{const r=el.getBoundingClientRect();ndc.set((e.clientX-r.left)/r.width*2-1,-((e.clientY-r.top)/r.height)*2+1);raycaster.setFromCamera(ndc,camera)
      const first=raycaster.intersectObject(built.root,true).find(h=>h.object.visible);down={x:e.clientX,y:e.clientY,hit:!!first&&owned(first.object)}}
    const onUp=(e:PointerEvent)=>{if(down?.hit&&Math.hypot(e.clientX-down.x,e.clientY-down.y)<6){animate(progress>.5?0:1);el.dispatchEvent(new CustomEvent('ames:open-state'))}down=null}
    el.addEventListener('ames:open',onMessage);host.addEventListener('pointerdown',onDown,{capture:true});window.addEventListener('pointerup',onUp)
    return()=>{el.removeEventListener('ames:open',onMessage);host.removeEventListener('pointerdown',onDown,{capture:true});window.removeEventListener('pointerup',onUp)
      cancelAnimationFrame(frame);opens.forEach(o=>o.object.quaternion.copy(o.rest));delete el.dataset.amesOpenable;delete el.dataset.amesOpenState}
  },[built,gl,invalidate,camera])
  useControlledTurntable(pivot,enabled,true,interacting||folding,resetToken,invalidate)
  const stage=useMemo(()=>{const size=built.size.clone().multiplyScalar(built.scale)
    return {floor:-size.y/2,back:-size.z/2-.015,depth:size.z,span:Math.max(size.x,size.y,size.z),hang:built.bracelet?.lay==='hang',phone:typeof matchMedia==='function'&&matchMedia('(pointer: coarse)').matches}},[built])
  return <>
    <group ref={pivot} name="ames-physical-turntable" scale={built.scale}><primitive object={built.root}/></group>
    <StudioStage {...stage}/>
  </>
}
