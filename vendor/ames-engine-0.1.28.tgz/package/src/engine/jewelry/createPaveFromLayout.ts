import { BufferAttribute, BufferGeometry, Matrix4, Quaternion, Vector3 } from 'three'
import { ConvexGeometry } from 'three/examples/jsm/geometries/ConvexGeometry.js'

/** Melee for pavé: a light single-cut brilliant (octagonal table, 16-sided girdle, pointed
 * culet) with the engine's round brilliant proportions. Diameter 2, girdle on y = 0. */
let meleeUnit: BufferGeometry | undefined
function melee() {
  if (meleeUnit) return meleeUnit
  const points: Vector3[] = []
  for (let i = 0; i < 8; i++) { const a = (i + .5) * Math.PI / 4; points.push(new Vector3(.56 * Math.cos(a), .322, .56 * Math.sin(a))) }
  for (let i = 0; i < 16; i++) { const a = i * Math.PI / 8; points.push(new Vector3(Math.cos(a), 0, Math.sin(a))) }
  points.push(new Vector3(0, -.886, 0))
  meleeUnit = new ConvexGeometry(points)
  return meleeUnit
}

/**
 * Builds a merged pavé volume from an AMES pavé layout: base64 Float32 records of
 * [x, y, z, qx, qy, qz, qw, diameter], one per melee, in the coordinate frame of the
 * pavé node's parent. Shipping the layout instead of the melee mesh keeps a fully iced
 * piece to a few kilobytes of stones.
 */
export function createPaveFromLayout(layout: string, parentToLocal = new Matrix4()) {
  const bytes = Uint8Array.from(atob(layout), c => c.charCodeAt(0))
  const records = new Float32Array(bytes.buffer, 0, Math.floor(bytes.byteLength / 32) * 8)
  const unit = melee(), unitPosition = unit.getAttribute('position'), unitNormal = unit.getAttribute('normal')
  const perStone = unitPosition.count, stones = records.length / 8
  const position = new Float32Array(stones * perStone * 3), normal = new Float32Array(stones * perStone * 3)
  const matrix = new Matrix4(), normalMatrix = new Matrix4(), q = new Quaternion(), p = new Vector3(), s = new Vector3(), v = new Vector3()
  // Hand-set stones are never identical in placement: each melee is turned on its axis at random (so the facets do
  // not line up) and tipped by up to about a degree. Seeded by the stone's index, so a piece looks the same each time.
  const random = (seed: number) => { const x = Math.sin(seed * 12.9898 + 78.233) * 43758.5453; return x - Math.floor(x) }
  const spin = new Quaternion(), tip = new Quaternion(), up = new Vector3(0, 1, 0), axis = new Vector3()
  for (let i = 0; i < stones; i++) {
    const r = i * 8, half = records[r + 7] / 2
    p.set(records[r], records[r + 1], records[r + 2]); q.set(records[r + 3], records[r + 4], records[r + 5], records[r + 6]); s.setScalar(half)
    const turn = random(i + 1) * Math.PI / 4, lean = (random(i + 101) - .5) * .035, dir = random(i + 211) * Math.PI * 2
    spin.setFromAxisAngle(up, turn); tip.setFromAxisAngle(axis.set(Math.cos(dir), 0, Math.sin(dir)), lean); q.multiply(tip).multiply(spin)
    matrix.compose(p, q, s).premultiply(parentToLocal); normalMatrix.makeRotationFromQuaternion(q).premultiply(new Matrix4().extractRotation(parentToLocal))
    for (let k = 0; k < perStone; k++) {
      const o = (i * perStone + k) * 3
      v.fromBufferAttribute(unitPosition, k).applyMatrix4(matrix); position[o] = v.x; position[o + 1] = v.y; position[o + 2] = v.z
      v.fromBufferAttribute(unitNormal, k).transformDirection(normalMatrix); normal[o] = v.x; normal[o + 1] = v.y; normal[o + 2] = v.z
    }
  }
  const geometry = new BufferGeometry()
  geometry.setAttribute('position', new BufferAttribute(position, 3)); geometry.setAttribute('normal', new BufferAttribute(normal, 3))
  geometry.userData = { cut: 'pave-melee', stones }
  return geometry
}
