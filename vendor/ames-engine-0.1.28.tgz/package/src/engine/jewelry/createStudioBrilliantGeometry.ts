import { Vector3 } from 'three'
import { ConvexGeometry } from 'three/examples/jsm/geometries/ConvexGeometry.js'
import { createRoundBrilliantGeometry } from './createRoundBrilliantGeometry'

/** Preserve eightfold brilliant optics, refine both closed girdle boundaries. */
export function createStudioBrilliantGeometry(outline: 'round'|'oval'|'pear'|'cushion'|'radiant' = 'round') {
  const base=createRoundBrilliantGeometry(), attribute=base.getAttribute('position')
  const points:Vector3[]=[],seen=new Set<string>()
  for(let i=0;i<attribute.count;i++) {
    const v=new Vector3().fromBufferAttribute(attribute,i),key=v.toArray().map(x=>x.toFixed(7)).join(',')
    if(!seen.has(key)){seen.add(key);points.push(v)}
  }
  // A thin girdle ring (matching the round brilliant): a tall polished band shows as a bright line round the stone.
  for(let i=0;i<64;i++)for(const y of [-.008,.008]) {
    const a=i*Math.PI*2/64,v=new Vector3(Math.cos(a),y,Math.sin(a)),key=v.toArray().map(x=>x.toFixed(7)).join(',')
    if(!seen.has(key)){seen.add(key);points.push(v)}
  }
  base.dispose()
  // Keep each authored cut's outline. The host subsequently fits its exact bounds.
  for(const v of points){
    const radius=Math.hypot(v.x,v.z);if(radius<1e-8)continue
    const c=v.x/radius,s=v.z/radius
    if(outline==='pear'){v.x=radius*c*(.78-.25*s);v.z=radius*s*1.28}
    if(outline==='cushion'){v.x=radius*Math.sign(c)*Math.abs(c)**.68;v.z=radius*Math.sign(s)*Math.abs(s)**.68}
    if(outline==='radiant'){const edge=Math.min(1/Math.max(Math.abs(c),Math.abs(s)),1.75/(Math.abs(c)+Math.abs(s)));v.x=radius*c*edge;v.z=radius*s*edge}
  }
  const geometry=new ConvexGeometry(points)
  geometry.computeBoundingBox();geometry.computeBoundingSphere()
  const normals=geometry.getAttribute('normal'),planes=new Set<string>()
  for(let i=0;i<normals.count;i+=3)planes.add([normals.getX(i),normals.getY(i),normals.getZ(i)].map(n=>n.toFixed(5)).join(','))
  geometry.userData={cut:'eightfold-brilliant-refined-girdle',outline,flatFacets:planes.size,girdleSegments:64}
  return geometry
}
