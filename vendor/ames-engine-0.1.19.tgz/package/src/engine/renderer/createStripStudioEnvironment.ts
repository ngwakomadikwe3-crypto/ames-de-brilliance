import { BackSide, Color, Mesh, MeshBasicMaterial, PlaneGeometry, PMREMGenerator, Scene, SphereGeometry } from 'three'
import type { Texture, WebGLRenderer, WebGLRenderTarget } from 'three'

/**
 * The reflections polished metal sees, set up like a jewellery photographer's light tent: pale walls, an overhead
 * softbox and tall strip lights, with black cards placed to draw the dark lines that show a polished surface's
 * shape, as in a product photograph, instead of an even chrome glow.
 */
export function createStripStudioEnvironment(gl: WebGLRenderer): { texture: Texture; dispose: () => void } {
  const scene = new Scene(), disposables: { dispose: () => void }[] = []
  const add = (geometry: PlaneGeometry | SphereGeometry, colour: number, intensity: number, place: (m: Mesh) => void, side?: typeof BackSide) => {
    const material = new MeshBasicMaterial({ color: new Color(colour).multiplyScalar(intensity), side, toneMapped: false })
    const mesh = new Mesh(geometry, material); place(mesh); mesh.lookAt(0, 0, 0); scene.add(mesh); disposables.push(geometry, material)
  }
  // The room: a mid-grey tent, darker toward the table, so polished metal has real darks to show.
  add(new SphereGeometry(20, 32, 16), 0xffffff, .3, m => m.position.set(0, 0, 0), BackSide)
  add(new PlaneGeometry(30, 30), 0xffffff, .1, m => m.position.set(0, -9, 0))
  // Overhead softbox, and tall strips left and right, slightly forward, and a thinner one behind.
  add(new PlaneGeometry(7, 7), 0xffffff, 4.5, m => m.position.set(0, 9, 1))
  add(new PlaneGeometry(1.8, 12), 0xffffff, 6, m => m.position.set(-8, 1, 3))
  add(new PlaneGeometry(1.8, 12), 0xfff8f0, 5.5, m => m.position.set(8, 1, 2))
  add(new PlaneGeometry(10, 1.4), 0xffffff, 4.5, m => m.position.set(0, 3, -9))
  // Around the horizon, where a ring band looks: alternating white cards and black flags, as in a ring
  // photographer's tent, give the band its bright and dark bands.
  for (let i = 0; i < 12; i++) {
    const a = i / 12 * Math.PI * 2, white = i % 2 === 0
    add(new PlaneGeometry(white ? 3.2 : 4.2, 7), white ? 0xffffff : 0x000000, white ? 1.6 : 1, m => m.position.set(Math.cos(a) * 9.5, -.5, Math.sin(a) * 9.5))
  }
  // A black card low in front: the dark line along the inside of a band.
  add(new PlaneGeometry(14, 2.4), 0x000000, 1, m => m.position.set(0, -4, 8))
  const generator = new PMREMGenerator(gl)
  const target: WebGLRenderTarget = generator.fromScene(scene, 0.012)
  generator.dispose(); disposables.forEach(d => d.dispose())
  return { texture: target.texture, dispose: () => target.dispose() }
}
