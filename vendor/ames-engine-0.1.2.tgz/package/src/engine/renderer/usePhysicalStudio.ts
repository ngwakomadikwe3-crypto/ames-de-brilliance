import { useEffect, useState } from 'react'
import { useThree } from '@react-three/fiber'
import { EquirectangularReflectionMapping, HalfFloatType, PMREMGenerator, LinearSRGBColorSpace } from 'three'
import { RGBELoader } from 'three-stdlib'
import type { DataTexture, Texture, WebGLRenderTarget } from 'three'

export const STUDIO_HDR_URL = '/ames-engine/environments/studio-small-09-v2.hdr'
export interface PhysicalStudio { radiance: DataTexture; environment: Texture }

/** Each renderer owns its PMREM. Failure is fatal to 3D, never a substitute map. */
export function usePhysicalStudio(): PhysicalStudio | null {
  const { gl, scene, invalidate } = useThree()
  const [maps, setMaps] = useState<PhysicalStudio | null>(null)
  const [error, setError] = useState<Error | null>(null)
  useEffect(() => {
    let alive = true
    let radiance: DataTexture | undefined, target: WebGLRenderTarget | undefined
    const previous = scene.environment
    const generator = new PMREMGenerator(gl)
    gl.domElement.dataset.studioEnvironment = 'loading-hdr'
    new RGBELoader().setDataType(HalfFloatType).loadAsync(STUDIO_HDR_URL).then(hdr => {
      if (!alive) { hdr.dispose(); return }
      radiance = hdr
      hdr.mapping = EquirectangularReflectionMapping
      hdr.colorSpace = LinearSRGBColorSpace
      if (!hdr.image.width || !hdr.image.height) throw Error('Studio HDR image is empty.')
      target = generator.fromEquirectangular(hdr)
      if (!target.texture || gl.getContext().isContextLost()) throw Error('Studio HDR processing failed.')
      scene.environment = target.texture
      scene.environmentIntensity = 1
      gl.domElement.dataset.studioEnvironment = 'hdr-pmrem'
      setMaps({ radiance: hdr, environment: target.texture }); invalidate()
    }).catch(() => {
      if (alive) setError(Error('Studio lighting could not load. Showing the still preview.'))
    }).finally(() => generator.dispose())
    return () => {
      alive = false; scene.environment = previous
      radiance?.dispose(); target?.dispose()
      delete gl.domElement.dataset.studioEnvironment
    }
  }, [gl, scene, invalidate])
  if (error) throw error
  return maps
}
