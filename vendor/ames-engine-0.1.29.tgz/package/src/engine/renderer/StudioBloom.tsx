import { useEffect, useMemo } from 'react'
import { useFrame, useThree } from '@react-three/fiber'
import { Color, ConstantAlphaFactor, CustomBlending, HalfFloatType, NoBlending, NoToneMapping, OneMinusConstantAlphaFactor, Quaternion, ShaderMaterial, Vector2, Vector3, WebGLRenderTarget } from 'three'
import type { Object3D, PerspectiveCamera } from 'three'
import { FullScreenQuad } from 'three/examples/jsm/postprocessing/Pass.js'

let bloomSamples = 4
const STAR_THRESHOLD = 1.8, STAR_GAIN = .07
/** Stones join this layer: only light leaving a stone becomes a star, never a highlight on the metal. */
export const STAR_LAYER = 3
/** Edge smoothing samples for the studio render (fewer on phones). */
export function setBloomSamples(n: number) { bloomSamples = n }

/**
 * Still-frame refinement: how a photograph differs from a single rendered frame. Once the piece and the view have
 * come to rest, the studio keeps drawing the same picture, each time through a slightly different point of the
 * lens, and averages the frames. The hard stair-steps inside the stones melt into clean facets, fine detail stops
 * shimmering, and what lies in front of or behind the point of focus softens a little, as it does through a real
 * macro lens. Nothing is spent while the piece is being turned: the first frame is exactly the unrefined picture.
 *  frames: how many frames are averaged; aperture: lens radius as a fraction of the distance to the point of
 *  focus (0 = everything sharp); budgetMs: stop early on a slow device once this long has been spent.
 */
export const stillRefinement = { frames: 28, aperture: .0035, budgetMs: 4000 }
export function setStillRefinement(next: Partial<typeof stillRefinement>) { Object.assign(stillRefinement, next) }
/** After the piece itself last moved (a swinging drop, a ticking hand, an opening lid), wait this long before refining. */
const REFINE_SETTLE_MS = 380
const halton = (index: number, base: number) => { let f = 1, r = 0; for (let i = index; i > 0; i = Math.floor(i / base)) { f /= base; r += f * (i % base) } return r }
/** A number that changes whenever anything that is drawn moves, appears or disappears. */
function poseOf(root: Object3D) {
  let h = 0, n = 0
  root.traverse(object => { n++
    if (!object.visible) { h = (h * 31 + n) % 2147483647; return }
    const e = object.matrixWorld.elements
    h = (h * 31 + (e[0] * 3 + e[1] * 5 + e[2] * 7 + e[4] * 11 + e[5] * 13 + e[6] * 17 + e[8] * 19 + e[9] * 23 + e[10] * 29 + e[12] * 37 + e[13] * 41 + e[14] * 43) * 8191) % 2147483647 })
  return h
}

/** HDR-only highlight bloom, preserving transparent alpha and tone-mapping once. */
export function StudioBloom() {
  const {gl,size}=useThree(),dpr=useThree(s=>s.viewport.dpr)
  const state=useMemo(()=>{
    const target=()=>new WebGLRenderTarget(1,1,{type:HalfFloatType,depthBuffer:true})
    const base=target(), blurA=target(),blurB=target(),peaks=target(),rayA=target(),rayB=target(),gemPass=target()
    base.samples=bloomSamples
    // The averaged picture, and the pass that folds each new frame into it (weight 1/n, set per frame).
    const still=new WebGLRenderTarget(1,1,{type:HalfFloatType,depthBuffer:false})
    const fold=new ShaderMaterial({vertexShader:'varying vec2 vUv; void main(){vUv=uv;gl_Position=vec4(position.xy,0.,1.);}',depthTest:false,depthWrite:false,toneMapped:false,
      transparent:true,blending:CustomBlending,blendSrc:ConstantAlphaFactor,blendDst:OneMinusConstantAlphaFactor,
      uniforms:{inputMap:{value:base.texture}},
      // Clamped: one runaway pixel must not be able to stay in the average.
      fragmentShader:'varying vec2 vUv;uniform sampler2D inputMap;void main(){gl_FragColor=clamp(texture2D(inputMap,vUv),0.,60000.);}'})
    const refine={count:0,camera:'',pose:0,movedAt:0,startedAt:0,done:false,timer:0 as unknown as ReturnType<typeof setTimeout>|0,position:new Vector3(),quaternion:new Quaternion(),right:new Vector3(),up:new Vector3(),focus:new Vector3()}
    const vertexShader='varying vec2 vUv; void main(){vUv=uv;gl_Position=vec4(position.xy,0.,1.);}'
    const blur=new ShaderMaterial({vertexShader,depthTest:false,depthWrite:false,toneMapped:false,
      uniforms:{inputMap:{value:base.texture},stepUv:{value:new Vector2()},threshold:{value:2}},
      fragmentShader:`varying vec2 vUv;uniform sampler2D inputMap;uniform vec2 stepUv;uniform float threshold;
      void main(){vec3 sum=vec3(0.);float weightSum=0.;for(int i=-4;i<=4;i++){
        float w=exp(-float(i*i)/7.);vec3 c=texture2D(inputMap,vUv+float(i)*stepUv).rgb;
        float peak=dot(c,vec3(.2126,.7152,.0722));c*=max(peak-threshold,0.)/max(peak,.0001);sum+=c*w;weightSum+=w;
      }gl_FragColor=vec4(sum/weightSum,1.);}`})
    // Brilliance: the brightest flashes of light in the stones (and only those) are drawn out into fine four-point
    // stars, as a photographer's eye and lens see a diamond's fire. Found on a quarter-size copy, so it stays cheap.
    const peak=new ShaderMaterial({vertexShader,depthTest:false,depthWrite:false,toneMapped:false,
      uniforms:{inputMap:{value:gemPass.texture},texel:{value:new Vector2()},threshold:{value:STAR_THRESHOLD}},
      fragmentShader:`varying vec2 vUv;uniform sampler2D inputMap;uniform vec2 texel;uniform float threshold;
      // White light only: a star is a flash of the lamp itself, not a bright coloured facet.
      float lum(vec3 c){return min(c.r,min(c.g,c.b));}
      void main(){vec3 c=texture2D(inputMap,vUv).rgb;float p=lum(c),around=0.,inside=1.;
        // A star only where a point of light stands out from the stone around it, not across a bright face,
        // and never on a stone's outline, where the dark page beside it would make any edge look like a point.
        for(int i=0;i<8;i++){float a=float(i)*.785398;vec4 s=texture2D(inputMap,vUv+vec2(cos(a),sin(a))*texel*2.);around+=lum(s.rgb);inside=min(inside,s.a);}
        around/=8.;if(inside<.5)p=0.;float floor_=max(threshold,around*3.);gl_FragColor=vec4(c*max(p-floor_,0.)/max(p,.0001),1.);}`})
    const ray=new ShaderMaterial({vertexShader,depthTest:false,depthWrite:false,toneMapped:false,
      uniforms:{inputMap:{value:peaks.texture},stepUv:{value:new Vector2()}},
      fragmentShader:`varying vec2 vUv;uniform sampler2D inputMap;uniform vec2 stepUv;
      void main(){vec3 sum=vec3(0.);for(int i=1;i<=8;i++){float w=pow(.66,float(i));
        sum+=(texture2D(inputMap,vUv+float(i)*stepUv).rgb+texture2D(inputMap,vUv-float(i)*stepUv).rgb)*w;}
        gl_FragColor=vec4(sum,1.);}`})
    const output=new ShaderMaterial({vertexShader,depthTest:false,depthWrite:false,toneMapped:true,
      uniforms:{baseMap:{value:still.texture},glowMap:{value:blurB.texture},rayMapA:{value:rayA.texture},rayMapB:{value:rayB.texture},starGain:{value:STAR_GAIN}},
      fragmentShader:`varying vec2 vUv;uniform sampler2D baseMap;uniform sampler2D glowMap;uniform sampler2D rayMapA;uniform sampler2D rayMapB;uniform float starGain;
      void main(){vec4 base=texture2D(baseMap,vUv);vec3 glow=texture2D(glowMap,vUv).rgb*.035+(texture2D(rayMapA,vUv).rgb+texture2D(rayMapB,vUv).rgb)*starGain;
        float halo=clamp(max(glow.r,max(glow.g,glow.b)),0.,.18);float a=max(base.a,halo);
        gl_FragColor=vec4((base.rgb+glow)/max(a,.0001),a);
        #include <tonemapping_fragment>
        #include <colorspace_fragment>
        gl_FragColor.rgb *= gl_FragColor.a;
      }`})
    return {base,still,fold,refine,blurA,blurB,gemPass,peaks,rayA,rayB,peak,ray,blur,output,quad:new FullScreenQuad(blur),clear:new Color()}
  },[])
  useEffect(()=>{
    const dpr=gl.getPixelRatio(),w=Math.max(1,Math.round(size.width*dpr)),h=Math.max(1,Math.round(size.height*dpr))
    state.base.setSize(w,h);state.still.setSize(w,h);state.refine.count=0;state.refine.done=false;state.blurA.setSize(Math.ceil(w/2),Math.ceil(h/2));state.blurB.setSize(Math.ceil(w/2),Math.ceil(h/2))
    const qw=Math.ceil(w/4),qh=Math.ceil(h/4);state.peaks.setSize(qw,qh);state.gemPass.setSize(qw,qh);state.rayA.setSize(qw,qh);state.rayB.setSize(qw,qh)
    gl.domElement.dataset.studioBloom='hdr-threshold';return()=>{delete gl.domElement.dataset.studioBloom}
  },[gl,size,state,dpr])
  useEffect(()=>()=>{if(state.refine.timer)clearTimeout(state.refine.timer);state.still.dispose();state.fold.dispose();state.base.dispose();state.blurA.dispose();state.blurB.dispose();state.peaks.dispose();state.gemPass.dispose();state.rayA.dispose();state.rayB.dispose();state.peak.dispose();state.ray.dispose();state.blur.dispose();state.output.dispose();state.quad.dispose()},[state])
  useFrame(({scene,camera,controls,invalidate})=>{
    const target=gl.getRenderTarget(),tone=gl.toneMapping,alpha=gl.getClearAlpha();gl.getClearColor(state.clear)
    // Has the view or the piece changed since the last frame? If so, start the picture again from this frame.
    const r=state.refine,now=performance.now(),lens=camera as PerspectiveCamera
    scene.updateMatrixWorld();camera.updateMatrixWorld()
    const view=camera.matrixWorld.elements.join()+camera.projectionMatrix.elements.join(),pose=poseOf(scene)
    if(pose!==r.pose){r.pose=pose;r.movedAt=now;r.count=0;r.done=false
      // Nothing else will ask for a frame once the piece has come to rest: come back then and refine.
      if(r.timer)clearTimeout(r.timer);r.timer=setTimeout(()=>{r.timer=0;invalidate()},REFINE_SETTLE_MS+30)}
    if(view!==r.camera){r.camera=view;r.count=0;r.done=false}
    // The picture is finished and nothing has moved: show it again as it is, without drawing the piece again.
    if(r.done){gl.setRenderTarget(target);state.quad.material=state.output;state.quad.render(gl);return}
    const settled=now-r.movedAt>=REFINE_SETTLE_MS,frames=settled&&lens.isPerspectiveCamera?Math.max(1,Math.round(stillRefinement.frames)):1
    const sample=r.count
    if(sample===1)r.startedAt=now
    if(sample>0){
      // Each later frame looks through another point of the lens (and another point within each pixel).
      const w=state.base.width,h=state.base.height
      lens.setViewOffset(w,h,halton(sample,5)-.5,halton(sample,7)-.5,w,h)
      if(stillRefinement.aperture>0){
        r.position.copy(camera.position);r.quaternion.copy(camera.quaternion)
        r.focus.copy((controls as unknown as {target?:Vector3}|null)?.target??r.focus.set(0,0,0))
        const reach=camera.position.distanceTo(r.focus)*stillRefinement.aperture,radius=Math.sqrt(halton(sample,2))*reach,turn=halton(sample,3)*Math.PI*2
        r.right.setFromMatrixColumn(camera.matrixWorld,0);r.up.setFromMatrixColumn(camera.matrixWorld,1)
        camera.position.addScaledVector(r.right,Math.cos(turn)*radius).addScaledVector(r.up,Math.sin(turn)*radius)
        camera.lookAt(r.focus);camera.updateMatrixWorld()
      }
    }
    gl.setClearColor(0,0);gl.toneMapping=NoToneMapping;gl.setRenderTarget(state.base);gl.clear();gl.render(scene,camera)
    if(sample>0){
      // Put the camera back exactly: the orbit controls must never see the lens move.
      if(stillRefinement.aperture>0){camera.position.copy(r.position);camera.quaternion.copy(r.quaternion)}
      lens.clearViewOffset();camera.updateMatrixWorld()
    }
    // Fold this frame into the averaged picture.
    // (The first frame replaces the picture outright; later ones are weighted 1/n.)
    state.quad.material=state.fold;state.fold.uniforms.inputMap.value=state.base.texture;state.fold.blending=sample>0?CustomBlending:NoBlending;state.fold.blendAlpha=1/(sample+1)
    // (Without clearing: the picture so far is what the new frame is folded into.)
    const autoClear=gl.autoClear;gl.autoClear=false;gl.setRenderTarget(state.still);state.quad.render(gl);gl.autoClear=autoClear
    r.count=sample+1
    const spent=sample>0?now-r.startedAt:0
    if(r.count<frames&&!(r.count>=3&&spent>stillRefinement.budgetMs))invalidate()
    else if(settled&&frames>1)r.done=true
    if(gl.domElement.dataset.studioRefined!==String(r.count))gl.domElement.dataset.studioRefined=String(r.count)
    gl.domElement.dataset.studioStill=r.done?'done':'refining'
    state.quad.material=state.blur;state.blur.uniforms.inputMap.value=state.still.texture
    state.blur.uniforms.threshold.value=2;state.blur.uniforms.stepUv.value.set(1/state.blurA.width,0)
    gl.setRenderTarget(state.blurA);state.quad.render(gl)
    state.blur.uniforms.inputMap.value=state.blurA.texture;state.blur.uniforms.threshold.value=0;state.blur.uniforms.stepUv.value.set(0,1/state.blurB.height)
    gl.setRenderTarget(state.blurB);state.quad.render(gl)
    // Star rays, set a little off square (about 20 degrees) as a cross filter turns them.
    // The stones alone, at quarter size, so metal highlights never become stars.
    const mask=camera.layers.mask;camera.layers.set(STAR_LAYER);gl.setRenderTarget(state.gemPass);gl.clear();gl.render(scene,camera);camera.layers.mask=mask
    state.quad.material=state.peak;state.peak.uniforms.texel.value.set(1/state.gemPass.width,1/state.gemPass.height)
    gl.setRenderTarget(state.peaks);state.quad.render(gl)
    state.quad.material=state.ray;state.ray.uniforms.stepUv.value.set(Math.cos(.35)/state.peaks.width,Math.sin(.35)/state.peaks.height);gl.setRenderTarget(state.rayA);state.quad.render(gl)
    state.ray.uniforms.stepUv.value.set(-Math.sin(.35)/state.peaks.width,Math.cos(.35)/state.peaks.height);gl.setRenderTarget(state.rayB);state.quad.render(gl)
    gl.toneMapping=tone;gl.setRenderTarget(target);state.quad.material=state.output;state.quad.render(gl);gl.setClearColor(state.clear,alpha)
  },1)
  return null
}
