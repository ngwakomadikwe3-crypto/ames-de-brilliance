import { Color, Matrix4, MeshPhysicalMaterial, Vector3 } from 'three'
import type { BufferGeometry, Texture } from 'three'
import { MeshBVH, MeshBVHUniformStruct, shaderStructs, shaderIntersectFunction } from 'three-mesh-bvh'

export const STONE_OPTICS: Record<string, { ior: number; color: string; distance: number; dispersion: number }> = {
  'stone-diamond': { ior: 2.417, color: '#ffffff', distance: 12, dispersion: .7 },
  'stone-fancy-color-diamond': { ior: 2.417, color: '#ffe18c', distance: 2.8, dispersion: .7 },
  'stone-amber': { ior: 1.54, color: '#e0861c', distance: 2.2, dispersion: .05 },
  'stone-emerald': { ior: 1.577, color: '#14a85e', distance: 1.25, dispersion: .1 },
  // Matched to each stone's Blender render: colour kept per unit of travel, and how far it travels.
  'stone-alexandrite': { ior: 1.746, color: '#248c76', distance: 1.25, dispersion: 0.081 },
  'stone-amethyst': { ior: 1.544, color: '#8130b4', distance: 1.49, dispersion: 0.081 },
  'stone-ametrine': { ior: 1.544, color: '#8432b9', distance: 1.56, dispersion: 0.081 },
  'stone-aquamarine': { ior: 1.577, color: '#92e0ff', distance: 2.08, dispersion: 0.095 },
  'stone-citrine': { ior: 1.544, color: '#ff9f07', distance: 1.2, dispersion: 0.081 },
  'stone-garnet': { ior: 1.79, color: '#ae060e', distance: 1.25, dispersion: 0.114 },
  'stone-iolite': { ior: 1.54, color: '#5451b9', distance: 1.3, dispersion: 0.095 },
  'stone-kunzite': { ior: 1.66, color: '#f79ddb', distance: 2.6, dispersion: 0.1 },
  'stone-morganite': { ior: 1.58, color: '#ffaea3', distance: 2.6, dispersion: 0.095 },
  'stone-peridot': { ior: 1.67, color: '#8cd51c', distance: 1.56, dispersion: 0.106 },
  'stone-ruby': { ior: 1.762, color: '#e0020e', distance: 0.74, dispersion: 0.079 },
  'stone-sapphire': { ior: 1.762, color: '#1132db', distance: 1.39, dispersion: 0.079 },
  'stone-spinel': { ior: 1.718, color: '#925ab9', distance: 1.56, dispersion: 0.095 },
  'stone-tanzanite': { ior: 1.69, color: '#5d43db', distance: 1.39, dispersion: 0.114 },
  'stone-topaz': { ior: 1.62, color: '#7bcdff', distance: 2.08, dispersion: 0.085 },
  'stone-tourmaline': { ior: 1.624, color: '#22813e', distance: 1.25, dispersion: 0.1 },
  'stone-zircon': { ior: 1.93, color: '#f1ae5f', distance: 2.08, dispersion: 0.228 },
}

/** How much light tracing a gem may do. Phones get one trace per pixel (the colour split of the fire is left to
 * centre stones, where it costs three) and fewer internal bounces: on a phone, a watch's hundreds of melee would
 * otherwise trace millions of rays a frame. Set once by the viewer for the device it runs on. */
export const gemBudget = { heroTraces: 3, smallTraces: 3, heroBounces: 7, smallBounces: 4 }
export function setGemBudget(phone: boolean) {
  // The centre stone keeps its fire everywhere; on a phone the many small stones are traced once.
  Object.assign(gemBudget, phone ? { heroTraces: 3, smallTraces: 1, heroBounces: 5, smallBounces: 3 } : { heroTraces: 3, smallTraces: 3, heroBounces: 7, smallBounces: 4 })
}

/** MeshPhysicalMaterial with a BVH volume transmission extension. Stock physical
 * reflection/clearcoat remain intact; rays actually exit the faceted stone,
 * including total internal reflection and wavelength-dependent IOR. */
export function createPhysicalStudioGem(geometry: BufferGeometry, id: string, source: MeshPhysicalMaterial,
  environment: Texture, radiance: Texture, worldScale: number, small = false) {
  geometry.computeBoundingBox()
  const size = geometry.boundingBox!.getSize(new Vector3())
  const depth = size.y
  const optical = STONE_OPTICS[id], diamond = id === 'stone-diamond' || id === 'stone-fancy-color-diamond'
  const ior = optical?.ior ?? source.ior ?? 1.6
  const body = optical ? new Color(optical.color) : source.attenuationColor?.clone() ?? source.color.clone()
  if (!optical && body.equals(new Color('white'))) body.copy(source.color)
  const material = new MeshPhysicalMaterial({
    name: 'AMES studio volume · ' + id, color: 'white', metalness: 0, roughness: diamond ? 0 : .045,
    transmission: 1, ior, thickness: depth, attenuationColor: body,
    attenuationDistance: depth * worldScale * (optical?.distance ?? 2),
    dispersion: optical?.dispersion ?? .18, clearcoat: diamond ? .18 : 0, clearcoatRoughness: 0,
    envMap: environment, envMapIntensity: diamond ? 1 : .5, flatShading: true, toneMapped: true,
  })
  const bvhGeometry = geometry.clone()
  const bvh = new MeshBVHUniformStruct()
  bvh.updateFrom(new MeshBVH(bvhGeometry, { targetLeafSize: 2 }))
  const localToWorld = new Matrix4(), worldToLocal = new Matrix4()
  const uniforms = {
    amesBvh: { value: bvh }, amesRadiance: { value: radiance },
    amesLocalToWorld: { value: localToWorld }, amesWorldToLocal: { value: worldToLocal },
    amesEpsilon: { value: size.length() * .00015 },
    // How soft the studio looks from inside the stone. Pixel-sharp, the light tent's edges repeat as hard lines down
    // every parallel step facet; a touch of softness gives the broad light and dark bands a real stone shows.
    amesSoftness: { value: id === 'stone-diamond' || id === 'stone-fancy-color-diamond' ? .035 : .075 },
    // The viewer's own shadow: light that leaves the stone back toward the eye comes from where the viewer's head
    // and the camera block the room, so it is dark. This is what gives a well cut stone its crisp black and white
    // pattern (the "contrast" a grader looks for); without it the stone turns milky.
    amesHeadShadow: { value: diamond ? .9 : .55 },
    amesBounces: { value: 0 }, amesTraces: { value: 1 },
  }
  const bounces = small ? gemBudget.smallBounces : gemBudget.heroBounces, traces = small ? gemBudget.smallTraces : gemBudget.heroTraces
  // A smooth stone (amber's polished dome) is shaded with its smooth normals; faceted stones with each facet's own.
  const smooth = id === 'stone-amber'
  if (smooth) material.flatShading = false
  material.userData = { studioPhysical: true, gemstoneId: id, bounces, traces }
  uniforms.amesBounces.value = bounces; uniforms.amesTraces.value = traces
  // One shader for every stone, however many bounces and colour traces it gets: the counts are uniforms, so the
  // tracing code is compiled once instead of copied out per bounce and per colour. Compiling it is most of the
  // wait before a piece appears, especially on phones.
  material.customProgramCacheKey = () => `ames-physical-bvh-v6-${smooth ? 's' : 'f'}`
  material.onBeforeCompile = shader => {
    Object.assign(shader.uniforms, uniforms)
    // centroid: where edge smoothing shades a pixel only partly covered by a facet, take the position from inside
    // that facet, not the pixel centre beyond its edge; a ray traced from outside the stone shows as a fine bright
    // line along every facet edge. The BVH tracing already needs WebGL 2, which has centroid.
    const centroid = 'centroid '
    shader.vertexShader = `${centroid}varying vec3 amesLocalPosition; ${centroid}varying vec3 amesLocalNormal;\n` + shader.vertexShader
    shader.fragmentShader = `${centroid}varying vec3 amesLocalPosition; ${centroid}varying vec3 amesLocalNormal;\n` + shader.fragmentShader
    shader.vertexShader = shader.vertexShader.replace('#include <begin_vertex>', '#include <begin_vertex>\namesLocalPosition = position; amesLocalNormal = normal;')
    shader.fragmentShader = shader.fragmentShader.replace('#include <envmap_physical_pars_fragment>', `#include <envmap_physical_pars_fragment>
      precision highp isampler2D;
      precision highp usampler2D;
      uniform sampler2D amesRadiance;
      uniform mat4 amesLocalToWorld;
      uniform mat4 amesWorldToLocal;
      uniform float amesEpsilon;
      uniform float amesSoftness;
      uniform float amesHeadShadow;
      uniform int amesBounces;
      uniform int amesTraces;
      ${shaderStructs}
      ${shaderIntersectFunction}
      uniform BVH amesBvh;
      vec3 amesEnvironment(vec3 ray) {
        vec3 d = normalize(mat3(amesLocalToWorld) * ray);
        vec3 toEye = normalize(cameraPosition - (amesLocalToWorld * vec4(0., 0., 0., 1.)).xyz);
        float head = smoothstep(.8, .96, dot(d, toEye)) * amesHeadShadow;
        return textureCubeUV(envMap, envMapRotation * d, amesSoftness).rgb * (1. - head);
      }
      vec3 amesTrace(float eta, vec3 absorption, float distanceScale) {
        vec3 camera = (amesWorldToLocal * vec4(cameraPosition,1.)).xyz;
        vec3 incoming = normalize(amesLocalPosition-camera);
        // The facet's own flat normal, from the surface itself: a vertex normal is blended across facet edges, and
        // rays started with it near an edge slip straight out of the stone (thin white lines along every edge).
        vec3 n = ${smooth ? 'normalize(amesLocalNormal)' : 'normalize(cross(dFdx(amesLocalPosition), dFdy(amesLocalPosition)))'};
        if (dot(n, incoming) > 0.) n = -n;
        if (dot(n, n) < .5) n = normalize(amesLocalNormal);
        vec3 ray = refract(incoming, n, 1. / eta);
        // Start safely inside the stone, not on its skin, so the first hit is never the facet the ray entered by.
        vec3 origin = amesLocalPosition - n * amesEpsilon * 3. + ray * amesEpsilon;
        vec3 throughput = vec3(1.); vec3 light = vec3(0.); bool escaped = false;
        for (int bounce=0; bounce<amesBounces; bounce++) {
          uvec4 indices=uvec4(0u); vec3 normal=vec3(0.); vec3 bary=vec3(0.);
          float side=1.; float distanceToFace=0.;
          bool hit=bvhIntersectFirstHit(amesBvh, origin, ray, indices, normal, bary, side, distanceToFace);
          if (!hit) { light += throughput * amesEnvironment(ray); escaped = true; break; }
          float travel=length(mat3(amesLocalToWorld)*(ray*distanceToFace));
          throughput *= pow(max(absorption,vec3(.0001)),vec3(travel/max(distanceScale,.000001)));
          vec3 boundary=origin+ray*distanceToFace;
          vec3 exitRay=refract(ray, normal, eta);
          if(dot(exitRay,exitRay)>.00001) {
            float f0=pow((eta-1.)/(eta+1.),2.);
            float fresnel=f0+(1.-f0)*pow(1.-clamp(dot(-ray,normal),0.,1.),5.);
            light += throughput*(1.-fresnel)*amesEnvironment(exitRay);
            throughput *= fresnel;
          }
          if(max(throughput.r,max(throughput.g,throughput.b))<.003) break;
          ray=reflect(ray,normal);origin=boundary+ray*amesEpsilon*2.;
        }
        // Out of bounces with light still inside: let it out where it was heading rather than losing it, so a
        // small stone traced with few bounces stays bright instead of turning black.
        if (!escaped) light += throughput * amesEnvironment(ray) * .7;
        return light;
      }
    `)
    shader.fragmentShader = shader.fragmentShader.replace('#include <transmission_fragment>', `
      material.transmission=transmission; material.transmissionAlpha=1.;
      float spread=dispersion*.025;
      vec3 transmitted=vec3(0.);
      int amesColours = amesTraces >= 3 ? 3 : 1;
      for (int c=0; c<amesColours; c++) {
        // Three traces split the light by colour (fire); one trace treats it as white.
        vec3 t = amesTrace(amesColours == 3 ? ior + spread * float(c - 1) : ior, attenuationColor, attenuationDistance);
        if (amesColours == 1) transmitted = t; else if (c == 0) transmitted.r = t.r; else if (c == 1) transmitted.g = t.g; else transmitted.b = t.b;
      }
      float faceF0=pow((ior-1.)/(ior+1.),2.);
      float faceF=faceF0+(1.-faceF0)*pow(1.-clamp(dot(geometryNormal,geometryViewDir),0.,1.),5.);
      totalDiffuse = transmitted * (1.-faceF);
    `)
  }
  material.onBeforeRender = (_renderer, _scene, _camera, _geometry, object) => {
    localToWorld.copy(object.matrixWorld); worldToLocal.copy(object.matrixWorld).invert()
  }
  material.addEventListener('dispose', () => { bvh.dispose(); bvhGeometry.dispose() })
  return material
}
