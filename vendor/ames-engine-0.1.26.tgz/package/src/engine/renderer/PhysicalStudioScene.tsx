import { Suspense, useMemo, useState } from 'react'
import { useGLTF } from '@react-three/drei'
import { usePhysicalStudio } from './usePhysicalStudio'
import { PhysicalStudioModel } from '../jewelry/PhysicalStudioModel'
import { ViewerControls } from './ViewerControls'
import { StudioBloom } from './StudioBloom'
import { AdaptiveSharpness } from './AdaptiveSharpness'
import type { CameraPreset } from './cameraFraming'

export function PhysicalStudioScene({modelUrl,cameraPreset,zoom,turntableEnabled,resetToken,controlsEnabled,onModelReady}: {
  modelUrl: string;cameraPreset?:CameraPreset;zoom?:number;turntableEnabled?:boolean;resetToken?:number;controlsEnabled?:boolean;onModelReady?:()=>void
}) {
  // Fetch the piece while the studio lighting loads, not after it.
  useMemo(()=>useGLTF.preload(modelUrl),[modelUrl])
  const studio=usePhysicalStudio()
  const [interacting,setInteracting]=useState(false)
  if(!studio)return null
  return <>
    <directionalLight position={[3,4,5]} intensity={1.2} color="#ffffff"/>
    <directionalLight position={[-3,2,-4]} intensity={.6} color="#f1f6ff"/>
    <Suspense fallback={null}><PhysicalStudioModel url={modelUrl} studio={studio} enabled={turntableEnabled??false} interacting={interacting} resetToken={resetToken} onReady={onModelReady}/></Suspense>
    {controlsEnabled&&<ViewerControls cameraPreset={cameraPreset} zoom={zoom} resetToken={resetToken} onInteractionChange={setInteracting}/>}
    <StudioBloom/>
    <AdaptiveSharpness interacting={interacting}/>
  </>
}
