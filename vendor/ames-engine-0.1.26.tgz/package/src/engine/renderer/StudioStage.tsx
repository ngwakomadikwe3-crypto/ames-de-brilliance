import { useMemo } from 'react'
import { ContactShadows } from '@react-three/drei'
import { AdditiveBlending, CircleGeometry, ShaderMaterial } from 'three'

/**
 * The surface a piece rests on, as in a jewellery photograph on dark velvet: a soft pool of light under the
 * piece, a tight dark contact shadow where it touches, and a wider soft shadow around it. A piece shown hanging
 * (a necklace laid facing the viewer) casts its shadow onto the backdrop behind it instead.
 */
export function StudioStage({ floor, back, depth, hang, span, phone }: { floor: number; back: number; depth: number; hang: boolean; span: number; phone: boolean }) {
  const pool = useMemo(() => new ShaderMaterial({
    transparent: true, depthWrite: false, blending: AdditiveBlending, toneMapped: false,
    uniforms: {},
    vertexShader: 'varying vec2 vUv; void main(){ vUv = uv; gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.); }',
    // A spotlight falling on a dark emerald cloth: brightest under the piece, gone well before the edges.
    fragmentShader: `varying vec2 vUv; void main(){ float r = length(vUv - .5) * 2.; float f = exp(-r * r * 3.2) * (1. - smoothstep(.8, 1., r));
      gl_FragColor = vec4(vec3(.2, .3, .27) * f, f * .32); }`,
  }), [])
  const disc = useMemo(() => new CircleGeometry(.5, 64), [])
  const size = Math.max(2.4, span * 1.6), res = phone ? 256 : 512
  if (hang) return <group rotation={[Math.PI / 2, 0, 0]} position={[0, 0, back]}>
    {/* Drop shadow on the backdrop, set a touch lower than the piece as if lit from above. */}
    <ContactShadows position={[0, 0, .1]} scale={size} opacity={.6} blur={1.6} far={.6} resolution={res} color="#000805" />
    <ContactShadows position={[0, 0, .2]} scale={size * 1.2} opacity={.4} blur={3.5} far={depth + .4} resolution={phone ? 128 : 256} color="#000805" />
    <mesh geometry={disc} material={pool} scale={size * 1.15} position={[0, -.002, 0]} rotation={[-Math.PI / 2, 0, 0]} renderOrder={-1} />
  </group>
  return <group position={[0, floor, 0]}>
    <mesh geometry={disc} material={pool} scale={size * 1.25} position={[0, -.004, 0]} rotation={[-Math.PI / 2, 0, 0]} renderOrder={-1} />
    {/* Where it touches the table: dark and close. */}
    <ContactShadows position={[0, .001, 0]} scale={size} opacity={.9} blur={1} far={.3} resolution={res} color="#000805" />
    {/* The wider, softer shadow of the whole piece. */}
    <ContactShadows position={[0, .002, 0]} scale={size * 1.15} opacity={.6} blur={2.8} far={2.6} resolution={phone ? 128 : 256} color="#000805" />
  </group>
}
