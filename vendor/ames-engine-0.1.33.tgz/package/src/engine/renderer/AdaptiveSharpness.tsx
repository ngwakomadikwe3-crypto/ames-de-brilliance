import { useEffect } from 'react'
import { useThree } from '@react-three/fiber'

/**
 * Full sharpness when the piece is still, a lighter picture only while a finger or mouse is turning it. The viewer
 * draws only when something changes, so the one sharp frame after a turn is the only cost of full resolution;
 * on a phone that keeps turning smooth without the whole view looking soft.
 */
export function AdaptiveSharpness({ interacting }: { interacting: boolean }) {
  const setDpr = useThree(state => state.setDpr), invalidate = useThree(state => state.invalidate)
  useEffect(() => {
    const touch = typeof window !== 'undefined' && typeof window.matchMedia === 'function' && window.matchMedia('(pointer: coarse)').matches
    const device = typeof window === 'undefined' ? 1 : window.devicePixelRatio || 1
    const still = Math.min(device, 2), moving = Math.min(still, touch ? 1.25 : 1.5)
    if (interacting) { setDpr(moving); return }
    const settle = setTimeout(() => { setDpr(still); invalidate() }, 140)
    return () => clearTimeout(settle)
  }, [interacting, setDpr, invalidate])
  return null
}
