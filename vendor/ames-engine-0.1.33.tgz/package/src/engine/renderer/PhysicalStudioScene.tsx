import { Suspense, useEffect, useMemo, useState } from 'react'
import { useThree } from '@react-three/fiber'
import { NeutralToneMapping } from 'three'
import { useGLTF } from '@react-three/drei'
import { usePhysicalStudio } from './usePhysicalStudio'
import { PhysicalStudioModel } from '../jewelry/PhysicalStudioModel'
import { ViewerControls } from './ViewerControls'
import { AdaptiveSharpness } from './AdaptiveSharpness'
import type { CameraPreset } from './cameraFraming'

const STUDIO_EXPOSURE = 1

export function PhysicalStudioScene({phone=false,modelUrl,cameraPreset,zoom,turntableEnabled,resetToken,controlsEnabled,onModelReady}: {
  phone?: boolean;modelUrl: string;cameraPreset?:CameraPreset;zoom?:number;turntableEnabled?:boolean;resetToken?:number;controlsEnabled?:boolean;onModelReady?:()=>void
}) {
  // Fetch the piece while the studio lighting loads, not after it.
  useMemo(()=>useGLTF.preload(modelUrl),[modelUrl])
  const studio=usePhysicalStudio()
  // Neutral tone mapping keeps a diamond's whites white and its darks deep (ACES greys the brightest light).
  const gl=useThree(s=>s.gl),invalidate=useThree(s=>s.invalidate)
  useEffect(()=>{const tone=gl.toneMapping,exposure=gl.toneMappingExposure
    gl.toneMapping=NeutralToneMapping;gl.toneMappingExposure=STUDIO_EXPOSURE;invalidate()
    return()=>{gl.toneMapping=tone;gl.toneMappingExposure=exposure}},[gl,invalidate])
  const [interacting,setInteracting]=useState(false)
  if(!studio)return null
  return <>
    <directionalLight position={[3,4,5]} intensity={1.2} color="#ffffff"/>
    <directionalLight position={[-3,2,-4]} intensity={.6} color="#f1f6ff"/>
    <Suspense fallback={null}><PhysicalStudioModel phone={phone} url={modelUrl} studio={studio} enabled={turntableEnabled??false} interacting={interacting} resetToken={resetToken} onReady={onModelReady}/></Suspense>
    {controlsEnabled&&<ViewerControls cameraPreset={cameraPreset} zoom={zoom} resetToken={resetToken} onInteractionChange={setInteracting}/>}
    {/* Render each frame directly. Temporal accumulation and star overlays are disabled while moving jewellery. */}
    <AdaptiveSharpness interacting={interacting}/>
  </>
}
