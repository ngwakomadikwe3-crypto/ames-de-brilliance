import { useGLTF } from '@react-three/drei'
import { useThree } from '@react-three/fiber'
import { useEffect, useMemo, useRef } from 'react'
import { Box3, BoxGeometry, BufferAttribute, BufferGeometry, Group, Matrix4, Mesh, MeshBasicMaterial, Quaternion, Vector3 } from 'three'
import type { Material, MeshPhysicalMaterial, Object3D } from 'three'
import { applyJewelryMaterials, isQualifiedDielectricMesh } from './jewelryGlbMaterials'
import { createStudioBrilliantGeometry } from './createStudioBrilliantGeometry'
import { createPaveFromLayout } from './createPaveFromLayout'
import { createPhysicalStudioGem } from '../materials/PhysicalStudioGem'
import { useControlledTurntable } from '../renderer/useControlledTurntable'
import type { PhysicalStudio } from '../renderer/usePhysicalStudio'

/** Plain float copy of a geometry. Compressed GLBs (meshopt, KHR_mesh_quantization) load
 * interleaved and normalised-integer attributes, which the gem BVH textures cannot read. */
function plainGeometry(source: BufferGeometry){
  const geometry=new BufferGeometry()
  for(const [name,attribute] of Object.entries(source.attributes)){
    const {count,itemSize}=attribute, array=new Float32Array(count*itemSize)
    for(let i=0;i<count;i++)for(let k=0;k<itemSize;k++)array[i*itemSize+k]=attribute.getComponent(i,k)
    geometry.setAttribute(name,new BufferAttribute(array,itemSize))
  }
  if(source.index)geometry.setIndex(Array.from(source.index.array as ArrayLike<number>))
  geometry.userData={...source.userData};return geometry
}

type StudioCut = 'round'|'oval'|'pear'|'cushion'|'radiant'
type BraceletInfo = { links: number; pitch: number; length_mm: number; width_mm: number; clasp?: string; stones?: number; stone?: string }
const STUDIO_CUTS = new Set<StudioCut>(['round','oval','pear','cushion','radiant'])
const BRILLIANT_IDS = new Set(['stone-diamond','stone-fancy-color-diamond','stone-ruby','stone-sapphire','stone-morganite','stone-alexandrite','stone-spinel','stone-garnet','stone-zircon','stone-peridot'])

export function PhysicalStudioModel({url, studio, enabled, interacting, resetToken, onReady}: {
  url: string; studio: PhysicalStudio; enabled: boolean; interacting: boolean; resetToken?: number; onReady?: () => void
}) {
  const {scene} = useGLTF(url)
  const {gl, invalidate, camera} = useThree()
  const pivot = useRef<Group>(null)
  const built = useMemo(() => {
    const root=scene.clone(true), geometries: BufferGeometry[]=[], materials: Material[]=[], diagnostics: object[]=[]
    const bounds=new Box3().setFromObject(root), scale=2.6/Math.max(...bounds.getSize(new Vector3()).toArray())
    root.position.sub(bounds.getCenter(new Vector3())); root.updateMatrixWorld(true)
    const gems: Mesh[]=[], cutCache=new Map<StudioCut, BufferGeometry>()
    // Watch hand pivots sit on the dial centre; they are turned to local time below.
    const hands: {object: Object3D; kind: string}[]=[]
    root.traverse(object=>{const kind=object.userData.ames_watch_hand;if(kind==='hour'||kind==='minute'||kind==='second')hands.push({object,kind})})
    // A bracelet built link by link (ames_link = place in the flat line from the clasp) can be unclasped and laid flat.
    let bracelet: BraceletInfo | null = null
    const links: {object: Object3D; order: number; p: Vector3; q: Quaternion}[]=[]
    root.traverse(object=>{const info=object.userData.ames_bracelet;if(info&&typeof info.pitch==='number')bracelet=info as BraceletInfo
      const order=object.userData.ames_link;if(typeof order==='number')links.push({object,order,p:object.position.clone(),q:object.quaternion.clone()})})
    // Hinged parts (earring drops): a node tagged ames_dangle swings about its own origin, the hinge.
    const dangles: {object: Object3D; rest: Quaternion; hang: Vector3; length: number}[]=[]
    root.traverse(object=>{if(!object.userData.ames_dangle||object===root)return
      const box=new Box3();object.updateMatrixWorld(true)
      const toLocal=new Matrix4().copy(object.matrixWorld).invert()
      object.traverse(child=>{if(child instanceof Mesh){child.geometry.computeBoundingBox();box.union(child.geometry.boundingBox!.clone().applyMatrix4(new Matrix4().multiplyMatrices(toLocal,child.matrixWorld)))}})
      if(box.isEmpty())return
      const centre=box.getCenter(new Vector3()),length=centre.length()
      if(length>1e-6)dangles.push({object,rest:object.quaternion.clone(),hang:centre.clone().applyQuaternion(object.quaternion).normalize(),length})})
    root.traverse(object=>{if(object instanceof Mesh && isQualifiedDielectricMesh(object))gems.push(object)})
    const assignment=applyJewelryMaterials(root,studio.environment,{preserveMesh:mesh=>gems.includes(mesh),opticsProfile:'mounted-gem-studio'})
    materials.push(...assignment.materials)
    for(const mesh of gems) {
      const source=(Array.isArray(mesh.material)?mesh.material[0]:mesh.material) as MeshPhysicalMaterial
      const id=String(mesh.userData.ames_gemstone_id ?? mesh.parent?.userData.ames_gemstone_id ?? 'stone-diamond')
      // AMES pavé ships as a layout of melee rather than a mesh: rebuild the stones here.
      const layout=mesh.userData.ames_pave_layout
      if(typeof layout==='string'){mesh.updateMatrix();const pave=createPaveFromLayout(layout,mesh.matrix.clone().invert());mesh.geometry=pave;geometries.push(pave)}
      // Replace only AMES-authored representative cuts. Uploaded jeweller geometry is retained.
      // An AMES-authored piece may name each stone's cut in its node extras (ames_cut).
      const authoredCut=String(mesh.userData.ames_cut ?? '') as StudioCut
      if(BRILLIANT_IDS.has(id) && (STUDIO_CUTS.has(authoredCut) || /\/(stone-[a-z-]+|demo-pave-solitaire)\//.test(url))) {
        mesh.geometry.computeBoundingBox();const old=mesh.geometry.boundingBox!, size=old.getSize(new Vector3()),center=old.getCenter(new Vector3())
        const outline: StudioCut = STUDIO_CUTS.has(authoredCut) ? authoredCut : id==='stone-morganite' ? 'pear' : id==='stone-fancy-color-diamond' ? 'radiant' : ['stone-garnet','stone-spinel'].includes(id) ? 'cushion' : ['stone-sapphire','stone-alexandrite','stone-peridot'].includes(id) ? 'oval' : 'round'
        // Pavé repeats one cut many times: build each outline once per model.
        if(!cutCache.has(outline)){const cut=createStudioBrilliantGeometry(outline);cutCache.set(outline,cut);geometries.push(cut)}
        const geometry=cutCache.get(outline)!.clone();geometry.computeBoundingBox()
        const own=geometry.boundingBox!, ownSize=own.getSize(new Vector3()),ownCenter=own.getCenter(new Vector3())
        geometry.translate(-ownCenter.x,-ownCenter.y,-ownCenter.z)
        geometry.scale(size.x/ownSize.x,size.y/ownSize.y,size.z/ownSize.z)
        geometry.translate(center.x,center.y,center.z);mesh.geometry=geometry;geometries.push(geometry)
      }
      // GPU intersection tolerances operate in geometry-local coordinates. Authoring
      // units can be metres or millimetres: normalise each stone before building its
      // BVH, then preserve its exact placement with the inverse mesh transform.
      mesh.geometry.computeBoundingBox()
      const opticalBounds=mesh.geometry.boundingBox!, opticalCenter=opticalBounds.getCenter(new Vector3())
      const opticalScale=opticalBounds.getSize(new Vector3()).length()
      if(!Number.isFinite(opticalScale)||opticalScale<=0)throw Error('Invalid gemstone volume.')
      const normalised=plainGeometry(mesh.geometry)
      normalised.translate(-opticalCenter.x,-opticalCenter.y,-opticalCenter.z)
      normalised.scale(1/opticalScale,1/opticalScale,1/opticalScale)
      mesh.geometry=normalised;geometries.push(normalised)
      mesh.updateMatrix()
      mesh.matrix.multiply(new Matrix4().makeTranslation(opticalCenter)).multiply(new Matrix4().makeScale(opticalScale,opticalScale,opticalScale))
      mesh.matrix.decompose(mesh.position,mesh.quaternion,mesh.scale);mesh.updateMatrixWorld(true)
      const worldScale=scale * mesh.getWorldScale(new Vector3()).y
      mesh.geometry.computeBoundingBox()
      // Merged pavé (ames_pave) is many melee in one volume: trace it with the small-stone budget.
      const small=mesh.userData.ames_pave===true || mesh.geometry.boundingBox!.getSize(new Vector3()).length()*worldScale<.2
      const material=createPhysicalStudioGem(mesh.geometry,id,source,studio.environment,studio.radiance,worldScale,small)
      mesh.material=material;materials.push(material)
      diagnostics.push({id,type:material.type,ior:material.ior,transmission:material.transmission,roughness:material.roughness,
        color:material.color.getHexString(),attenuationColor:material.attenuationColor.getHexString(),attenuationDistance:material.attenuationDistance,
        thickness:material.thickness,dispersion:material.dispersion,triangles:(mesh.geometry.index?.count??mesh.geometry.getAttribute('position').count)/3,
        cut:mesh.geometry.userData.cut??'imported',...mesh.geometry.userData})
    }
    // Ruler under the flat bracelet: a bar the bracelet's length with centimetre ticks, and its width across one end (mm, piece frame).
    let ruler: Group | null = null
    const info = bracelet as BraceletInfo | null
    if(info && links.length===info.links && links[0].object.parent){
      ruler=new Group();ruler.name='AMES bracelet ruler';ruler.visible=false
      const ink=new MeshBasicMaterial({color:'#dceee8',transparent:true,opacity:0,depthWrite:false});materials.push(ink)
      const bar=(x:number,y:number,z:number,sx:number,sy:number,sz:number)=>{const g=new BoxGeometry(sx,sy,sz);geometries.push(g);const m=new Mesh(g,ink);m.position.set(x,y,z);ruler!.add(m)}
      const L=info.length_mm,zLine=info.width_mm/2+3.2,y=-2.4
      bar(0,y,zLine,L,.22,.22)
      for(let mm=0;mm<=L+.01;mm+=10)bar(mm-L/2,y,zLine,.22,.22,mm%50===0?2.4:1.4)
      bar(L/2,y,zLine,.22,.22,2.4)
      bar(-L/2-2.2,y,0,.22,.22,info.width_mm);bar(-L/2-2.2,y,info.width_mm/2,.9,.22,.22);bar(-L/2-2.2,y,-info.width_mm/2,.9,.22,.22)
      links[0].object.parent.add(ruler)
    }
    const span=bounds.getSize(new Vector3()).toArray().reduce((a,b)=>Math.max(a,b),0)*1000
    return {root,scale,materials,geometries,diagnostics,hands,links,bracelet:info,ruler,span,dangles}
  },[scene,studio,url])
  useEffect(()=>()=>{built.materials.forEach(m=>m.dispose());built.geometries.forEach(g=>g.dispose())},[built])
  useEffect(()=>{
    gl.domElement.dataset.gemMaterials=JSON.stringify(built.diagnostics)
    let frame=requestAnimationFrame(()=>{invalidate();frame=requestAnimationFrame(()=>onReady?.())})
    return()=>{cancelAnimationFrame(frame);delete gl.domElement.dataset.gemMaterials}
  },[built,gl,invalidate,onReady])
  // A watch keeps the viewer's local time: hour and minute glide, the seconds hand sweeps
  // in eight beats a second like an automatic movement.
  useEffect(()=>{
    if(!built.hands.length)return
    const tick=()=>{
      const now=new Date(),seconds=now.getSeconds()+now.getMilliseconds()/1000,minutes=now.getMinutes()+seconds/60,hours=now.getHours()%12+minutes/60
      for(const {object,kind} of built.hands){
        const turns=kind==='hour'?hours/12:kind==='minute'?minutes/60:Math.floor(seconds*8)/8/60
        object.rotation.set(0,0,-turns*Math.PI*2)
      }
      invalidate()
    }
    tick();const timer=setInterval(tick,125)
    return()=>clearInterval(timer)
  },[built,invalidate])
  // Bracelet: the host page sends 'ames:bracelet' {flat} to the canvas; the links unroll from the clasp into a
  // straight line (and back), the view zooms out to fit, and the ruler fades in. The page reads data-ames-bracelet.
  const flatProgress=useRef(0)
  useEffect(()=>{
    const info=built.bracelet,links=built.links
    if(!info||links.length!==info.links)return
    const el=gl.domElement
    el.dataset.amesBracelet=JSON.stringify({...info,clasp:info.clasp??''})
    el.dataset.amesBraceletState='closed'
    const half=(info.links-1)/2,flatQ=new Quaternion(),flatP=links.map(l=>new Vector3((l.order-half)*info.pitch,0,0))
    const flatScale=Math.min(1,built.span*1.5/(info.length_mm+16)),ease=(t:number)=>t*t*(3-2*t),S=.65
    let frame=0,turnFrom=0,turnTo=0
    const apply=(p:number)=>{
      links.forEach((l,i)=>{const t=ease(Math.min(1,Math.max(0,p*(1+S)-S*l.order/(info.links-1))));l.object.position.lerpVectors(l.p,flatP[i],t);l.object.quaternion.slerpQuaternions(l.q,flatQ,t)})
      if(pivot.current){pivot.current.scale.setScalar(built.scale*(1+(flatScale-1)*ease(p)));pivot.current.rotation.y=turnFrom+(turnTo-turnFrom)*ease(Math.min(1,p*1.4))}
      if(built.ruler){const o=Math.min(1,Math.max(0,(p-.82)/.18));built.ruler.visible=o>0;built.ruler.children.forEach(c=>((c as Mesh).material as MeshBasicMaterial).opacity=.85*o)}
      el.dataset.amesBraceletState=p>=1?'flat':p<=0?'closed':'moving'
    }
    const animate=(target:number)=>{
      cancelAnimationFrame(frame)
      const from=flatProgress.current,start=performance.now(),duration=Math.max(1,1700*Math.abs(target-from))
      // Opening: turn the line square to the camera, so it reads left to right with the ruler in front.
      if(target>from&&from===0&&pivot.current){turnFrom=pivot.current.rotation.y%(Math.PI*2);turnTo=Math.atan2(camera.position.x,camera.position.z)
        while(turnTo-turnFrom>Math.PI)turnTo-=Math.PI*2;while(turnTo-turnFrom<-Math.PI)turnTo+=Math.PI*2}
      const step=(now:number)=>{const k=Math.min(1,(now-start)/duration);flatProgress.current=from+(target-from)*k;apply(flatProgress.current);invalidate();if(k<1)frame=requestAnimationFrame(step)}
      frame=requestAnimationFrame(step)
    }
    const onMessage=(event:Event)=>animate((event as CustomEvent<{flat?:boolean}>).detail?.flat?1:0)
    el.addEventListener('ames:bracelet',onMessage)
    return()=>{el.removeEventListener('ames:bracelet',onMessage);cancelAnimationFrame(frame);delete el.dataset.amesBracelet;delete el.dataset.amesBraceletState}
  },[built,gl,invalidate,camera])
  // Dangling: each hinged part is a damped pendulum. When the piece is turned (orbit or turntable) its hinge
  // moves on screen and the part swings behind it, then settles; it also sways gently once as it appears.
  useEffect(()=>{
    const dangles=built.dangles;if(!dangles.length)return
    gl.domElement.dataset.amesDangles=String(dangles.length)
    const reduce=typeof window!=='undefined'&&window.matchMedia?.('(prefers-reduced-motion: reduce)').matches
    const state=dangles.map((d,i)=>{
      // Slowed from real time (about a third) so the swing reads on screen; light damping.
      const omega=Math.min(14,Math.max(5,Math.sqrt(9.81/Math.max(.004,d.length/1000))/3))
      const side=new Vector3(1,0,0).sub(d.hang.clone().multiplyScalar(d.hang.x)).normalize()
      return {omega,zeta:.07,angle:new Vector3(),speed:reduce?new Vector3():side.multiplyScalar(i%2?-1.4:1.4),prev:null as Vector3|null,prevV:null as Vector3|null}
    })
    const world=new Vector3(),cam=new Vector3(),acc=new Vector3(),q=new Quaternion(),parentQ=new Quaternion(),scaleV=new Vector3(),axis=new Vector3(),swing=new Quaternion()
    let frame=0,last=performance.now()
    const tick=(now:number)=>{
      const dt=Math.min(.05,(now-last)/1000);last=now;let moving=false
      dangles.forEach((d,i)=>{
        const s=state[i],parent=d.object.parent;if(!parent)return
        // The hinge's acceleration as seen from the camera, in the part's parent frame (mm/s²).
        d.object.getWorldPosition(world);cam.copy(world).applyMatrix4(camera.matrixWorldInverse)
        acc.set(0,0,0)
        if(s.prev&&dt>0){const v=cam.clone().sub(s.prev).divideScalar(dt);if(s.prevV)acc.copy(v).sub(s.prevV).divideScalar(dt);s.prevV=v}
        s.prev=cam.clone()
        parent.getWorldQuaternion(parentQ);parent.getWorldScale(scaleV)
        acc.applyQuaternion(camera.quaternion).applyQuaternion(q.copy(parentQ).invert()).divideScalar(scaleV.x||1)
        acc.sub(d.hang.clone().multiplyScalar(acc.dot(d.hang)))
        if(acc.length()>2e5)acc.setLength(2e5)
        // θ'' = -ω²θ - 2ζωθ' - a/L (the part lags behind its hinge), a few sub-steps per frame.
        const steps=Math.max(1,Math.ceil(dt*240)),h=dt/steps
        for(let k=0;k<steps;k++){
          const a=s.angle.clone().multiplyScalar(-s.omega*s.omega).addScaledVector(s.speed,-2*s.zeta*s.omega).addScaledVector(acc,-.35/d.length)
          s.speed.addScaledVector(a,h);s.angle.addScaledVector(s.speed,h)
          s.angle.sub(d.hang.clone().multiplyScalar(s.angle.dot(d.hang)))
        }
        if(s.angle.length()>.6)s.angle.setLength(.6)
        const turn=s.angle.length()
        if(turn>1e-5){axis.crossVectors(d.hang,s.angle).normalize();swing.setFromAxisAngle(axis,turn);d.object.quaternion.copy(d.rest).premultiply(swing)}
        else d.object.quaternion.copy(d.rest)
        if(turn>2e-4||s.speed.length()>2e-3)moving=true
      })
      if(moving){invalidate();gl.domElement.dataset.amesDangleSwing=(Math.max(...state.map(x=>x.angle.length()))*180/Math.PI).toFixed(1)}
      else if(gl.domElement.dataset.amesDangleSwing!=='0.0')gl.domElement.dataset.amesDangleSwing='0.0'
      frame=requestAnimationFrame(tick)
    }
    frame=requestAnimationFrame(tick)
    return()=>{cancelAnimationFrame(frame);dangles.forEach(d=>d.object.quaternion.copy(d.rest));delete gl.domElement.dataset.amesDangles}
  },[built,gl,invalidate,camera])
  useControlledTurntable(pivot,enabled,true,interacting,resetToken,invalidate)
  return <group ref={pivot} name="ames-physical-turntable" scale={built.scale}><primitive object={built.root}/></group>
}
