import { useEffect, useMemo } from 'react'
import { useFrame, useThree } from '@react-three/fiber'
import { Color, HalfFloatType, NoToneMapping, ShaderMaterial, Vector2, WebGLRenderTarget } from 'three'
import { FullScreenQuad } from 'three/examples/jsm/postprocessing/Pass.js'

/** HDR-only highlight bloom, preserving transparent alpha and tone-mapping once. */
export function StudioBloom() {
  const {gl,size}=useThree()
  const state=useMemo(()=>{
    const target=()=>new WebGLRenderTarget(1,1,{type:HalfFloatType,depthBuffer:true})
    const base=target(), blurA=target(),blurB=target()
    base.samples=4
    const vertexShader='varying vec2 vUv; void main(){vUv=uv;gl_Position=vec4(position.xy,0.,1.);}'
    const blur=new ShaderMaterial({vertexShader,depthTest:false,depthWrite:false,toneMapped:false,
      uniforms:{inputMap:{value:base.texture},stepUv:{value:new Vector2()},threshold:{value:1.4}},
      fragmentShader:`varying vec2 vUv;uniform sampler2D inputMap;uniform vec2 stepUv;uniform float threshold;
      void main(){vec3 sum=vec3(0.);float weightSum=0.;for(int i=-4;i<=4;i++){
        float w=exp(-float(i*i)/7.);vec3 c=texture2D(inputMap,vUv+float(i)*stepUv).rgb;
        float peak=max(c.r,max(c.g,c.b));c*=max(peak-threshold,0.)/max(peak,.0001);sum+=c*w;weightSum+=w;
      }gl_FragColor=vec4(sum/weightSum,1.);}`})
    const output=new ShaderMaterial({vertexShader,depthTest:false,depthWrite:false,toneMapped:true,
      uniforms:{baseMap:{value:base.texture},glowMap:{value:blurB.texture}},
      fragmentShader:`varying vec2 vUv;uniform sampler2D baseMap;uniform sampler2D glowMap;
      void main(){vec4 base=texture2D(baseMap,vUv);vec3 glow=texture2D(glowMap,vUv).rgb*.09;
        float halo=clamp(max(glow.r,max(glow.g,glow.b)),0.,.3);float a=max(base.a,halo);
        gl_FragColor=vec4((base.rgb+glow)/max(a,.0001),a);
        #include <tonemapping_fragment>
        #include <colorspace_fragment>
        gl_FragColor.rgb *= gl_FragColor.a;
      }`})
    return {base,blurA,blurB,blur,output,quad:new FullScreenQuad(blur),clear:new Color()}
  },[])
  useEffect(()=>{
    const dpr=gl.getPixelRatio(),w=Math.max(1,Math.round(size.width*dpr)),h=Math.max(1,Math.round(size.height*dpr))
    state.base.setSize(w,h);state.blurA.setSize(Math.ceil(w/2),Math.ceil(h/2));state.blurB.setSize(Math.ceil(w/2),Math.ceil(h/2))
    gl.domElement.dataset.studioBloom='hdr-threshold';return()=>{delete gl.domElement.dataset.studioBloom}
  },[gl,size,state])
  useEffect(()=>()=>{state.base.dispose();state.blurA.dispose();state.blurB.dispose();state.blur.dispose();state.output.dispose();state.quad.dispose()},[state])
  useFrame(({scene,camera})=>{
    const target=gl.getRenderTarget(),tone=gl.toneMapping,alpha=gl.getClearAlpha();gl.getClearColor(state.clear)
    gl.setClearColor(0,0);gl.toneMapping=NoToneMapping;gl.setRenderTarget(state.base);gl.clear();gl.render(scene,camera)
    state.quad.material=state.blur;state.blur.uniforms.inputMap.value=state.base.texture
    state.blur.uniforms.threshold.value=1.4;state.blur.uniforms.stepUv.value.set(1/state.blurA.width,0)
    gl.setRenderTarget(state.blurA);state.quad.render(gl)
    state.blur.uniforms.inputMap.value=state.blurA.texture;state.blur.uniforms.threshold.value=0;state.blur.uniforms.stepUv.value.set(0,1/state.blurB.height)
    gl.setRenderTarget(state.blurB);state.quad.render(gl)
    gl.toneMapping=tone;gl.setRenderTarget(target);state.quad.material=state.output;state.quad.render(gl);gl.setClearColor(state.clear,alpha)
  },1)
  return null
}
