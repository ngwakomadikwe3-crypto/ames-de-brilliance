import { Color, Matrix4, MeshPhysicalMaterial, Vector3 } from 'three'
import type { BufferGeometry, Texture } from 'three'
import { MeshBVH, MeshBVHUniformStruct, shaderStructs, shaderIntersectFunction } from 'three-mesh-bvh'

export const STONE_OPTICS: Record<string, { ior: number; color: string; distance: number; dispersion: number }> = {
  'stone-diamond': { ior: 2.417, color: '#ffffff', distance: 12, dispersion: .7 },
  'stone-fancy-color-diamond': { ior: 2.417, color: '#ffe18c', distance: 2.8, dispersion: .7 },
  'stone-ruby': { ior: 1.76, color: '#e53051', distance: 1.8, dispersion: .18 },
  'stone-sapphire': { ior: 1.76, color: '#456fdb', distance: 1.9, dispersion: .18 },
  'stone-emerald': { ior: 1.577, color: '#14a85e', distance: 1.25, dispersion: .1 },
  'stone-morganite': { ior: 1.58, color: '#efb2bd', distance: 2.5, dispersion: .12 },
  'stone-kunzite': { ior: 1.66, color: '#dda4d1', distance: 2.2, dispersion: .15 },
}

/** MeshPhysicalMaterial with a BVH volume transmission extension. Stock physical
 * reflection/clearcoat remain intact; rays actually exit the faceted stone,
 * including total internal reflection and wavelength-dependent IOR. */
export function createPhysicalStudioGem(geometry: BufferGeometry, id: string, source: MeshPhysicalMaterial,
  environment: Texture, radiance: Texture, worldScale: number, small = false) {
  geometry.computeBoundingBox()
  const size = geometry.boundingBox!.getSize(new Vector3())
  const depth = size.y
  const optical = STONE_OPTICS[id], diamond = id === 'stone-diamond' || id === 'stone-fancy-color-diamond'
  const ior = optical?.ior ?? source.ior ?? 1.6
  const body = optical ? new Color(optical.color) : source.attenuationColor?.clone() ?? source.color.clone()
  if (!optical && body.equals(new Color('white'))) body.copy(source.color)
  const material = new MeshPhysicalMaterial({
    name: 'AMES studio volume · ' + id, color: 'white', metalness: 0, roughness: diamond ? 0 : .045,
    transmission: 1, ior, thickness: depth, attenuationColor: body,
    attenuationDistance: depth * worldScale * (optical?.distance ?? 2),
    dispersion: optical?.dispersion ?? .18, clearcoat: diamond ? .18 : 0, clearcoatRoughness: 0,
    envMap: environment, envMapIntensity: diamond ? 1 : .5, flatShading: true, toneMapped: true,
  })
  const bvhGeometry = geometry.clone()
  const bvh = new MeshBVHUniformStruct()
  bvh.updateFrom(new MeshBVH(bvhGeometry, { targetLeafSize: 2 }))
  const localToWorld = new Matrix4(), worldToLocal = new Matrix4()
  const uniforms = {
    amesBvh: { value: bvh }, amesRadiance: { value: radiance },
    amesLocalToWorld: { value: localToWorld }, amesWorldToLocal: { value: worldToLocal },
    amesEpsilon: { value: size.length() * .00002 },
    // How soft the studio looks from inside the stone. Pixel-sharp, the light tent's edges repeat as hard lines down
    // every parallel step facet; a touch of softness gives the broad light and dark bands a real stone shows.
    amesSoftness: { value: id === 'stone-diamond' || id === 'stone-fancy-color-diamond' ? .035 : .075 },
  }
  material.userData = { studioPhysical: true, gemstoneId: id, bounces: small ? 4 : 7 }
  material.customProgramCacheKey = () => 'ames-physical-bvh-v3-' + (small ? 'small' : 'hero')
  material.onBeforeCompile = shader => {
    Object.assign(shader.uniforms, uniforms)
    shader.vertexShader = 'varying vec3 amesLocalPosition; varying vec3 amesLocalNormal;\n' + shader.vertexShader
    shader.fragmentShader = 'varying vec3 amesLocalPosition; varying vec3 amesLocalNormal;\n' + shader.fragmentShader
    shader.vertexShader = shader.vertexShader.replace('#include <begin_vertex>', '#include <begin_vertex>\namesLocalPosition = position; amesLocalNormal = normal;')
    shader.fragmentShader = shader.fragmentShader.replace('#include <envmap_physical_pars_fragment>', `#include <envmap_physical_pars_fragment>
      precision highp isampler2D;
      precision highp usampler2D;
      uniform sampler2D amesRadiance;
      uniform mat4 amesLocalToWorld;
      uniform mat4 amesWorldToLocal;
      uniform float amesEpsilon;
      uniform float amesSoftness;
      ${shaderStructs}
      ${shaderIntersectFunction}
      uniform BVH amesBvh;
      vec3 amesEnvironment(vec3 ray) {
        vec3 d = normalize(mat3(amesLocalToWorld) * ray);
        return textureCubeUV(envMap, envMapRotation * d, amesSoftness).rgb;
      }
      vec3 amesTrace(float eta, vec3 absorption, float distanceScale) {
        vec3 camera = (amesWorldToLocal * vec4(cameraPosition,1.)).xyz;
        vec3 incoming = normalize(amesLocalPosition-camera);
        vec3 n = normalize(amesLocalNormal);
        vec3 ray = refract(incoming, n, 1. / eta);
        vec3 origin = amesLocalPosition + ray * amesEpsilon;
        vec3 throughput = vec3(1.); vec3 light = vec3(0.);
        for (int bounce=0; bounce<${small ? 4 : 7}; bounce++) {
          uvec4 indices=uvec4(0u); vec3 normal=vec3(0.); vec3 bary=vec3(0.);
          float side=1.; float distanceToFace=0.;
          bool hit=bvhIntersectFirstHit(amesBvh, origin, ray, indices, normal, bary, side, distanceToFace);
          if (!hit) { light += throughput * amesEnvironment(ray); break; }
          float travel=length(mat3(amesLocalToWorld)*(ray*distanceToFace));
          throughput *= pow(max(absorption,vec3(.0001)),vec3(travel/max(distanceScale,.000001)));
          vec3 boundary=origin+ray*distanceToFace;
          vec3 exitRay=refract(ray, normal, eta);
          if(dot(exitRay,exitRay)>.00001) {
            float f0=pow((eta-1.)/(eta+1.),2.);
            float fresnel=f0+(1.-f0)*pow(1.-clamp(dot(-ray,normal),0.,1.),5.);
            light += throughput*(1.-fresnel)*amesEnvironment(exitRay);
            throughput *= fresnel;
          }
          if(max(throughput.r,max(throughput.g,throughput.b))<.003) break;
          ray=reflect(ray,normal);origin=boundary+ray*amesEpsilon;
        }
        return light;
      }
    `)
    shader.fragmentShader = shader.fragmentShader.replace('#include <transmission_fragment>', `
      material.transmission=transmission; material.transmissionAlpha=1.;
      float spread=dispersion*.025;
      vec3 transmitted=vec3(
        amesTrace(ior-spread,attenuationColor,attenuationDistance).r,
        amesTrace(ior,attenuationColor,attenuationDistance).g,
        amesTrace(ior+spread,attenuationColor,attenuationDistance).b);
      float faceF0=pow((ior-1.)/(ior+1.),2.);
      float faceF=faceF0+(1.-faceF0)*pow(1.-clamp(dot(geometryNormal,geometryViewDir),0.,1.),5.);
      totalDiffuse = transmitted * (1.-faceF);
    `)
  }
  material.onBeforeRender = (_renderer, _scene, _camera, _geometry, object) => {
    localToWorld.copy(object.matrixWorld); worldToLocal.copy(object.matrixWorld).invert()
  }
  material.addEventListener('dispose', () => { bvh.dispose(); bvhGeometry.dispose() })
  return material
}
